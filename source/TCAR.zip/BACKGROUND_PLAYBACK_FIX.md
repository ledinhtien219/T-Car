# Background playback fix

Các thay đổi chính:

1. `CarHudAutoScreen`
   - Không shutdown toàn bộ app khi Android Auto surface bị destroy.
   - Chỉ detach `Presentation`/`VirtualDisplay`, giữ persistent WebView và media service.

2. `CarHudAutoService`
   - Không kill app trong `onDestroy()` hoặc `Session.onDestroy()` vì đây không phải tín hiệu disconnect đáng tin cậy.
   - Chỉ shutdown hoàn toàn khi nhận USB detach thật; bỏ `ACTION_POWER_DISCONNECTED` để tránh false-positive với Android Auto không dây/thay đổi nguồn sạc.

3. `CarMediaManager`
   - Thêm background playback keep-alive mỗi 5 giây khi Android Auto còn kết nối và người dùng muốn tiếp tục phát.
   - Với IPTV gọi `window.__carhudKeepAlive()` để tiếp tục HLS/video.
   - Với YouTube gọi helper resume để chống Chromium/WebView suspend khi surface bị tháo.
   - Dừng keep-alive khi người dùng thực sự pause hoặc kết nối được đánh dấu ngắt.

4. `iptv_player.html`
   - Đồng bộ `play/playing/pause/ended` về native bằng `onPlaybackStateChanged`.
   - Thêm `__carhudKeepAlive()` để restart HLS loading và `video.play()` sau khi WebView bị background/throttle.
   - Thêm phục hồi khi visibility/pageshow trở lại.

Kiểm tra đã thực hiện:
- JavaScript inline của IPTV: `node --check` pass.
- Gradle compile chưa chạy được trong môi trường đóng mạng vì wrapper cần tải Gradle 8.14.5 từ services.gradle.org.
