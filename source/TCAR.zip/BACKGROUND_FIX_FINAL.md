# Android Auto background playback - minimal final fix

This package is rebuilt from the original uploaded project.

Only runtime source change:
- `app/src/main/java/com/carhud/aaproxy/CarHudAutoScreen.kt`

Behavior change:
- `onSurfaceDestroyed()` no longer treats Android Auto surface loss as cable unplug.
- The existing VirtualDisplay is kept alive and switched to headless mode with `setSurface(null)`.
- The existing Presentation/WebView remains attached to its Window, avoiding background Chromium/HLS disruption.
- When the surface returns, existing `setupPresentation()` recreates the VirtualDisplay as before.

Intentionally NOT changed:
- `CarMediaManager.kt`
- `CarHudAutoService.kt`
- `iptv_player.html`
- YouTube player logic
- wake-lock/audio-focus/timer behavior

This preserves the original project's background playback tuning and only fixes the Android Auto surface lifecycle path.
