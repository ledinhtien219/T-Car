package com.carhud.aaproxy

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.webkit.WebView

open class BackgroundAudioWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : WebView(context, attrs, defStyleAttr) {

    var keepAudioAlive: Boolean = true

    override fun onWindowVisibilityChanged(visibility: Int) {
        if (keepAudioAlive && (visibility == GONE || visibility == INVISIBLE)) {
            super.onWindowVisibilityChanged(VISIBLE)
        } else {
            super.onWindowVisibilityChanged(visibility)
        }
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        if (keepAudioAlive && (visibility == GONE || visibility == INVISIBLE)) {
            super.onVisibilityChanged(changedView, VISIBLE)
        } else {
            super.onVisibilityChanged(changedView, visibility)
        }
    }
}
