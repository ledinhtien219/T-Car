package com.carhud.aaproxy

import com.carhud.app.R
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Modern High-Tech Automotive Cockpit Dashboard
 *
 * Left Column (~48% width):
 *   - Card 1: Cockpit Digital Clock & Lunar Calendar (Weight 1.0f)
 *   - Card 2: Studio Audio Player with Album Art & Scrubber (Weight 1.4f)
 *   - Card 3: Weather Station with Massive Temperature Font (54sp) & Environmental Chips (Weight 1.0f)
 *
 * Right Column (~52% width):
 *   - Card 4: Speed Limit Dial, Speedometer & Waze Mod Smart Alerts with Voice TTS (Weight 1.0f)
 *   - Card 5: Favorite Apps Launcher / Embedded App View (Weight 2.4f)
 */
class CarDashboardView(
    context: Context,
    private val onAppClick: (WebAppItem) -> Unit,
    private val onAddAppClick: () -> Unit,
    private val onAllAppsClick: () -> Unit,
    private val onFullscreenRequested: ((WebAppItem) -> Unit)? = null,
    private val onBackClick: (() -> Unit)? = null,
    private val onEmbeddedClosed: (() -> Unit)? = null
) : FrameLayout(context) {

    /**
     * XML/Layout Editor constructor.
     * Runtime code can keep using the callback-based constructor above.
     */
    constructor(context: Context, attrs: AttributeSet?) : this(
        context = context,
        onAppClick = {},
        onAddAppClick = {},
        onAllAppsClick = {}
    )

    private val density = context.resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * density + 0.5f).toInt()

    private val coroutineScope = CoroutineScope(Dispatchers.Main + Job())
    private val timeHandler = Handler(Looper.getMainLooper())
    private var isDayMode = false

    // Root containers
    private lateinit var rootHorizontal: LinearLayout
    private lateinit var leftColumn: LinearLayout
    private lateinit var rightColumn: LinearLayout

    // Card 1: Clock & Calendar
    private lateinit var clockCard: LinearLayout
    private lateinit var clockText: TextView
    private lateinit var dateText: TextView

    // Card 2: Music Player (Spotify Style)
    private lateinit var musicCard: LinearLayout
    private lateinit var mediaAlbumArt: FrameLayout
    private lateinit var mediaAlbumImageView: ImageView
    private lateinit var mediaAlbumIcon: TextView

    private lateinit var mediaTitleText: TextView
    private lateinit var mediaArtistText: TextView

    private lateinit var mediaCurTimeText: TextView
    private lateinit var mediaProgressBar: ProgressBar
    private lateinit var mediaDurTimeText: TextView

    private lateinit var mediaShuffleBtn: ImageView
    private lateinit var mediaPrevBtn: ImageView
    private lateinit var mediaPlayPauseBtn: FrameLayout
    private lateinit var mediaPlayPauseIcon: ImageView
    private lateinit var mediaNextBtn: ImageView
    private lateinit var mediaRepeatBtn: ImageView

    // Card 3: Weather Station
    private lateinit var weatherCard: LinearLayout
    private lateinit var weatherIconText: TextView
    private lateinit var weatherTempText: TextView
    private lateinit var weatherUnitText: TextView
    private lateinit var weatherLocationBadge: TextView
    private lateinit var weatherHumidityChip: TextView
    private lateinit var weatherWindChip: TextView

    // Card 4: Speed & Waze Mod Alerts
    private lateinit var speedCard: LinearLayout
    private lateinit var speedLimitBadge: TextView
    private lateinit var currentSpeedHolder: FrameLayout
    private lateinit var currentSpeedBadge: TextView
    private lateinit var currentSpeedUnit: TextView
    private lateinit var alertContainer: FrameLayout
    private lateinit var alertActiveBox: LinearLayout
    private lateinit var alertIconBox: FrameLayout
    private lateinit var alertIconText: TextView
    private lateinit var alertSourceBadge: TextView
    private lateinit var alertDistBadge: TextView
    private lateinit var alertTitleText: TextView
    private lateinit var alertRoadText: TextView
    private lateinit var speedAlertDivider: View
    private var overspeedAnimator: android.animation.ValueAnimator? = null
    private var isOverspeedAnimating = false

    // Card 5: Favorite Apps Grid / Embedded App
    private lateinit var appsCard: LinearLayout
    private lateinit var app2GridContainer: LinearLayout
    private lateinit var app2GridTitle: TextView
    private lateinit var app2RowsContainer: LinearLayout
    private lateinit var app2DotsIndicator: LinearLayout
    private lateinit var allAppsBtn: TextView
    private lateinit var app2Dot1: View
    private lateinit var app2Dot2: View
    private lateinit var app2Dot3: View

    private lateinit var app2EmbeddedContainer: LinearLayout
    private lateinit var app2EmbeddedHolder: FrameLayout
    private lateinit var app2EmbeddedTitle: TextView
    private lateinit var app2EmbeddedIcon: ImageView
    private lateinit var app2HomeBtn: TextView
    private lateinit var app2BackBtn: TextView
    private lateinit var app2ReloadBtn: TextView
    private lateinit var app2ChannelsBtn: TextView
    private lateinit var app2FitBtn: TextView
    private lateinit var app2FsBtn: TextView
    private lateinit var app2SwitchBtn: TextView
    private var currentApp2: WebAppItem? = null
    private var currentWeb2: WebView? = null

    // Delete confirm overlay
    private var deleteConfirmOverlay: FrameLayout? = null

    init {
        isDayMode = SettingsActivity.resolveIsDay(context)
        updateDashboardBackground(isDayMode)
        setPadding(0, 0, 0, 0)

        // The real UI is inflated from res/layout/dashboard.xml.
        // Edit dashboard.xml in Split/Design; the app uses that same layout.
        buildClassicLayout()

        // Never start services/flows inside Android Studio's layout preview.
        if (!isInEditMode) {
            CarTtsManager.init(context)
            CarTtsManager.startListeningToRepository()
            startLiveStreams()
        }
    }

    private fun updateDashboardBackground(isDay: Boolean) {
        val bg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            if (isDay) {
                // Sáng: nền ánh tím nhạt/bạc theo ảnh mẫu (media_1789114879718.png)
                intArrayOf(
                    Color.parseColor("#E2E4F6"),
                    Color.parseColor("#E8EAF9"),
                    Color.parseColor("#ECEEFB")
                )
            } else {
                // Tối: nền xanh than chì/petrol cockpit theo ảnh mẫu (media_1789114840922.png)
                intArrayOf(
                    Color.parseColor("#18262D"),
                    Color.parseColor("#1B2E35"),
                    Color.parseColor("#1F3038")
                )
            }
        )
        background = bg
    }

    private fun rounded(bgColor: Int, radiusDp: Float, strokeColor: Int = 0, strokeWidthDp: Int = 0): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusDp * density
            setColor(bgColor)
            if (strokeWidthDp > 0 && strokeColor != 0) {
                setStroke((strokeWidthDp * density).toInt(), strokeColor)
            }
        }
    }

    private fun buildClassicLayout() {
        removeAllViews()
        LayoutInflater.from(context).inflate(R.layout.dashboard, this, true)

        // Root
        rootHorizontal = findViewById(R.id.rootHorizontal)
        leftColumn = findViewById(R.id.leftColumn)
        rightColumn = findViewById(R.id.rightColumn)

        // Clock
        clockCard = findViewById(R.id.clockCard)
        clockText = findViewById(R.id.clockText)
        dateText = findViewById(R.id.dateText)

        // Music
        musicCard = findViewById(R.id.musicCard)
        mediaAlbumArt = findViewById(R.id.mediaAlbumArt)
        mediaAlbumImageView = findViewById(R.id.mediaAlbumImageView)
        mediaAlbumIcon = findViewById(R.id.mediaAlbumIcon)
        mediaTitleText = findViewById(R.id.mediaTitleText)
        mediaArtistText = findViewById(R.id.mediaArtistText)
        mediaCurTimeText = findViewById(R.id.mediaCurTimeText)
        mediaProgressBar = findViewById(R.id.mediaProgressBar)
        mediaDurTimeText = findViewById(R.id.mediaDurTimeText)
        mediaShuffleBtn = findViewById(R.id.mediaShuffleBtn)
        mediaPrevBtn = findViewById(R.id.mediaPrevBtn)
        mediaPlayPauseBtn = findViewById(R.id.mediaPlayPauseBtn)
        mediaPlayPauseIcon = findViewById(R.id.mediaPlayPauseIcon)
        mediaNextBtn = findViewById(R.id.mediaNextBtn)
        mediaRepeatBtn = findViewById(R.id.mediaRepeatBtn)

        // Weather
        weatherCard = findViewById(R.id.weatherCard)
        weatherIconText = findViewById(R.id.weatherIconText)
        weatherTempText = findViewById(R.id.weatherTempText)
        weatherUnitText = findViewById(R.id.weatherUnitText)
        weatherLocationBadge = findViewById(R.id.weatherLocationBadge)
        weatherHumidityChip = findViewById(R.id.weatherHumidityChip)
        weatherWindChip = findViewById(R.id.weatherWindChip)

        // Speed / Waze
        speedCard = findViewById(R.id.speedCard)
        speedLimitBadge = findViewById(R.id.speedLimitBadge)
        currentSpeedHolder = findViewById(R.id.currentSpeedHolder)
        currentSpeedBadge = findViewById(R.id.currentSpeedBadge)
        currentSpeedUnit = findViewById(R.id.currentSpeedUnit)
        alertContainer = findViewById(R.id.alertContainer)
        alertActiveBox = findViewById(R.id.alertActiveBox)
        alertIconBox = findViewById(R.id.alertIconBox)
        alertIconText = findViewById(R.id.alertIconText)
        alertSourceBadge = findViewById(R.id.alertSourceBadge)
        alertDistBadge = findViewById(R.id.alertDistBadge)
        alertTitleText = findViewById(R.id.alertTitleText)
        alertRoadText = findViewById(R.id.alertRoadText)
        speedAlertDivider = findViewById(R.id.speedAlertDivider)

        // Apps / embedded player
        appsCard = findViewById(R.id.appsCard)
        app2GridContainer = findViewById(R.id.app2GridContainer)
        app2GridTitle = findViewById(R.id.app2GridTitle)
        app2RowsContainer = findViewById(R.id.app2RowsContainer)
        app2DotsIndicator = findViewById(R.id.app2DotsIndicator)
        allAppsBtn = findViewById(R.id.allAppsBtn)
        app2Dot1 = findViewById(R.id.app2Dot1)
        app2Dot2 = findViewById(R.id.app2Dot2)
        app2Dot3 = findViewById(R.id.app2Dot3)
        app2EmbeddedContainer = findViewById(R.id.app2EmbeddedContainer)
        app2EmbeddedHolder = findViewById(R.id.app2EmbeddedHolder)
        app2EmbeddedTitle = findViewById(R.id.app2EmbeddedTitle)
        app2EmbeddedIcon = findViewById(R.id.app2EmbeddedIcon)
        app2HomeBtn = findViewById(R.id.app2HomeBtn)
        app2BackBtn = findViewById(R.id.app2BackBtn)
        app2ReloadBtn = findViewById(R.id.app2ReloadBtn)
        app2ChannelsBtn = findViewById(R.id.app2ChannelsBtn)
        app2FitBtn = findViewById(R.id.app2FitBtn)
        app2FsBtn = findViewById(R.id.app2FsBtn)
        app2SwitchBtn = findViewById(R.id.app2SwitchBtn)

        // Keep the same behavior as the old programmatic layout.
        // The dashboard currently shows exactly 4 cards: 3 left + player on the right.
        speedCard.visibility = View.GONE
        app2GridContainer.visibility = View.GONE
        app2EmbeddedContainer.visibility = View.VISIBLE

        // Music controls
        mediaProgressBar.max = 100
        mediaProgressBar.setOnTouchListener { v, event ->
            if (event.action == android.view.MotionEvent.ACTION_DOWN ||
                event.action == android.view.MotionEvent.ACTION_MOVE
            ) {
                val dur = CarMediaManager.trackState.value.currentDurationSec
                if (dur > 0 && v.width > 0) {
                    val ratio = (event.x / v.width).coerceIn(0f, 1f)
                    CarMediaManager.seekTo((ratio * dur).toLong())
                }
            }
            true
        }
        mediaShuffleBtn.setOnClickListener { CarMediaManager.toggleShuffle() }
        mediaPrevBtn.setOnClickListener { CarMediaManager.playPrevious() }
        mediaPlayPauseBtn.setOnClickListener { CarMediaManager.togglePlayPause() }
        mediaNextBtn.setOnClickListener { CarMediaManager.playNext() }
        mediaRepeatBtn.setOnClickListener { CarMediaManager.toggleRepeat() }

        // Weather refresh
        weatherCard.setOnClickListener {
            val loc = GpsSpeedManager.lastLocation.value
            if (loc != null) {
                WeatherManager.updateFromLocation(context, loc)
            } else {
                WeatherManager.updateLocation(21.0285, 105.8542, "Hà Nội")
            }
        }

        // App grid
        allAppsBtn.setOnClickListener { onAllAppsClick() }

        // Embedded player toolbar
        app2HomeBtn.setOnClickListener {
            val app = currentApp2
            val web = currentWeb2
            if (app != null && web != null) {
                val prefs = context.getSharedPreferences(SettingsActivity.PREFS, Context.MODE_PRIVATE)
                val isDesktop = prefs.getBoolean(SettingsActivity.KEY_DESKTOP_MODE, false)
                val homeUrl = if (app.id == "youtube") {
                    if (isDesktop) "https://www.youtube.com" else "https://m.youtube.com"
                } else {
                    app.url
                }
                web.loadUrl(homeUrl)
            }
        }

        app2BackBtn.setOnClickListener {
            val web = currentWeb2
            if (web != null && web.canGoBack()) {
                web.goBack()
            } else {
                closeEmbeddedApp()
            }
        }
        app2ReloadBtn.setOnClickListener { currentWeb2?.reload() }
        app2ChannelsBtn.setOnClickListener {
            currentWeb2?.evaluateJavascript("if(window.toggleChannels) window.toggleChannels();", null)
        }
        app2FitBtn.setOnClickListener {
            currentWeb2?.evaluateJavascript("if(window.toggleVideoFit) window.toggleVideoFit();", null)
        }
        app2FsBtn.setOnClickListener {
            currentApp2?.let { onFullscreenRequested?.invoke(it) }
        }
        app2SwitchBtn.setOnClickListener {
            val appList = WebAppManager.getAllApps(context)
            val nextApp = if (currentApp2?.id == "iptv") {
                appList.firstOrNull { it.id == "youtube" } ?: WebAppManager.DEFAULT_APPS.first()
            } else {
                appList.firstOrNull { it.id == "iptv" }
                    ?: appList.firstOrNull { it.id == "youtube" }
                    ?: WebAppManager.DEFAULT_APPS.first()
            }
            onAppClick(nextApp)
        }

        // Apply the same runtime theme logic to the XML-backed views.
        // dashboard.xml already carries preview styling, so skip app/services work in edit mode.
        if (!isInEditMode) {
            applyDayNightMode(isDayMode)
        }
    }

    // ==========================================
    // EMBEDDED APP CONTROLLERS
    // ==========================================

    fun showEmbeddedApp(app: WebAppItem, webView: WebView) {
        showEmbeddedApp2(app, webView)
    }

    fun showEmbeddedApp2(app: WebAppItem, webView: WebView) {
        currentApp2 = app
        currentWeb2 = webView
        CarMediaManager.isEmbeddedAppShowing = true
        CarMediaManager.activeAppId = app.id
        CarMediaManager.lastEmbeddedApp = app
        app2EmbeddedTitle.text = app.name
        if (!app.iconPath.isNullOrBlank() && File(app.iconPath).exists()) {
            val bmp = BitmapFactory.decodeFile(app.iconPath)
            if (bmp != null) app2EmbeddedIcon.setImageBitmap(bmp) else app2EmbeddedIcon.setImageResource(app.iconRes)
        } else {
            app2EmbeddedIcon.setImageResource(app.iconRes)
        }

        try {
            (webView.parent as? ViewGroup)?.removeView(webView)
        } catch (e: Exception) {}

        app2EmbeddedHolder.removeAllViews()
        app2EmbeddedHolder.addView(webView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        webView.visibility = View.VISIBLE
        YouTubePlayerHelper.applyTheme(webView, this.isDayMode)

        val isYouTube = (app.id == "youtube" || app.url.contains("youtube"))
        val isIptv = (app.id == "iptv" || app.url.contains("iptv_player.html"))
        if (isIptv) {
            webView.evaluateJavascript("window.isDashboardMode = true; if (window.hideChannelsAndControls) window.hideChannelsAndControls();", null)
            webView.postDelayed({
                webView.evaluateJavascript("window.isDashboardMode = true; if (window.hideChannelsAndControls) window.hideChannelsAndControls();", null)
            }, 300L)
        }
        if (::app2HomeBtn.isInitialized) app2HomeBtn.visibility = if (isYouTube) VISIBLE else GONE
        if (::app2BackBtn.isInitialized) app2BackBtn.visibility = GONE
        if (::app2ReloadBtn.isInitialized) app2ReloadBtn.visibility = GONE
        if (::app2ChannelsBtn.isInitialized) app2ChannelsBtn.visibility = if (isIptv) VISIBLE else GONE
        if (::app2FitBtn.isInitialized) app2FitBtn.visibility = if (isIptv) VISIBLE else GONE
        if (::app2FsBtn.isInitialized) app2FsBtn.visibility = if (isYouTube) VISIBLE else GONE
        if (::app2SwitchBtn.isInitialized) app2SwitchBtn.visibility = GONE

        // Expand rightColumn: hide speedCard so embedded app gets 100% full height
        speedCard.visibility = View.GONE
        appsCard.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        appsCard.setPadding(0, 0, 0, 0)
        appsCard.background = null
        app2EmbeddedHolder.background = null
        app2GridContainer.visibility = View.GONE
        app2EmbeddedContainer.visibility = View.VISIBLE

        app2EmbeddedHolder.post {
            try {
                webView.onResume()
                webView.evaluateJavascript(
                    """
                    (function() {
                        var v = document.querySelector('video');
                        if (v && v.paused) { try { if (v.muted) v.muted = false; v.play(); } catch(e){} }
                        var p = document.getElementById('movie_player') || document.querySelector('.html5-video-player');
                        if (p && typeof p.playVideo === 'function' && p.getPlayerState && p.getPlayerState() !== 1) { try { p.playVideo(); } catch(e){} }
                    })();
                    """.trimIndent(), null
                )
            } catch (e: Exception) {}
        }
    }

    fun detachEmbeddedWeb() {
        try {
            if (::app2EmbeddedHolder.isInitialized) {
                app2EmbeddedHolder.removeAllViews()
            }
        } catch (e: Exception) {}
    }

    val currentEmbeddedWeb: WebView?
        get() = currentWeb2

    fun closeEmbeddedApp() {
        detachEmbeddedWeb()
    }

    fun closeEmbeddedApp2() {
        detachEmbeddedWeb()
    }

    fun isEmbeddedAppShowing(): Boolean = (::app2EmbeddedContainer.isInitialized && app2EmbeddedContainer.visibility == View.VISIBLE)

    // ==========================================
    // THEME & APPS LIST
    // ==========================================

    fun applyDayNightMode(isDay: Boolean) {
        this.isDayMode = isDay
        updateDashboardBackground(isDay)

        // Nền thẻ kính mờ trong suốt nhẹ chuẩn theo ảnh mẫu
        // Sáng: media_1789114879718.png (#F1F1FB mờ trong suốt, viền #D2D4E3)
        // Tối: media_1789114840922.png (#24363F mờ trong suốt, viền #384F59)
        val cardBg = if (isDay) Color.parseColor("#EBF1F1FB") else Color.parseColor("#D924363F")
        val cardBorder = if (isDay) Color.parseColor("#D2D4E3") else Color.parseColor("#384F59")

        clockCard.background = rounded(cardBg, 18f, cardBorder, 1)
        musicCard.background = rounded(cardBg, 18f, cardBorder, 1)
        weatherCard.background = rounded(cardBg, 18f, cardBorder, 1)
        if (!isOverspeedAnimating) {
            speedCard.background = rounded(cardBg, 18f, cardBorder, 1)
        }
        if (::speedAlertDivider.isInitialized) {
            speedAlertDivider.setBackgroundColor(if (isDay) Color.parseColor("#CBD5E1") else Color.parseColor("#1E3A52"))
        }
        appsCard.background = rounded(cardBg, 18f, cardBorder, 1)

        clockText.setTextColor(if (isDay) Color.parseColor("#1E2538") else Color.WHITE)
        dateText.setTextColor(if (isDay) Color.parseColor("#475569") else Color.parseColor("#94A3B8"))

        if (isDay) {
            app2GridTitle.setTextColor(Color.parseColor("#475569"))

            mediaTitleText.setTextColor(Color.parseColor("#1E2538"))
            mediaArtistText.setTextColor(Color.parseColor("#64748B"))
            mediaCurTimeText.setTextColor(Color.parseColor("#64748B"))
            mediaDurTimeText.setTextColor(Color.parseColor("#64748B"))
            val bgTrack = rounded(Color.parseColor("#CBD5E1"), 2f)
            val progressFill = rounded(Color.parseColor("#2563EB"), 2f)
            val clipProgress = ClipDrawable(progressFill, Gravity.START, ClipDrawable.HORIZONTAL)
            mediaProgressBar.progressDrawable = android.graphics.drawable.LayerDrawable(arrayOf(bgTrack, clipProgress)).apply {
                setId(0, android.R.id.background)
                setId(1, android.R.id.progress)
            }
            mediaPrevBtn.setColorFilter(Color.parseColor("#0F172A"))
            mediaNextBtn.setColorFilter(Color.parseColor("#0F172A"))
            if (!CarMediaManager.trackState.value.isShuffleEnabled) {
                mediaShuffleBtn.setColorFilter(Color.parseColor("#475569"))
            }
            if (!CarMediaManager.trackState.value.isRepeatEnabled) {
                mediaRepeatBtn.setColorFilter(Color.parseColor("#475569"))
            }
            mediaAlbumArt.background = rounded(Color.parseColor("#E6E9F5"), 10f, Color.parseColor("#D2D4E3"), 1)

            weatherTempText.setTextColor(if (isDay) Color.parseColor("#1E2538") else Color.WHITE)
            weatherUnitText.setTextColor(if (isDay) Color.parseColor("#0284C7") else Color.parseColor("#38BDF8"))
            weatherLocationBadge.setTextColor(if (isDay) Color.parseColor("#475569") else Color.parseColor("#CBD5E1"))
            weatherHumidityChip.background = rounded(
                if (isDay) Color.parseColor("#F1F5F9") else Color.parseColor("#1E293B"),
                8f,
                if (isDay) Color.parseColor("#E2E8F0") else Color.parseColor("#334155"),
                1
            )
            weatherHumidityChip.setTextColor(if (isDay) Color.parseColor("#334155") else Color.parseColor("#94A3B8"))
            weatherWindChip.background = rounded(
                if (isDay) Color.parseColor("#F1F5F9") else Color.parseColor("#1E293B"),
                8f,
                if (isDay) Color.parseColor("#E2E8F0") else Color.parseColor("#334155"),
                1
            )
            weatherWindChip.setTextColor(if (isDay) Color.parseColor("#334155") else Color.parseColor("#94A3B8"))

            currentSpeedHolder.background = rounded(Color.parseColor("#E0E7FF"), 36f, Color.parseColor("#2563EB"), 3)
            currentSpeedBadge.setTextColor(Color.parseColor("#2563EB"))
            currentSpeedUnit.setTextColor(Color.parseColor("#3730A3"))
        } else {
            app2GridTitle.setTextColor(Color.parseColor("#94A3B8"))

            mediaTitleText.setTextColor(Color.WHITE)
            mediaArtistText.setTextColor(Color.parseColor("#A1A1AA"))
            mediaCurTimeText.setTextColor(Color.parseColor("#A1A1AA"))
            mediaDurTimeText.setTextColor(Color.parseColor("#A1A1AA"))
            val bgTrack = rounded(Color.parseColor("#3F3F46"), 2f)
            val progressFill = rounded(Color.WHITE, 2f)
            val clipProgress = ClipDrawable(progressFill, Gravity.START, ClipDrawable.HORIZONTAL)
            mediaProgressBar.progressDrawable = android.graphics.drawable.LayerDrawable(arrayOf(bgTrack, clipProgress)).apply {
                setId(0, android.R.id.background)
                setId(1, android.R.id.progress)
            }
            mediaPrevBtn.setColorFilter(Color.WHITE)
            mediaNextBtn.setColorFilter(Color.WHITE)
            if (!CarMediaManager.trackState.value.isShuffleEnabled) {
                mediaShuffleBtn.setColorFilter(Color.WHITE)
            }
            if (!CarMediaManager.trackState.value.isRepeatEnabled) {
                mediaRepeatBtn.setColorFilter(Color.WHITE)
            }
            mediaAlbumArt.background = rounded(Color.parseColor("#152236"), 10f, Color.parseColor("#2A4262"), 1)

            weatherTempText.setTextColor(Color.WHITE)
            weatherUnitText.setTextColor(Color.parseColor("#38BDF8"))
            weatherLocationBadge.setTextColor(Color.parseColor("#CBD5E1"))
            weatherHumidityChip.background = rounded(
                Color.parseColor("#1E293B"),
                8f,
                Color.parseColor("#334155"),
                1
            )
            weatherHumidityChip.setTextColor(Color.parseColor("#94A3B8"))
            weatherWindChip.background = rounded(
                Color.parseColor("#1E293B"),
                8f,
                Color.parseColor("#334155"),
                1
            )
            weatherWindChip.setTextColor(Color.parseColor("#94A3B8"))

            currentSpeedHolder.background = rounded(Color.parseColor("#182A33"), 36f, Color.parseColor("#10B981"), 3)
            currentSpeedBadge.setTextColor(Color.parseColor("#38BDF8"))
            currentSpeedUnit.setTextColor(Color.parseColor("#94A3B8"))
        }

        if (::allAppsBtn.isInitialized) {
            allAppsBtn.setTextColor(if (isDay) Color.parseColor("#2563EB") else Color.parseColor("#38BDF8"))
        }
        if (::app2EmbeddedContainer.isInitialized) {
            app2EmbeddedHolder.background = rounded(
                if (isDay) Color.parseColor("#F4F5FD") else Color.parseColor("#162329"),
                12f,
                if (isDay) Color.parseColor("#D2D4E3") else Color.parseColor("#384F59"),
                1
            )
            app2EmbeddedTitle.setTextColor(if (isDay) Color.parseColor("#1E2538") else Color.WHITE)
            val btnBg = rounded(if (isDay) Color.parseColor("#E6E9F5") else Color.parseColor("#1F3038"), 8f, if (isDay) Color.parseColor("#D2D4E3") else Color.parseColor("#384F59"), 1)
            val btnTextColor = if (isDay) Color.parseColor("#1E2538") else Color.WHITE
            if (::app2HomeBtn.isInitialized) {
                app2HomeBtn.background = btnBg
                app2HomeBtn.setTextColor(btnTextColor)
            }
            app2BackBtn.background = btnBg
            app2BackBtn.setTextColor(btnTextColor)
            app2ReloadBtn.background = btnBg
            app2ReloadBtn.setTextColor(btnTextColor)
            app2FsBtn.background = btnBg
            app2FsBtn.setTextColor(btnTextColor)
            if (::app2ChannelsBtn.isInitialized) {
                app2ChannelsBtn.background = btnBg
                app2ChannelsBtn.setTextColor(btnTextColor)
            }
            if (::app2FitBtn.isInitialized) {
                app2FitBtn.background = btnBg
                app2FitBtn.setTextColor(btnTextColor)
            }
        }
        if (::app2Dot1.isInitialized) {
            app2Dot1.background = rounded(if (isDay) Color.parseColor("#2563EB") else Color.parseColor("#38BDF8"), 3f, Color.TRANSPARENT, 0)
            app2Dot2.background = rounded(if (isDay) Color.parseColor("#D2D4E3") else Color.parseColor("#384F59"), 2.5f, Color.TRANSPARENT, 0)
            app2Dot3.background = rounded(if (isDay) Color.parseColor("#D2D4E3") else Color.parseColor("#384F59"), 2.5f, Color.TRANSPARENT, 0)
        }

        currentWeb2?.let { YouTubePlayerHelper.applyUniversalWebTheme(it, isDay) }

        refreshAppsList()
    }

    /**
     * Renders Favorite Apps Grid (Card 5).
     * NOTE: As requested by the user, the "+ Thêm" button is COMPLETELY REMOVED from the car screen.
     * All app additions/modifications are managed on the mobile phone SettingsActivity.
     */
    fun refreshAppsList() {
        app2RowsContainer.removeAllViews()
        val allApps = WebAppManager.getEnabledApps(context)
        // Display up to 5 favorite apps in a clean, elegant row
        val apps = allApps.take(5)

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        for (app in apps) {
            row.addView(createAppCell(app), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }

        app2RowsContainer.addView(row)
    }

    private fun createAppCell(app: WebAppItem): View {
        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(2), dp(4), dp(2))

            val iconBox = FrameLayout(context).apply {
                layoutParams = LayoutParams(dp(60), dp(60))
                val bgCol = try { Color.parseColor(app.colorHex) } catch (e: Exception) { Color.parseColor("#2D9CDB") }
                background = rounded(bgCol, 18f, Color.TRANSPARENT, 0)

                val iv = ImageView(context).apply {
                    if (!app.iconPath.isNullOrBlank() && File(app.iconPath).exists()) {
                        val bmp = BitmapFactory.decodeFile(app.iconPath)
                        if (bmp != null) setImageBitmap(bmp) else setImageResource(app.iconRes)
                    } else {
                        setImageResource(app.iconRes)
                    }
                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                    setPadding(dp(10), dp(10), dp(10), dp(10))
                }
                addView(iv, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
            addView(iconBox)

            val nameLabel = TextView(context).apply {
                text = app.name
                textSize = 12.5f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (isDayMode) Color.parseColor("#1E2538") else Color.WHITE)
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = dp(5)
                }
            }
            addView(nameLabel)

            setOnClickListener {
                onAppClick(app)
            }

            setOnLongClickListener {
                if (!app.isBuiltIn) {
                    showDeleteConfirmDialog(app)
                    true
                } else false
            }
        }
    }

    private fun createAddCell(): View {
        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(2), dp(4), dp(2))

            val iconBox = FrameLayout(context).apply {
                layoutParams = LayoutParams(dp(58), dp(58))
                background = rounded(
                    if (isDayMode) Color.parseColor("#E8F5E9") else Color.parseColor("#1B2D24"),
                    16f,
                    if (isDayMode) Color.parseColor("#81C784") else Color.parseColor("#2E7D32"),
                    1
                )

                val iconView = ImageView(context).apply {
                    setImageResource(android.R.drawable.ic_input_add)
                    setColorFilter(if (isDayMode) Color.parseColor("#2E7D32") else Color.parseColor("#4CAF50"))
                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                    setPadding(dp(13), dp(13), dp(13), dp(13))
                }
                addView(iconView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
            addView(iconBox)

            val nameLabel = TextView(context).apply {
                text = "+ Thêm"
                textSize = 12.5f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(if (isDayMode) Color.parseColor("#2E7D32") else Color.parseColor("#81C784"))
                gravity = Gravity.CENTER
                maxLines = 1
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = dp(5)
                }
            }
            addView(nameLabel)

            setOnClickListener {
                onAddAppClick()
            }
        }
    }

    private fun showDeleteConfirmDialog(app: WebAppItem) {
        hideDeleteConfirmDialog()
        val overlay = FrameLayout(context).apply {
            setBackgroundColor(Color.parseColor("#CC000000"))
            isClickable = true
            isFocusable = true
        }

        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = rounded(Color.parseColor("#1E2838"), 16f, Color.parseColor("#37474F"), 1)
            setPadding(dp(20), dp(18), dp(20), dp(18))
            layoutParams = FrameLayout.LayoutParams(dp(300), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER)

            val iconBox = FrameLayout(context).apply {
                layoutParams = LayoutParams(dp(46), dp(46)).apply { bottomMargin = dp(10) }
                val bgCol = try { Color.parseColor(app.colorHex) } catch (e: Exception) { Color.parseColor("#2D9CDB") }
                background = rounded(bgCol, 12f, Color.TRANSPARENT, 0)

                val iv = ImageView(context).apply {
                    if (!app.iconPath.isNullOrBlank() && File(app.iconPath).exists()) {
                        val bmp = BitmapFactory.decodeFile(app.iconPath)
                        if (bmp != null) setImageBitmap(bmp) else setImageResource(app.iconRes)
                    } else {
                        setImageResource(app.iconRes)
                    }
                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                }
                addView(iv, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
            addView(iconBox)

            val title = TextView(context).apply {
                text = "X\u00F3a \u1EE9ng d\u1EE5ng \"${app.name}\"?"
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(4)
                }
            }
            addView(title)

            val desc = TextView(context).apply {
                text = "\u1EE8ng d\u1EE5ng n\u00E0y s\u1EBD \u0111\u01B0\u1EE3c x\u00F3a kh\u1ECFi m\u00E0n h\u00ECnh ch\u00EDnh c\u1EE7a xe."
                textSize = 11.5f
                setTextColor(Color.parseColor("#B0BEC5"))
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(14)
                }
            }
            addView(desc)

            val btnRow = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

                val cancelBtn = TextView(context).apply {
                    text = "\u2715 H\u1EE7y b\u1ECF"
                    textSize = 12.5f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    background = rounded(Color.parseColor("#263238"), 10f, Color.TRANSPARENT, 0)
                    setPadding(dp(14), dp(8), dp(14), dp(8))
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        rightMargin = dp(6)
                    }
                    setOnClickListener { hideDeleteConfirmDialog() }
                }
                addView(cancelBtn)

                val deleteBtn = TextView(context).apply {
                    text = "\uD83D\uDDD1\uFE0F X\u00F3a ngay"
                    textSize = 12.5f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    background = rounded(Color.parseColor("#D32F2F"), 10f, Color.TRANSPARENT, 0)
                    setPadding(dp(14), dp(8), dp(14), dp(8))
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.2f)
                    setOnClickListener {
                        WebAppManager.deleteApp(context, app.id)
                        refreshAppsList()
                        hideDeleteConfirmDialog()
                        Toast.makeText(context, "\u0110\u00E3 x\u00F3a \u1EE9ng d\u1EE5ng ${app.name}", Toast.LENGTH_SHORT).show()
                    }
                }
                addView(deleteBtn)
            }
            addView(btnRow)
        }

        overlay.addView(card)
        addView(overlay, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        deleteConfirmOverlay = overlay
    }

    private fun hideDeleteConfirmDialog() {
        deleteConfirmOverlay?.let {
            removeView(it)
            deleteConfirmOverlay = null
        }
    }

    // ==========================================
    // LIVE STREAMS & DATA UPDATES
    // ==========================================

    private fun startLiveStreams() {
        // Live Clock ticker (Giờ : Phút 54sp bold)
        val timeRunnable = object : Runnable {
            override fun run() {
                val now = Date()
                val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
                clockText.text = timeStr
                dateText.text = VietnameseLunarHelper.getFormattedDateWithLunar()
                timeHandler.postDelayed(this, 1000)
            }
        }
        timeHandler.post(timeRunnable)

        // GPS location sync for Weather
        coroutineScope.launch {
            GpsSpeedManager.lastLocation.collectLatest { loc ->
                loc?.let {
                    WeatherManager.updateFromLocation(context, it)
                }
            }
        }

        // Weather live stream
        WeatherManager.start(context)
        coroutineScope.launch {
            WeatherManager.weatherState.collectLatest { weather ->
                weatherIconText.text = weather.iconEmoji
                weatherTempText.text = weather.tempC.toString()
                weatherLocationBadge.text = "📍 ${weather.location}"
                weatherHumidityChip.text = "💧 ${weather.humidity}%"
                weatherWindChip.text = "🍃 ${weather.windSpeedKmh} km/h"
            }
        }

        // Car Media live stream
        coroutineScope.launch {
            CarMediaManager.trackState.collectLatest { track ->
                val newTitle = if (track.title.isNotBlank()) track.title else "Chưa phát nhạc"
                val newArtist = if (track.artist.isNotBlank()) track.artist else "T-Car Music"
                if (mediaTitleText.text != newTitle) mediaTitleText.text = newTitle
                if (mediaArtistText.text != newArtist) mediaArtistText.text = newArtist

                val curM = track.currentPositionSec / 60
                val curS = track.currentPositionSec % 60
                val durM = track.currentDurationSec / 60
                val durS = track.currentDurationSec % 60
                val newCurText = String.format(Locale.US, "%d:%02d", curM, curS)
                val newDurText = if (track.currentDurationSec > 0) String.format(Locale.US, "%d:%02d", durM, durS) else "0:00"

                if (mediaCurTimeText.text != newCurText) mediaCurTimeText.text = newCurText
                if (mediaDurTimeText.text != newDurText) mediaDurTimeText.text = newDurText
                if (mediaProgressBar.progress != track.progressPercent) mediaProgressBar.progress = track.progressPercent

                mediaPlayPauseIcon.setImageResource(if (track.isPlaying) R.drawable.ic_player_pause else R.drawable.ic_player_play)

                mediaShuffleBtn.setColorFilter(if (track.isShuffleEnabled) Color.parseColor("#1DB954") else (if (isDayMode) Color.parseColor("#475569") else Color.WHITE))
                mediaRepeatBtn.setColorFilter(if (track.isRepeatEnabled) Color.parseColor("#1DB954") else (if (isDayMode) Color.parseColor("#475569") else Color.WHITE))

                if (track.artworkBitmap != null) {
                    mediaAlbumImageView.setImageBitmap(track.artworkBitmap)
                    mediaAlbumImageView.visibility = VISIBLE
                    mediaAlbumIcon.visibility = View.GONE
                } else {
                    mediaAlbumImageView.visibility = View.GONE
                    mediaAlbumIcon.visibility = View.VISIBLE
                }
            }

        }

        // Speed & Waze Mod Live Alert stream (with Vietnamese TTS voice readout)
        coroutineScope.launch {
            VietmapStateRepository.alertState.collectLatest { data ->
                val vSpeed = data.currentSpeed
                val isFresh = data.isLiveFresh || (data.isConnected && vSpeed > 0)
                val displaySpeed = if (isFresh && vSpeed > 0) vSpeed else GpsSpeedManager.rawGpsSpeed.value

                currentSpeedBadge.text = displaySpeed.toString()

                val rawLimit = data.speedLimit
                val hasLimit = rawLimit != null && rawLimit > 0
                val targetMargin = if (hasLimit) dp(6) else 0
                val lpHolder = currentSpeedHolder.layoutParams as? LinearLayout.LayoutParams
                if (lpHolder != null && lpHolder.leftMargin != targetMargin) {
                    lpHolder.leftMargin = targetMargin
                    currentSpeedHolder.layoutParams = lpHolder
                }
                if (hasLimit) {
                    speedLimitBadge.text = rawLimit.toString()
                    speedLimitBadge.visibility = View.VISIBLE
                } else {
                    speedLimitBadge.text = ""
                    speedLimitBadge.visibility = View.GONE
                }

                val masterEnabled = WazeHudManager.isMasterAlertsEnabled(context)
                val overspeedAlertEnabled = WazeHudManager.isOverspeedAlertEnabled(context)
                val cameraEnabled = WazeHudManager.isSpeedCameraEnabled(context)

                val isOverSpeed = rawLimit != null && rawLimit > 0 && displaySpeed > rawLimit && masterEnabled && overspeedAlertEnabled
                if (isOverSpeed) {
                    startOverspeedFlash()
                    currentSpeedBadge.setTextColor(Color.parseColor("#FF1744"))
                    currentSpeedHolder.background = rounded(
                        if (isDayMode) Color.parseColor("#FEE2E2") else Color.parseColor("#40FF1744"),
                        30f,
                        Color.parseColor("#FF1744"),
                        2
                    )
                    currentSpeedUnit.setTextColor(Color.parseColor("#FF1744"))
                } else {
                    stopOverspeedFlash()
                    currentSpeedBadge.setTextColor(if (isDayMode) Color.parseColor("#0284C7") else Color.parseColor("#00E5FF"))
                    currentSpeedHolder.background = rounded(
                        if (isDayMode) Color.parseColor("#E0F2FE") else Color.parseColor("#102838"),
                        30f,
                        if (isDayMode) Color.parseColor("#0284C7") else Color.parseColor("#10B981"),
                        2
                    )
                    currentSpeedUnit.setTextColor(if (isDayMode) Color.parseColor("#0369A1") else Color.parseColor("#8E9CAE"))
                }

                val warning = data.warningType
                val rawAlertTitle = data.alertTitle?.replace("VML-TPMS", "")?.replace("TPMS", "")?.trim()
                val cleanAlertTitle = if (rawAlertTitle != null && !WazeHlpWebSocketManager.isIgnoredText(rawAlertTitle)) rawAlertTitle else null

                val effWarning = when {
                    warning != VietmapWarningType.NONE -> warning
                    !cleanAlertTitle.isNullOrBlank() -> WazeHlpWebSocketManager.mapWarningType(cleanAlertTitle)
                    else -> VietmapWarningType.NONE
                }

                val isAlertFresh = data.alertTimestamp > 0L && (System.currentTimeMillis() - data.alertTimestamp < 10000L)
                val hasCameraAlert = (effWarning != VietmapWarningType.NONE) && masterEnabled && cameraEnabled && isAlertFresh
                val isTurnEnabled = masterEnabled && WazeHudManager.isTurnManeuverEnabled(context)
                val isNavigating = isTurnEnabled && (data.distanceToTurnMeters > 0 || data.turnCode > 0 || !data.turnDescription.isNullOrBlank())
                val cleanRoad = if (!data.roadName.isNullOrBlank() && !WazeHlpWebSocketManager.isIgnoredText(data.roadName)) data.roadName else null

                val hasActiveAlert = isOverSpeed || hasCameraAlert || isNavigating
                if (hasActiveAlert) {
                    speedAlertDivider.visibility = View.VISIBLE
                    alertContainer.visibility = View.VISIBLE
                    alertActiveBox.visibility = View.VISIBLE
                    alertActiveBox.background = null
                    speedCard.gravity = Gravity.CENTER_VERTICAL or Gravity.START
                } else {
                    speedAlertDivider.visibility = View.GONE
                    alertContainer.visibility = View.GONE
                    alertActiveBox.visibility = View.GONE
                    speedCard.gravity = Gravity.CENTER
                }

                if (isOverSpeed) {
                    // Ưu tiên 1: Quá tốc độ giới hạn
                    alertIconBox.background = rounded(
                        if (isDayMode) Color.parseColor("#FEE2E2") else Color.parseColor("#FF0F172A"),
                        16f,
                        Color.parseColor("#FF1744"),
                        3
                    )
                    alertIconText.text = "⚡"
                    alertIconText.textSize = 30f
                    alertSourceBadge.text = "CẢNH BÁO QUÁ TỐC ĐỘ"
                    alertSourceBadge.textSize = 13f
                    alertSourceBadge.typeface = Typeface.DEFAULT_BOLD
                    alertSourceBadge.setTextColor(Color.parseColor("#FF1744"))
                    alertTitleText.text = "VƯỢT QUÁ TỐC ĐỘ CHO PHÉP!"
                    alertTitleText.textSize = 17f
                    alertTitleText.typeface = Typeface.DEFAULT_BOLD
                    alertTitleText.setTextColor(if (isDayMode) Color.parseColor("#991B1B") else Color.WHITE)
                    alertRoadText.text = "Vui lòng giảm tốc độ dưới $rawLimit km/h"
                    alertRoadText.textSize = 13.5f
                    alertRoadText.setTextColor(if (isDayMode) Color.parseColor("#7F1D1D") else Color.parseColor("#E2E8F0"))
                    alertDistBadge.visibility = View.GONE
                } else if (hasCameraAlert) {
                    // Ưu tiên 2: Cảnh báo camera phạt nguội / mối nguy hiểm thực sự từ Waze
                    val accentColor = Color.parseColor(effWarning.accentColor)

                    alertIconBox.background = rounded(
                        if (isDayMode) Color.parseColor("#FFFFFF") else Color.parseColor("#FF0F172A"),
                        16f,
                        accentColor,
                        3
                    )
                    alertIconText.text = effWarning.iconEmoji
                    alertIconText.textSize = 30f
                    alertSourceBadge.text = effWarning.category
                    alertSourceBadge.textSize = 13f
                    alertSourceBadge.typeface = Typeface.DEFAULT_BOLD
                    alertSourceBadge.setTextColor(accentColor)
                    alertTitleText.text = cleanAlertTitle ?: effWarning.label
                    alertTitleText.textSize = 17f
                    alertTitleText.typeface = Typeface.DEFAULT_BOLD
                    alertTitleText.setTextColor(if (isDayMode) Color.parseColor("#0F172A") else Color.WHITE)
                    alertRoadText.text = cleanRoad ?: "Đoạn đường có giám sát an toàn"
                    alertRoadText.textSize = 13.5f
                    alertRoadText.setTextColor(if (isDayMode) Color.parseColor("#334155") else Color.parseColor("#E2E8F0"))

                    val distVal = if (!data.distanceText.isNullOrBlank()) {
                        data.distanceText
                    } else if (data.distanceMeters != null && data.distanceMeters > 0) {
                        "${data.distanceMeters}m"
                    } else {
                        null
                    }

                    if (!distVal.isNullOrBlank()) {
                        val cleanDist = if (distVal.endsWith("m") || distVal.endsWith("km")) distVal else "${distVal}m"
                        alertDistBadge.text = "📍 Cách $cleanDist"
                        alertDistBadge.textSize = 13.5f
                        alertDistBadge.typeface = Typeface.DEFAULT_BOLD
                        alertDistBadge.setTextColor(Color.WHITE)
                        alertDistBadge.background = rounded(accentColor, 8f)
                        alertDistBadge.visibility = View.VISIBLE
                    } else {
                        alertDistBadge.visibility = View.GONE
                    }
                } else if (isNavigating) {
                    // Ưu tiên 3: Điều hướng lộ trình Waze Mod (Mũi tên QCVN 41:2019 + khoảng cách ngã rẽ)
                    val arrowStr = when {
                        data.turnCode in listOf(2, 9) || data.turnAction in listOf("turn-left", "sharp-left", "left") -> "↰"
                        data.turnCode in listOf(3, 10) || data.turnAction in listOf("turn-right", "sharp-right", "right") -> "↱"
                        data.turnCode in listOf(4, 12) || data.turnAction in listOf("slight-left", "keep-left", "exit-left") -> "↖"
                        data.turnCode in listOf(5, 13) || data.turnAction in listOf("slight-right", "keep-right", "exit-right") -> "↗"
                        data.turnCode == 8 || data.turnAction in listOf("u-turn", "uturn") -> "↩"
                        data.turnCode in listOf(6, 7) || data.turnAction == "roundabout" -> "🔄"
                        data.turnCode == 11 || data.turnAction == "destination" -> "🏁"
                        else -> "↑"
                    }

                    alertIconBox.background = rounded(
                        if (isDayMode) Color.parseColor("#E0F2FE") else Color.parseColor("#1B2E38"),
                        16f,
                        Color.parseColor("#06B6D4"),
                        1
                    )
                    alertIconText.text = arrowStr
                    alertIconText.setTextColor(if (isDayMode) Color.parseColor("#0284C7") else Color.parseColor("#00E5FF"))
                    alertSourceBadge.text = "ĐIỀU HƯỚNG WAZE"
                    alertSourceBadge.setTextColor(Color.parseColor("#06B6D4"))

                    val turnTitle = when {
                        !data.turnDescription.isNullOrBlank() -> data.turnDescription
                        data.turnCode == 1 -> "Tiếp tục đi thẳng"
                        else -> "Lộ trình dẫn đường"
                    }
                    alertTitleText.text = turnTitle
                    alertTitleText.setTextColor(if (isDayMode) Color.parseColor("#0F172A") else Color.WHITE)

                    alertRoadText.text = cleanRoad ?: "Tiếp tục di chuyển theo lộ trình"
                    alertRoadText.setTextColor(if (isDayMode) Color.parseColor("#64748B") else Color.parseColor("#94A3B8"))

                    val distM = data.distanceToTurnMeters
                    if (distM > 0) {
                        val distFormatted = if (distM >= 1000) String.format(java.util.Locale.US, "%.1f km", distM / 1000f) else "${distM}m"
                        alertDistBadge.text = "📍 Cách $distFormatted"
                        alertDistBadge.background = rounded(Color.parseColor("#0284C7"), 7f)
                        alertDistBadge.visibility = View.VISIBLE
                    } else {
                        alertDistBadge.visibility = View.GONE
                    }
                }
            }
        }

        // GPS speed fallback
        coroutineScope.launch {
            GpsSpeedManager.rawGpsSpeed.collectLatest { gpsSpeed ->
                val vState = VietmapStateRepository.alertState.value
                if (!vState.isLiveFresh || vState.currentSpeed == 0) {
                    currentSpeedBadge.text = gpsSpeed.toString()
                }
            }
        }

        refreshAppsList()
    }

    private val currentCardBg: Int
        get() = if (isDayMode) Color.parseColor("#EBF1F1FB") else Color.parseColor("#D924363F")

    private val currentCardBorder: Int
        get() = if (isDayMode) Color.parseColor("#D2D4E3") else Color.parseColor("#384F59")

    private fun startOverspeedFlash() {
        if (isOverspeedAnimating) return
        isOverspeedAnimating = true

        val normalBg = currentCardBg
        val normalBorder = currentCardBorder
        val warningBg = Color.parseColor("#59DC2626") // Nền đỏ cảnh báo (~35% alpha)
        val warningBorder = Color.parseColor("#FF1744") // Viền đỏ rực

        overspeedAnimator?.cancel()
        overspeedAnimator = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 450L
            repeatMode = android.animation.ValueAnimator.REVERSE
            repeatCount = android.animation.ValueAnimator.INFINITE
            addUpdateListener { anim ->
                val fraction = anim.animatedValue as Float
                val curBg = blendColors(normalBg, warningBg, fraction)
                val curBorder = blendColors(normalBorder, warningBorder, fraction)
                val curBorderWidth = (1f + 2f * fraction).toInt()
                speedCard.background = rounded(curBg, 18f, curBorder, curBorderWidth)
            }
            start()
        }
    }

    private fun stopOverspeedFlash() {
        if (!isOverspeedAnimating && overspeedAnimator == null) return
        isOverspeedAnimating = false
        overspeedAnimator?.cancel()
        overspeedAnimator = null
        speedCard.background = rounded(currentCardBg, 18f, currentCardBorder, 1)
    }

    private fun blendColors(from: Int, to: Int, ratio: Float): Int {
        val inverseRatio = 1f - ratio
        val a = (Color.alpha(from) * inverseRatio + Color.alpha(to) * ratio).toInt()
        val r = (Color.red(from) * inverseRatio + Color.red(to) * ratio).toInt()
        val g = (Color.green(from) * inverseRatio + Color.green(to) * ratio).toInt()
        val b = (Color.blue(from) * inverseRatio + Color.blue(to) * ratio).toInt()
        return Color.argb(a, r, g, b)
    }

    override fun scrollTo(x: Int, y: Int) {
        // Cố định màn hình chính, luôn giữ tại tọa độ (0, 0)
        super.scrollTo(0, 0)
    }

    override fun scrollBy(x: Int, y: Int) {
        // Tuyệt đối không cho phép cuộn hay dịch chuyển màn hình chính
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stopOverspeedFlash()
        coroutineScope.cancel()
        timeHandler.removeCallbacksAndMessages(null)
    }
}