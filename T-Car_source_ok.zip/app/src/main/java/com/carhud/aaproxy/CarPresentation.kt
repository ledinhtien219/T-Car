package com.carhud.aaproxy

import com.carhud.app.R
import android.annotation.SuppressLint
import android.app.ActivityOptions
import android.app.PendingIntent
import android.app.Presentation
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.*
import androidx.core.content.ContextCompat
import android.text.InputType
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import java.io.ByteArrayInputStream
import kotlin.math.roundToInt

class CarPresentation(
    context: Context,
    display: Display,
    existingWebView: WebView? = null
) : Presentation(android.view.ContextThemeWrapper(context, R.style.Theme_CarHud), display, R.style.Theme_CarHud), SharedPreferences.OnSharedPreferenceChangeListener {

    private var web: WebView = existingWebView ?: WebView(try { context.createDisplayContext(display) } catch (e: Exception) { context })
    private lateinit var root: FrameLayout
    private var sidebarContainer: View? = null
    private var sidebarView: LinearLayout? = null
    private lateinit var statusBanner: TextView
    private var micBtn: ImageView? = null
    private var playPauseBtn: ImageView? = null
    private var isCurrentlyPlaying = false
    private lateinit var searchOverlay: FrameLayout
    private lateinit var searchInput: EditText
    private var topToolbarContainer: View? = null
    private var appGridOverlay: FrameLayout? = null
    private var appGridPanel: LinearLayout? = null
    private var appGridPosToggleBtn: TextView? = null
    private var appGridSizeBtn: TextView? = null
    private var addAppOverlay: FrameLayout? = null
    private var addAppNameInput: EditText? = null
    private var addAppUrlInput: EditText? = null
    private var addAppDesktopCheck: CheckBox? = null
    private var addAppIconPreview: ImageView? = null
    private var downloadedFaviconBitmap: Bitmap? = null
    private var dashboardView: CarDashboardView? = null
    private var isDashboardShowing = true
    private var currentActiveAppId: String = "youtube"
    private val mainHandler = Handler(Looper.getMainLooper())

    // Prevent repeated play/resume commands when Android Auto recreates the surface
    // or YouTube briefly reports a paused/buffering state.
    private var autoResumePending = false

    companion object {
        @Volatile
        private var lastGlobalAutoResumeAt = 0L
    }

    private fun scheduleSafeResume(target: WebView, delayMs: Long = 500L) {
        if (autoResumePending) return
        if (!CarMediaManager.userWantsPlayback || CarMediaManager.isPlaying) return

        val now = SystemClock.uptimeMillis()
        if (now - lastGlobalAutoResumeAt < 3000L) return

        autoResumePending = true
        target.postDelayed({
            autoResumePending = false

            val currentUrl = target.url.orEmpty()
            val isYouTubeWatch = currentUrl.contains("youtube.com/watch") ||
                currentUrl.contains("m.youtube.com/watch") ||
                currentUrl.contains("youtu.be/")

            if (isYouTubeWatch &&
                CarMediaManager.userWantsPlayback &&
                !CarMediaManager.isPlaying
            ) {
                lastGlobalAutoResumeAt = SystemClock.uptimeMillis()
                YouTubePlayerHelper.resumePlayback(target)
            }
        }, delayMs)
    }

    private var isUltrawide = false
    private var isPortrait = false
    private var carWidth = 0
    private var carHeight = 0
    private var carDpi = 160
    private var phoneDpi = 160f
    private var aspectRatio = 1.777f
    private val prefs: SharedPreferences by lazy {
        context.getSharedPreferences(SettingsActivity.PREFS, Context.MODE_PRIVATE)
    }
    private var hudOverlay: VietmapHudOverlay? = null
    private val hudPrefs: SharedPreferences by lazy {
        context.getSharedPreferences("waze_hud_settings_prefs", Context.MODE_PRIVATE)
    }
    private val hudPrefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        mainHandler.post {
            updateHudOverlay()
        }
    }

    private val searchLiveTextListener: (String) -> Unit = { text ->
        mainHandler.post {
            if (::searchInput.isInitialized && searchInput.text.toString() != text) {
                searchInput.setText(text)
                searchInput.setSelection(text.length)
            }
        }
    }

    private val voiceManager = VoiceSearchManager(
        context = context,
        onResult = { query ->
            mainHandler.post {
                handleVoiceQuery(query)
            }
        },
        onStateChanged = { state, text ->
            mainHandler.post {
                if (state == VoiceSearchManager.State.LISTENING || state == VoiceSearchManager.State.RECOGNIZING) {
                    YouTubePlayerHelper.setDuckingVolume(web, 0.0f)
                } else if (state == VoiceSearchManager.State.IDLE || state == VoiceSearchManager.State.ERROR || state == VoiceSearchManager.State.SUCCESS) {
                    YouTubePlayerHelper.setDuckingVolume(web, 1.0f)
                }
                updateVoiceState(state, text)
                if (state == VoiceSearchManager.State.LISTENING) {
                    searchInput.hint = "🎙️ Đang lắng nghe... Nói tên bài hát"
                } else if (state == VoiceSearchManager.State.RECOGNIZING) {
                    if (text.startsWith("🎙️ ")) {
                        val partial = text.removePrefix("🎙️ ").trim()
                        if (partial.isNotEmpty()) {
                            searchInput.setText(partial)
                            searchInput.setSelection(partial.length)
                        }
                    } else {
                        searchInput.hint = "🎙️ Đang nhận diện: $text"
                    }
                } else if (state == VoiceSearchManager.State.ERROR) {
                    searchInput.hint = "⚠️ $text - Gõ bàn phím bên dưới để tìm"
                }
                CarMediaManager.notifyVoiceState(state, text)
            }
        }
    )

    private val voiceListener: (VoiceSearchManager.State, String) -> Unit = { state, text ->
        mainHandler.post {
            updateVoiceState(state, text)
        }
    }

    private val searchQueryListener: (String) -> Unit = { query ->
        mainHandler.post {
            searchInput.setText(query)
            searchInput.setSelection(query.length)
            if (isDashboardShowing) {
                showWebFullscreen()
            }
            YouTubePlayerHelper.search(web, query)
            hideSearchOverlay(notifyPhone = false)
        }
    }

    private val searchDismissListener: () -> Unit = {
        mainHandler.post {
            hideSearchOverlay(notifyPhone = false)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CarMediaManager.activeVoiceManager = voiceManager
        voiceManager.prewarm()
        CarMediaManager.registerVoiceListener(voiceListener)
        CarMediaManager.registerSearchQueryListener(searchQueryListener)
        CarMediaManager.registerSearchDismissListener(searchDismissListener)
        CarMediaManager.registerSearchLiveTextListener(searchLiveTextListener)

        try {
            GpsSpeedManager.start(context)
        } catch (e: Exception) {}

        // Force Presentation to fill the entire VirtualDisplay & enable device keyboard (IME)
        window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        window?.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        window?.decorView?.setBackgroundColor(Color.BLACK)
        try {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM)
        } catch (e: Exception) {}
        // Chromium WebView natively manages AudioFocus; do not call requestAudioFocus here.
        prefs.registerOnSharedPreferenceChangeListener(this)

        root = FrameLayout(context).apply {
            setBackgroundColor(Color.BLACK)
        }

        // Auto-detect car screen metrics and form-factor
        val metrics = android.util.DisplayMetrics()
        display.getRealMetrics(metrics)
        carWidth = if (metrics.widthPixels > 0) metrics.widthPixels else 800
        carHeight = if (metrics.heightPixels > 0) metrics.heightPixels else 480
        carDpi = if (metrics.densityDpi > 0) metrics.densityDpi else 160
        aspectRatio = if (carHeight > 0) carWidth.toFloat() / carHeight.toFloat() else 1.777f

        isUltrawide = (aspectRatio >= 1.85f)
        isPortrait = (aspectRatio < 0.95f)

        // 1. YouTube WebView (Detach from old parent if any)
        (web.parent as? ViewGroup)?.removeView(web)
        
        // Calculate the scale difference to fix UI sizing on Android Auto
        phoneDpi = web.context.applicationContext.resources.displayMetrics.densityDpi.toFloat()
        applyWebScaleForUrl(web.url)

        // ALWAYS configure webview performance & initial theme background
        val initIsDay = isDayMode()
        web.setBackgroundColor(if (initIsDay) Color.WHITE else Color.BLACK)
        YouTubePlayerHelper.applyUltraPerformance(web)

        // Apply scaling & responsive layout immediately to the active WebView
        YouTubePlayerHelper.inject(web, isUltrawide, isPortrait, carWidth, carHeight, carDpi, phoneDpi.toInt(), aspectRatio)
        YouTubePlayerHelper.applyTheme(web, initIsDay)

        try {
            web.removeJavascriptInterface("AndroidVoice")
        } catch (e: Exception) {}

        web.addJavascriptInterface(object {
            @JavascriptInterface
            fun isAuto(): Boolean = true

            @JavascriptInterface
            fun onUserTouch() {
                mainHandler.post {
                    showBars()
                }
            }

            @JavascriptInterface
            fun onPlaybackStateChanged(playing: Boolean) {
                mainHandler.post {
                    setPlaybackState(playing)
                    CarMediaManager.setPlaybackState(playing)
                }
            }

            @JavascriptInterface
            fun onTrackChanged(title: String, artist: String) {
                mainHandler.post {
                    CarMediaManager.updateTrack(title, artist, null)
                }
            }

            @JavascriptInterface
            fun onTrackChanged(title: String, artist: String, thumbUrl: String) {
                mainHandler.post {
                    CarMediaManager.updateTrack(title, artist, thumbUrl)
                }
            }


            @JavascriptInterface
            fun onUserSelectedVideo(url: String) {
                CarMediaManager.userWantsPlayback = true
                CarMediaManager.saveLastPlayedUrl(context, url)
                mainHandler.post {
                    CarMediaManager.ensureAudioFocus()
                    CarMediaManager.acquireWakeLock(context)
                }
            }

            @JavascriptInterface
            fun saveLastPlayedUrl(url: String) {
                CarMediaManager.saveLastPlayedUrl(context, url)
            }

            @JavascriptInterface
            fun onVideoTimeUpdate(currentSec: Int, totalSec: Int, formattedTime: String) {
                mainHandler.post {
                    updateVideoProgress(currentSec, totalSec, formattedTime)
                    CarMediaManager.updatePlaybackProgress(currentSec, totalSec)
                }
            }

            @JavascriptInterface
            fun openSearchKeyboard() {
                mainHandler.post {
                    showSearchOverlay()
                }
            }

            @JavascriptInterface
            fun startListening() {
                mainHandler.post {
                    startVoiceSearch()
                }
            }

            @JavascriptInterface
            fun fetchSponsorSegments(videoId: String) {
                SponsorBlockManager.fetchSegments(videoId) { jsonString ->
                    mainHandler.post {
                        try {
                            val jsonLiteral = org.json.JSONObject.quote(jsonString)
                            web.evaluateJavascript("if (window.FermataSB && window.FermataSB.onSegmentsLoaded) { window.FermataSB.onSegmentsLoaded('$videoId', $jsonLiteral); }", null)
                        } catch (e: Exception) {}
                    }
                }
            }
        }, "AndroidVoice")

        web.addJavascriptInterface(object {
            @android.webkit.JavascriptInterface
            fun getChannelsJson(): String {
                return IptvManager.getCachedJson(context)
            }

            @android.webkit.JavascriptInterface
            fun getCustomUrl(): String {
                return IptvManager.getM3uUrl(context)
            }

            @android.webkit.JavascriptInterface
            fun saveCustomUrl(newUrl: String) {
                mainHandler.post {
                    IptvManager.setM3uUrl(context, newUrl)
                    IptvManager.refresh(context) { freshList ->
                        val arr = org.json.JSONArray()
                        for (ch in freshList) arr.put(ch.toJson())
                        web.evaluateJavascript("window.onChannelsUpdated('${arr.toString().replace("'", "\\'")}')", null)
                    }
                }
            }

            @android.webkit.JavascriptInterface
            fun saveCustomM3uString(fileName: String, content: String) {
                mainHandler.post {
                    IptvManager.setM3uContent(context, content, fileName)
                    IptvManager.refresh(context) { freshList ->
                        val arr = org.json.JSONArray()
                        for (ch in freshList) arr.put(ch.toJson())
                        web.evaluateJavascript("window.onChannelsUpdated('${arr.toString().replace("'", "\\'")}')", null)
                    }
                }
            }

            @android.webkit.JavascriptInterface
            fun refresh() {
                mainHandler.post {
                    IptvManager.refresh(context) { freshList ->
                        val arr = org.json.JSONArray()
                        for (ch in freshList) arr.put(ch.toJson())
                        web.evaluateJavascript("window.onChannelsUpdated('${arr.toString().replace("'", "\\'")}')", null)
                    }
                }
            }
        }, "AndroidIptv")

        IptvManager.getChannels(context) {}

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val target = request?.url?.toString() ?: return false
                if (target.startsWith("intent:") || 
                    target.startsWith("snssdk") || 
                    target.startsWith("market:") || 
                    target.contains("play.google.com/store")) {
                    return true // Block app redirect, stay in webview
                }
                return false
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                val target = url ?: return false
                if (target.startsWith("intent:") || 
                    target.startsWith("snssdk") || 
                    target.startsWith("market:") || 
                    target.contains("play.google.com/store")) {
                    return true
                }
                return false
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                YouTubeAdBlocker.shouldIntercept(request)?.let { return it }
                val url = request?.url?.toString()
                if (url != null && YouTubePlayerHelper.isAdUrl(url)) {
                    val origin = request.requestHeaders?.get("Origin") ?: request.requestHeaders?.get("origin")
                    return YouTubePlayerHelper.createEmptyResponse(origin)
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                val isDay = isDayMode()
                applyUniversalWebTheme(view, isDay)
                applyWebScaleForUrl(url)
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                CarMediaManager.currentLoadingUrl = null
                YouTubeAdBlocker.onPageFinished(view, url)
                applyWebScaleForUrl(url)
                val isDay = isDayMode()
                applyUniversalWebTheme(view, isDay)
                val isYouTube = url.contains("youtube.com") || url.contains("youtu.be")
                if (isYouTube) {
                    YouTubePlayerHelper.inject(view, isUltrawide, isPortrait, carWidth, carHeight, carDpi, phoneDpi.toInt(), aspectRatio)
                }
                val autoResume = prefs.getBoolean(SettingsActivity.KEY_AUTO_RESUME_LAST_TRACK, true)
                if (url.contains("watch")) {
                    // Never turn a transient buffering pause into a forced playback loop.
                    if (CarMediaManager.userWantsPlayback) {
                        CarMediaManager.ensureAudioFocus()
                        CarMediaManager.acquireWakeLock(context)
                        scheduleSafeResume(view, 700L)
                    }
                } else if (isYouTube && autoResume && CarMediaManager.userWantsPlayback && (url.endsWith("youtube.com") || url.endsWith("youtube.com/"))) {
                    CarMediaManager.ensureAudioFocus()
                    view.postDelayed({
                        if (!CarMediaManager.isPlaying && CarMediaManager.userWantsPlayback) {
                            YouTubePlayerHelper.playFirstAvailableVideo(view)
                        }
                    }, 800L)
                }
            }
        }

        web.setBackgroundColor(Color.BLACK)
        web.visibility = View.VISIBLE

        var customView: View? = null
        var customViewCallback: WebChromeClient.CustomViewCallback? = null

        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.grant(request.resources)
            }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                web.visibility = View.GONE
                sidebarContainer?.visibility = View.GONE
                topToolbarContainer?.visibility = View.GONE
                root.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }

            override fun onHideCustomView() {
                if (customView == null) return
                root.removeView(customView)
                customView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
                web.visibility = View.VISIBLE
                showBars()
                try {
                    web.evaluateJavascript(
                        """
                        (function() {
                            document.documentElement.classList.remove('carhud-force-fullscreen');
                            document.body.classList.remove('carhud-force-fullscreen');
                            var v = document.querySelector('video');
                            if (v) {
                                v.removeAttribute('data-carhud-styled');
                                v.style.removeProperty('position');
                                v.style.removeProperty('top');
                                v.style.removeProperty('left');
                                v.style.removeProperty('right');
                                v.style.removeProperty('bottom');
                                v.style.removeProperty('width');
                                v.style.removeProperty('height');
                                v.style.removeProperty('margin');
                                v.style.removeProperty('object-fit');
                                v.style.removeProperty('z-index');
                                if (v.paused) { try { v.play(); } catch(e){} }
                            }
                            var p = document.getElementById('movie_player') || document.querySelector('.html5-video-player');
                            if (p && typeof p.playVideo === 'function') { try { p.playVideo(); } catch(e){} }
                        })();
                        """.trimIndent(), null
                    )
                } catch (e: Exception) {}
            }
        }

        applyDesktopMode(web)
        // CRUCIAL: Ensure YouTube page is loaded (with Auto-Resume last played song)
        val isDesktop = prefs.getBoolean(SettingsActivity.KEY_DESKTOP_MODE, false)
        val defaultHome = if (isDesktop) "https://www.youtube.com" else "https://m.youtube.com"
        val autoResume = prefs.getBoolean(SettingsActivity.KEY_AUTO_RESUME_LAST_TRACK, true)
        val lastUrl = CarMediaManager.lastPlayedUrl ?: prefs.getString(SettingsActivity.KEY_LAST_PLAYED_URL, null)
        val currentUrl = web.url
        val shouldResume = autoResume && !lastUrl.isNullOrBlank() && lastUrl.contains("watch")

        if (shouldResume) {
            // Restore the previous watch only when auto-resume is actually requested.
            CarMediaManager.userWantsPlayback = true
            CarMediaManager.ensureAudioFocus()
            CarMediaManager.acquireWakeLock(context)
            val targetUrl = lastUrl!!
            val alreadyLoading = (CarMediaManager.currentLoadingUrl == targetUrl)
            if (!alreadyLoading && (currentUrl.isNullOrBlank() || currentUrl == "about:blank" || !currentUrl.contains("watch"))) {
                CarMediaManager.currentLoadingUrl = targetUrl
                web.loadUrl(targetUrl)
            } else {
                YouTubePlayerHelper.inject(web, isUltrawide, isPortrait, carWidth, carHeight, carDpi, phoneDpi.toInt(), aspectRatio)
                scheduleSafeResume(web, 700L)
            }
        } else if (currentUrl.isNullOrBlank() || currentUrl == "about:blank") {
            if (CarMediaManager.currentLoadingUrl != defaultHome) {
                CarMediaManager.currentLoadingUrl = defaultHome
                web.loadUrl(defaultHome)
            }
        } else if (currentUrl.contains("watch")) {
            YouTubePlayerHelper.inject(web, isUltrawide, isPortrait, carWidth, carHeight, carDpi, phoneDpi.toInt(), aspectRatio)
            scheduleSafeResume(web, 700L)
        } else {
            YouTubePlayerHelper.inject(web, isUltrawide, isPortrait, carWidth, carHeight, carDpi, phoneDpi.toInt(), aspectRatio)
            if (CarMediaManager.userWantsPlayback && autoResume) {
                web.postDelayed({
                    YouTubePlayerHelper.playFirstAvailableVideo(web)
                }, 800L)
            }
        }

        CarMediaManager.registerCarWebView(web, context)

        val dash = CarDashboardView(
            context,
            onAppClick = { app -> switchWebApp(app, embedded = true) },
            onAddAppClick = { showAddAppDialog() },
            onAllAppsClick = { showAppGridOverlay() },
            onFullscreenRequested = { app -> showWebFullscreen(app) },
            onBackClick = { goBack() },
            onEmbeddedClosed = {
                // Keep video active by switching or reloading
            }
        )
        dashboardView = dash
        dash.setOnTouchListener { _, _ ->
            onUserInteraction()
            false
        }
        web.setOnTouchListener { _, _ ->
            onUserInteraction()
            false
        }
        root.setOnTouchListener { _, _ ->
            onUserInteraction()
            false
        }
        root.addView(dash, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        if (CarMediaManager.isWebShowingFullscreen) {
            try {
                (web.parent as? ViewGroup)?.removeView(web)
            } catch (e: Exception) {}
            root.addView(web, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            dash.visibility = View.GONE
            web.visibility = View.VISIBLE
            isDashboardShowing = false
        } else {
            dash.visibility = View.VISIBLE
            isDashboardShowing = true
            CarMediaManager.isEmbeddedAppShowing = true

            // ALWAYS EMBED VIDEO APP (YouTube or TV) - NEVER revert to list app!
            val appList = WebAppManager.getAllApps(context)
            val targetAppId = CarMediaManager.activeAppId
            val targetApp = appList.find { it.id == targetAppId }
                ?: (if (web.url?.contains("iptv") == true) appList.find { it.id == "iptv" } else null)
                ?: appList.firstOrNull { it.id == "youtube" }
                ?: WebAppManager.DEFAULT_APPS.first()
            dash.showEmbeddedApp(targetApp, web)
        }


        // 2. Build and attach dynamic sidebar
        rebuildSidebar()

        // 3. Build and attach dynamic top toolbar
        rebuildTopToolbar()

        // 4. Centered Large Voice Status Banner
        statusBanner = TextView(context).apply {
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(16), dp(28), dp(16))
            background = rounded(Color.parseColor("#EE102032"), 16f, Color.parseColor("#00E5FF"), 2)
            elevation = 40f
            visibility = View.GONE
        }
        val bannerParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.CENTER
        }
        root.addView(statusBanner, bannerParams)

        // 5. In-Car Search Overlay
        searchOverlay = buildSearchOverlay()
        root.addView(searchOverlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // 6. CarWeb-style App Grid Launcher Overlay
        appGridOverlay = buildAppGridOverlay()
        root.addView(appGridOverlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // 7. Add Custom App Dialog Overlay
        addAppOverlay = buildAddAppOverlay()
        root.addView(addAppOverlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // 8. Floating Modern Vietmap/Waze HUD Overlay (Styles #1 to #4)
        setupHudOverlay()
        try {
            hudPrefs.registerOnSharedPreferenceChangeListener(hudPrefsListener)
        } catch (e: Exception) {}

        setContentView(root)

        if (!LicenseManager.isLicensed(context)) {
            showCarActivationLock(root)
        }

        val controlReceiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                when (intent?.action) {
                    "com.carhud.SHOW_DASHBOARD" -> showDashboard()
                    "com.carhud.SHOW_APP_GRID" -> showAppGridOverlay()
                    "com.carhud.SHOW_WEB" -> showWeb()
                    "com.carhud.TOGGLE_DAY_NIGHT" -> toggleDayNightMode()
                }
            }
        }
        val ctrlFilter = android.content.IntentFilter().apply {
            addAction("com.carhud.SHOW_DASHBOARD")
            addAction("com.carhud.SHOW_APP_GRID")
            addAction("com.carhud.SHOW_WEB")
            addAction("com.carhud.TOGGLE_DAY_NIGHT")
        }
        try {
            ContextCompat.registerReceiver(
                context,
                controlReceiver,
                ctrlFilter,
                ContextCompat.RECEIVER_EXPORTED
            )
        } catch (e: Exception) {}
    }

    private fun setupHudOverlay() {
        // ALWAYS enable and show HUD overlay on Android Auto
        WazeHudManager.setFloatingOverlayEnabled(context, true)
        if (hudOverlay != null) {
            updateHudOverlay()
            return
        }
        val overlay = VietmapHudOverlay(context).apply {
            elevation = 120f
        }
        hudOverlay = overlay
        root.addView(overlay)
        updateHudLayoutParams()
        overlay.applyHudConfig()
        root.bringChildToFront(overlay)
    }

    private fun updateHudOverlay() {
        if (hudOverlay == null) {
            setupHudOverlay()
        } else {
            updateHudLayoutParams()
            hudOverlay?.applyHudConfig()
            hudOverlay?.let { root.bringChildToFront(it) }
        }
    }

    private fun updateHudLayoutParams() {
        val overlay = hudOverlay ?: return
        val styleId = WazeHudManager.getActiveStyleId(context)
        val (posX, posY) = WazeHudManager.getPosition(context)
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (posX >= 0 && posY >= 0) {
                leftMargin = dp(posX)
                topMargin = dp(posY)
            } else {
                when (styleId) {
                    3 -> { // Left Dock default
                        leftMargin = dp(10)
                        topMargin = dp(60)
                    }
                    4 -> { // Right Dock default
                        val screenWdp = (carWidth / resources.displayMetrics.density).roundToInt()
                        leftMargin = dp((screenWdp - 95).coerceAtLeast(20))
                        topMargin = dp(60)
                    }
                    else -> { // #1 & #2 Bubble Ngang default
                        leftMargin = dp(24)
                        topMargin = dp(24)
                    }
                }
            }
        }
        overlay.layoutParams = lp
        root.bringChildToFront(overlay)
    }

    private fun applyDesktopMode(targetWeb: WebView) {
        val isDesktop = prefs.getBoolean(SettingsActivity.KEY_DESKTOP_MODE, false)
        if (isDesktop) {
            targetWeb.settings.userAgentString = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
        } else {
            targetWeb.settings.userAgentString = null
        }
    }

    private var lastAppliedScale = -1
    fun applyWebScaleForUrl(url: String?) {
        val effectivePhoneDpi = if (phoneDpi > 0f) phoneDpi else 440f
        val effectiveCarDpi = if (carDpi > 0) carDpi.toFloat() else 160f
        val scalePercent = ((effectiveCarDpi / effectivePhoneDpi) * 100f).coerceIn(20f, 200f).toInt()
        if (scalePercent != lastAppliedScale) {
            lastAppliedScale = scalePercent
            web.setInitialScale(scalePercent)
            web.settings.useWideViewPort = true
            web.settings.loadWithOverviewMode = true
            web.settings.textZoom = 100
        }
    }

    fun isDayMode(): Boolean = SettingsActivity.resolveIsDay(context)

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        mainHandler.post {
            if (key == SettingsActivity.KEY_DESKTOP_MODE) {
                applyDesktopMode(web)
                val isDesktop = prefs.getBoolean(SettingsActivity.KEY_DESKTOP_MODE, false)
                val currentUrl = web.url ?: ""
                val targetUrl = if (isDesktop) {
                    if (currentUrl.contains("m.youtube.com")) currentUrl.replace("m.youtube.com", "www.youtube.com") else "https://www.youtube.com"
                } else {
                    if (currentUrl.contains("www.youtube.com")) currentUrl.replace("www.youtube.com", "m.youtube.com") else "https://m.youtube.com"
                }
                web.loadUrl(targetUrl)
            }
            if (key == SettingsActivity.KEY_THEME_MODE || key == "carhud_day_mode") {
                applyCurrentTheme(isDayMode())
            } else {
                rebuildSidebar()
                rebuildTopToolbar()
            }
        }
    }

    fun setPlaybackState(playing: Boolean) {
        isCurrentlyPlaying = playing
        playPauseBtn?.let { btn ->
            val iconRes = if (playing) R.drawable.ic_bar_square else R.drawable.ic_bar_play
            btn.setImageResource(iconRes)
            val isDay = isDayMode()
            if (isDay) {
                btn.setColorFilter(Color.parseColor("#1E293B"))
            } else {
                btn.clearColorFilter()
            }
        }
    }

    private var videoTimePill: TextView? = null

    fun updateVideoProgress(currentSec: Int, totalSec: Int, formattedTime: String) {
        val showTime = prefs.getBoolean(SettingsActivity.KEY_SHOW_TIME_PILL, true)
        if (showTime && totalSec > 0 && formattedTime.isNotEmpty() && !isDashboardShowing) {
            videoTimePill?.apply {
                text = "⏱ $formattedTime"
                if (visibility != View.VISIBLE) {
                    visibility = View.VISIBLE
                }
            }
        } else {
            videoTimePill?.visibility = View.GONE
        }
    }

    private fun rebuildSidebar() {
        sidebarContainer?.let { root.removeView(it) }

        val scale = prefs.getInt(SettingsActivity.KEY_TOOLBAR_SCALE, 100)
        val iconSizeDp = ((56 * scale) / 100).coerceIn(38, 84)
        val pillThicknessDp = iconSizeDp + 10

        val showBack = prefs.getBoolean(SettingsActivity.KEY_SHOW_BACK, true)
        val showHome = prefs.getBoolean(SettingsActivity.KEY_SHOW_HOME, true)
        val showTv = prefs.getBoolean(SettingsActivity.KEY_SHOW_TV, false)
        val showDayNight = prefs.getBoolean(SettingsActivity.KEY_SHOW_DAY_NIGHT, true)
        val showSearch = prefs.getBoolean(SettingsActivity.KEY_SHOW_KEYBOARD_SEARCH, false)
        val showMic = prefs.getBoolean(SettingsActivity.KEY_SHOW_VOICE_SEARCH, true)
        val showPlayPause = false
        val showNext = false
        val showFullscreen = false
        val showSettings = false

        val autoDetect = prefs.getBoolean(SettingsActivity.KEY_AUTO_DETECT_SCREEN, true)
        val configuredPos = prefs.getString(SettingsActivity.KEY_TOOLBAR_POSITION, "bottom") ?: "bottom"
        val positionKey = when {
            configuredPos == "auto" -> {
                if (isPortrait) "bottom" else "left"
            }
            else -> configuredPos
        }
        val isHorizontal = (positionKey == "bottom")

        val isDay = isDayMode()

        val sidebar = LinearLayout(context).apply {
            orientation = if (isHorizontal) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = if (isDay) {
                rounded(Color.parseColor("#EBF1F1FB"), 999f, Color.parseColor("#0284C7"), 2)
            } else {
                rounded(Color.parseColor("#F50B132B"), 999f, Color.parseColor("#00E5FF"), 2)
            }
            setPadding(dp(6), dp(6), dp(6), dp(6))

            var hasPrev = false

            if (showBack) {
                addView(createBarIcon(R.drawable.ic_bar_back, iconSizeDp) { goBack() })
                hasPrev = true
            }
            if (showHome) {
                if (hasPrev) addView(createDivider(iconSizeDp, isHorizontal))
                val homeBtn = createBarIcon(R.drawable.ic_bar_home, iconSizeDp) { showDashboard() }
                if (isDashboardShowing) {
                    homeBtn.background = rounded(
                        if (isDay) Color.parseColor("#E0F2FE") else Color.parseColor("#1E3B5A"),
                        999f,
                        if (isDay) Color.parseColor("#0284C7") else Color.parseColor("#00E5FF"),
                        2
                    )
                }
                addView(homeBtn)
                hasPrev = true
            }
            // Fullscreen Zoom / Toggle (Nút số 2)
            if (showTv) {
                if (hasPrev) addView(createDivider(iconSizeDp, isHorizontal))
                val tvBtn = createBarIcon(R.drawable.ic_bar_fullscreen, iconSizeDp) {
                    if (isDashboardShowing) {
                        showWebFullscreen()
                    } else {
                        showDashboard()
                    }
                }
                if (!isDashboardShowing) {
                    tvBtn.background = rounded(
                        if (isDay) Color.parseColor("#E0F2FE") else Color.parseColor("#1E3B5A"),
                        999f,
                        if (isDay) Color.parseColor("#0284C7") else Color.parseColor("#00E5FF"),
                        2
                    )
                }
                addView(tvBtn)
                hasPrev = true
            }

            // Day / Night mode toggle
            if (showDayNight) {
                if (hasPrev) addView(createDivider(iconSizeDp, isHorizontal))
                val dayNightIcon = if (isDay) R.drawable.ic_mode_night else R.drawable.ic_mode_day
                val dayNightBtn = createBarIcon(dayNightIcon, iconSizeDp) { toggleDayNightMode() }
                addView(dayNightBtn)
                hasPrev = true
            }
            if (showSearch) {
                if (hasPrev) addView(createDivider(iconSizeDp, isHorizontal))
                addView(createBarIcon(R.drawable.ic_bar_search, iconSizeDp) { showSearchOverlay() })
                hasPrev = true
            }
            if (showMic) {
                if (hasPrev) addView(createDivider(iconSizeDp, isHorizontal))
                micBtn = createBarIcon(R.drawable.ic_bar_mic, iconSizeDp) { startVoiceSearch() }
                addView(micBtn)
                hasPrev = true
            }
            if (showPlayPause) {
                if (hasPrev) addView(createDivider(iconSizeDp, isHorizontal))
                val initialIcon = if (isCurrentlyPlaying) R.drawable.ic_bar_square else R.drawable.ic_bar_play
                val btn = createBarIcon(initialIcon, iconSizeDp) {
                    togglePlayPause()
                }
                playPauseBtn = btn
                addView(btn)
                hasPrev = true
            }
            if (showNext) {
                if (hasPrev) addView(createDivider(iconSizeDp, isHorizontal))
                addView(createBarIcon(R.drawable.ic_bar_next, iconSizeDp) { YouTubePlayerHelper.playNext(web) })
                hasPrev = true
            }
            if (showFullscreen) {
                if (hasPrev) addView(createDivider(iconSizeDp, isHorizontal))
                addView(createBarIcon(R.drawable.ic_bar_fullscreen, iconSizeDp) { YouTubePlayerHelper.toggleFullscreen(web) })
                hasPrev = true
            }
            if (showSettings) {
                if (hasPrev) addView(createDivider(iconSizeDp, isHorizontal))
                val gearBtn = createBarIcon(R.drawable.ic_bar_setting, iconSizeDp) { openPhoneSettings() }
                addView(gearBtn)
            }
        }
        sidebarView = sidebar

        val targetGravity = when (positionKey) {
            "right" -> Gravity.END or Gravity.CENTER_VERTICAL
            "bottom" -> Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            else -> Gravity.START or Gravity.CENTER_VERTICAL
        }

        val showTimePill = true
        val timePill = TextView(context).apply {
            textSize = 11.5f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (isDay) Color.parseColor("#0284C7") else Color.parseColor("#00E5FF"))
            background = if (isDay) {
                rounded(Color.parseColor("#F1F5F9"), 10f, Color.parseColor("#CBD5E1"), 1)
            } else {
                rounded(Color.parseColor("#EE101C28"), 10f, Color.parseColor("#1E88E5"), 1)
            }
            setPadding(dp(8), dp(3), dp(8), dp(3))
            this.gravity = Gravity.CENTER
            visibility = if (isDashboardShowing || !showTimePill || videoTimePill?.text.isNullOrEmpty()) View.GONE else View.VISIBLE
            text = videoTimePill?.text ?: ""
        }
        videoTimePill = timePill

        val wrapper = LinearLayout(context).apply {
            elevation = 60f
            orientation = if (isHorizontal) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            this.gravity = Gravity.CENTER
            if (isHorizontal) {
                val timeLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(4)
                }
                addView(timePill, timeLp)
                addView(sidebar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(pillThicknessDp)))
            } else {
                if (positionKey == "right") {
                    val timeLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        rightMargin = dp(4)
                    }
                    addView(timePill, timeLp)
                    addView(sidebar, LinearLayout.LayoutParams(dp(pillThicknessDp), ViewGroup.LayoutParams.WRAP_CONTENT))
                } else {
                    addView(sidebar, LinearLayout.LayoutParams(dp(pillThicknessDp), ViewGroup.LayoutParams.WRAP_CONTENT))
                    val timeLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        leftMargin = dp(4)
                    }
                    addView(timePill, timeLp)
                }
            }
        }
        sidebarContainer = wrapper

        val webAppPos = prefs.getString(SettingsActivity.KEY_WEBAPP_TOOLBAR_POSITION, "left") ?: "left"
        val isLeftSidebar = (targetGravity and Gravity.HORIZONTAL_GRAVITY_MASK == Gravity.START)
        val dockScale = prefs.getInt(SettingsActivity.KEY_DOCK_SCALE, 100).coerceIn(50, 150)
        val dockBtnSize = ((36 * dockScale) / 100).coerceIn(22, 60)
        val dockPadH = ((4 * dockScale) / 100).coerceIn(2, 10)
        val dockTotalWidthDp = dockBtnSize + (dockPadH * 2) + 6
        val initialLeftMargin = if (isLeftSidebar && webAppPos == "left") dp(dockTotalWidthDp + 8) else dp(6)

        val wrapperParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            this.gravity = targetGravity
            leftMargin = initialLeftMargin
            rightMargin = dp(6)
            topMargin = dp(6)
            bottomMargin = dp(6)
        }
        root.addView(wrapper, wrapperParams)
        root.bringChildToFront(wrapper)

        resetAutoHideTimer()
    }

    private val autoHideHandler = Handler(Looper.getMainLooper())
    private val hideBarsRunnable = Runnable {
        hideBars()
    }

    fun showBars() {
        sidebarContainer?.let { sidebar ->
            if (sidebar.visibility != View.VISIBLE) {
                sidebar.bringToFront()
                sidebar.visibility = View.VISIBLE
                sidebar.alpha = 0f
                sidebar.animate().alpha(1f).setDuration(200).start()
            }
        }
        topToolbarContainer?.let { topBar ->
            if (topBar.visibility != View.VISIBLE) {
                topBar.bringToFront()
                topBar.visibility = View.VISIBLE
                topBar.alpha = 0f
                topBar.animate().alpha(1f).setDuration(200).start()
            }
        }
        resetAutoHideTimer()
    }

    fun hideBars() {
        sidebarContainer?.let { sidebar ->
            if (sidebar.visibility == View.VISIBLE) {
                sidebar.animate().alpha(0f).setDuration(200).withEndAction {
                    sidebar.visibility = View.GONE
                }.start()
            }
        }
        topToolbarContainer?.let { topBar ->
            if (topBar.visibility == View.VISIBLE) {
                topBar.animate().alpha(0f).setDuration(200).withEndAction {
                    topBar.visibility = View.GONE
                }.start()
            }
        }
    }

    fun showSidebar() = showBars()
    fun hideSidebar() = hideBars()

    fun resetAutoHideTimer() {
        autoHideHandler.removeCallbacks(hideBarsRunnable)
        autoHideHandler.postDelayed(hideBarsRunnable, 10000L) // 10s auto-hide
    }

    fun onUserInteraction() {
        mainHandler.post {
            showBars()
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        onUserInteraction()
        return super.dispatchTouchEvent(ev)
    }

    private fun rebuildTopToolbar() {
        topToolbarContainer?.let { root.removeView(it) }

        val apps = WebAppManager.getEnabledApps(context)
        currentActiveAppId = WebAppManager.getActiveAppId(context)

        val autoDetect = prefs.getBoolean(SettingsActivity.KEY_AUTO_DETECT_SCREEN, true)
        val configuredPos = prefs.getString(SettingsActivity.KEY_TOOLBAR_POSITION, "bottom") ?: "bottom"
        val isHorizontal = (configuredPos == "bottom" || isPortrait)
        val leftOffset = if (isHorizontal) dp(10) else dp(56)

        val webAppPos = prefs.getString(SettingsActivity.KEY_WEBAPP_TOOLBAR_POSITION, "left") ?: "left"
        val isVertical = (webAppPos == "left")

        val dockScale = prefs.getInt(SettingsActivity.KEY_DOCK_SCALE, 100).coerceIn(50, 150)
        val factor = dockScale / 100f

        val padH = if (isVertical) ((4 * dockScale) / 100).coerceIn(2, 10) else ((6 * dockScale) / 100).coerceIn(3, 14)
        val padV = if (isVertical) ((6 * dockScale) / 100).coerceIn(3, 14) else ((4 * dockScale) / 100).coerceIn(2, 10)

        val isDay = isDayMode()

        val toolbar = LinearLayout(context).apply {
            orientation = if (isVertical) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = if (isDay) {
                rounded(Color.parseColor("#EBF1F1FB"), 999f, Color.parseColor("#0284C7"), 2)
            } else {
                rounded(Color.parseColor("#F50B132B"), 999f, Color.parseColor("#00E5FF"), 2)
            }
            elevation = 25f
            setPadding(dp(padH), dp(padV), dp(padH), dp(padV))
        }

        // 1. App Grid Launcher button (▦)
        val vBtnSize = ((56 * dockScale) / 100).coerceIn(38, 84)
        val hBtnSize = ((50 * dockScale) / 100).coerceIn(32, 76)
        val iconPad = (vBtnSize * 0.16f).roundToInt().coerceIn(5, 12)
        val appIconPad = (vBtnSize * 0.16f).roundToInt().coerceIn(5, 12)
        val tabMargin = ((4 * dockScale) / 100).coerceIn(2, 8)
        val hMargin = ((6 * dockScale) / 100).coerceIn(3, 10)

        val gridBtn = ImageView(context).apply {
            setImageResource(R.drawable.ic_app_grid)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(iconPad), dp(iconPad), dp(iconPad), dp(iconPad))
            background = rounded(
                if (isDay) Color.parseColor("#E0F2FE") else Color.parseColor("#1E3B5A"),
                999f,
                if (isDay) Color.parseColor("#0284C7") else Color.parseColor("#00E5FF"),
                2
            )
            layoutParams = if (isVertical) {
                LinearLayout.LayoutParams(dp(vBtnSize), dp(vBtnSize)).apply { bottomMargin = dp(tabMargin) }
            } else {
                LinearLayout.LayoutParams(dp(hBtnSize), dp(hBtnSize)).apply { rightMargin = dp(hMargin) }
            }
            enableTouchBounce()
            setOnClickListener {
                onUserInteraction()
                toggleAppGridOverlay()
            }
        }
        toolbar.addView(gridBtn)

        // Divider
        val div1 = View(context).apply {
            setBackgroundColor(if (isDay) Color.parseColor("#CBD5E1") else Color.parseColor("#33FFFFFF"))
            layoutParams = if (isVertical) {
                val divWidth = ((28 * dockScale) / 100).coerceIn(18, 44)
                LinearLayout.LayoutParams(dp(divWidth), dp(1)).apply {
                    topMargin = dp(2)
                    bottomMargin = dp(tabMargin)
                }
            } else {
                val divHeight = ((20 * dockScale) / 100).coerceIn(12, 34)
                LinearLayout.LayoutParams(dp(1), dp(divHeight)).apply {
                    rightMargin = dp(hMargin)
                }
            }
        }
        toolbar.addView(div1)

        // 2. App Tabs Container
        if (isVertical) {
            val vScroll = ScrollView(context).apply {
                isVerticalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            val tabsContainer = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
            }
            for (app in apps) {
                val isActive = (app.id == currentActiveAppId)
                val appBrandColor = try { Color.parseColor(app.colorHex) } catch(e: Exception) { Color.parseColor("#1E88E5") }
                val tabView = FrameLayout(context).apply {
                    val boxColor = if (isDay) {
                        if (isActive) Color.parseColor("#E0F2FE") else Color.parseColor("#FFFFFF")
                    } else {
                        if (isActive) Color.parseColor("#1E3B5A") else Color.parseColor("#0F172A")
                    }
                    val borderColor = if (isDay) {
                        if (isActive) Color.parseColor("#0284C7") else Color.parseColor("#CBD5E1")
                    } else {
                        if (isActive) Color.parseColor("#00E5FF") else Color.parseColor("#334155")
                    }
                    background = rounded(boxColor, 999f, borderColor, if (isActive) 2 else 1)
                    layoutParams = LinearLayout.LayoutParams(dp(vBtnSize), dp(vBtnSize)).apply {
                        bottomMargin = dp(tabMargin)
                    }

                    val icon = ImageView(context).apply {
                        scaleType = ImageView.ScaleType.FIT_CENTER
                        setPadding(dp(appIconPad), dp(appIconPad), dp(appIconPad), dp(appIconPad))

                        if (!app.iconPath.isNullOrBlank() && java.io.File(app.iconPath).exists()) {
                            val bmp = BitmapFactory.decodeFile(app.iconPath)
                            if (bmp != null) {
                                setImageBitmap(bmp)
                                clearColorFilter()
                            } else {
                                setImageResource(app.iconRes)
                                clearColorFilter()
                            }
                        } else {
                            setImageResource(app.iconRes)
                            clearColorFilter()
                        }
                    }
                    addView(icon, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

                    enableTouchBounce()
                    setOnClickListener {
                        onUserInteraction()
                        switchWebApp(app, embedded = isDashboardShowing)
                    }
                    setOnLongClickListener {
                        onUserInteraction()
                        showDisableAppDialog(app)
                        true
                    }
                }
                tabsContainer.addView(tabView)
            }
            vScroll.addView(tabsContainer)
            toolbar.addView(vScroll)
        } else {
            val hScroll = HorizontalScrollView(context).apply {
                isHorizontalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val tabsContainer = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            for (app in apps) {
                val isActive = (app.id == currentActiveAppId)
                val appBrandColor = try { Color.parseColor(app.colorHex) } catch(e: Exception) { Color.parseColor("#1E88E5") }
                val tabPadH = ((10 * dockScale) / 100).coerceIn(5, 18)
                val tabPadV = ((4 * dockScale) / 100).coerceIn(2, 8)
                val tabView = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(tabPadH), dp(tabPadV), dp(tabPadH), dp(tabPadV))
                    background = if (isDay) {
                        if (isActive) rounded(Color.parseColor("#E0F2FE"), (10f * factor).coerceIn(6f, 16f), Color.parseColor("#0284C7"), 2)
                        else rounded(Color.parseColor("#FFFFFF"), (10f * factor).coerceIn(6f, 16f), Color.parseColor("#CBD5E1"), 1)
                    } else {
                        if (isActive) rounded(Color.parseColor("#1E3B5A"), (10f * factor).coerceIn(6f, 16f), Color.parseColor("#00E5FF"), 2)
                        else rounded(Color.parseColor("#101C28"), (10f * factor).coerceIn(6f, 16f), Color.parseColor("#1B2E42"), 1)
                    }
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(hBtnSize)).apply {
                        rightMargin = dp(((6 * dockScale) / 100).coerceIn(3, 10))
                    }

                    val hIconSize = ((18 * dockScale) / 100).coerceIn(10, 30)
                    val icon = ImageView(context).apply {
                        scaleType = ImageView.ScaleType.CENTER_INSIDE
                        layoutParams = LinearLayout.LayoutParams(dp(hIconSize), dp(hIconSize)).apply {
                            rightMargin = dp(5)
                        }

                        if (!app.iconPath.isNullOrBlank() && java.io.File(app.iconPath).exists()) {
                            val bmp = BitmapFactory.decodeFile(app.iconPath)
                            if (bmp != null) {
                                setImageBitmap(bmp)
                                clearColorFilter()
                            } else {
                                setImageResource(app.iconRes)
                                clearColorFilter()
                            }
                        } else {
                            setImageResource(app.iconRes)
                            clearColorFilter()
                        }
                    }
                    addView(icon)

                    val label = TextView(context).apply {
                        text = app.name
                        textSize = (12f * factor).coerceIn(8.5f, 18f)
                        typeface = if (isActive) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                        setTextColor(if (isActive) (if (isDay) Color.parseColor("#0284C7") else Color.WHITE) else (if (isDay) Color.parseColor("#1E293B") else Color.parseColor("#B0BEC5")))
                    }
                    addView(label)

                    enableTouchBounce()
                    setOnClickListener {
                        onUserInteraction()
                        switchWebApp(app, embedded = isDashboardShowing)
                    }
                    setOnLongClickListener {
                        onUserInteraction()
                        showDisableAppDialog(app)
                        true
                    }
                }

                tabsContainer.addView(tabView)
            }
            hScroll.addView(tabsContainer)
            toolbar.addView(hScroll)
        }

        topToolbarContainer = toolbar
        toolbar.visibility = View.VISIBLE

        val params = if (isVertical) {
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                leftMargin = dp(6)
            }
        } else {
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.TOP or Gravity.START
                topMargin = dp(6)
                leftMargin = leftOffset
                rightMargin = dp(10)
            }
        }
        root.addView(toolbar, params)

        // Dynamically adjust sidebarContainer left margin if it sits on the left side
        val dockTotalWidthDp = vBtnSize + (padH * 2) + 6
        sidebarContainer?.let { sc ->
            val lp = sc.layoutParams as? FrameLayout.LayoutParams
            if (lp != null && (lp.gravity and Gravity.HORIZONTAL_GRAVITY_MASK == Gravity.START)) {
                lp.leftMargin = if (isVertical) dp(dockTotalWidthDp + 8) else dp(6)
                sc.layoutParams = lp
            }
        }

        resetAutoHideTimer()
    }

    private fun showDockSizeDialog() {
        val currentScale = prefs.getInt(SettingsActivity.KEY_DOCK_SCALE, 100).coerceIn(50, 150)
        val options = arrayOf("Nhỏ gọn (70%)", "Vừa (85%)", "Chuẩn mặc định (100%)", "Lớn (120%)", "Cực lớn (140%)")
        val scales = intArrayOf(70, 85, 100, 120, 140)
        var selectedIndex = scales.indexOf(currentScale)
        if (selectedIndex == -1) {
            selectedIndex = scales.indices.minByOrNull { Math.abs(scales[it] - currentScale) } ?: 2
        }

        try {
            android.app.AlertDialog.Builder(context, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("📏 Kích thước thanh dock")
                .setSingleChoiceItems(options, selectedIndex) { dialog, which ->
                    val newScale = scales[which]
                    prefs.edit().putInt(SettingsActivity.KEY_DOCK_SCALE, newScale).apply()
                    appGridSizeBtn?.text = "📏 Cỡ: $newScale%"
                    rebuildTopToolbar()
                    rebuildSidebar()
                    updateVoiceState(VoiceSearchManager.State.SUCCESS, "Đã chỉnh kích thước dock: $newScale%")
                    dialog.dismiss()
                }
                .setNegativeButton("Đóng", null)
                .show()
        } catch (e: Exception) {}
    }

    private fun showDisableAppDialog(app: WebAppItem) {
        val performDisable = {
            WebAppManager.setAppEnabled(context, app.id, false)
            if (app.id == currentActiveAppId) {
                val enabled = WebAppManager.getEnabledApps(context)
                switchWebApp(enabled.first())
                try {
                    web.stopLoading()
                    web.clearCache(false)
                    web.freeMemory()
                } catch (e: Exception) {}
                System.gc()
            } else {
                rebuildTopToolbar()
                rebuildAppGrid()
            }
            updateVoiceState(VoiceSearchManager.State.SUCCESS, "Đã tắt ${app.name} để tăng tốc!")
        }
        try {
            android.app.AlertDialog.Builder(context, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("⚙ Tùy chỉnh dock: ${app.name}")
                .setMessage("Tắt ứng dụng này khỏi thanh dock để giải phóng bộ nhớ RAM và tăng tốc hiệu năng xe?")
                .setPositiveButton("🛑 Tắt app") { _, _ -> performDisable() }
                .setNeutralButton("📏 Cỡ dock") { _, _ -> showDockSizeDialog() }
                .setNegativeButton("Hủy", null)
                .show()
        } catch (e: Exception) {
            performDisable()
        }
    }

    private fun handleVoiceQuery(query: String) {
        val tvCmd = TvVoiceHelper.parse(query)
        if (tvCmd != null) {
            playTvChannel(tvCmd.channelTarget)
            hideSearchOverlay()
            return
        }

        searchInput.setText(query)
        searchInput.setSelection(query.length)
        YouTubePlayerHelper.setDuckingVolume(web, 1.0f)

        // Ensure active app is YouTube when doing a video search
        if (currentActiveAppId != "youtube") {
            val ytApp = WebAppManager.getAllApps(context).find { it.id == "youtube" } ?: WebAppManager.DEFAULT_APPS.first()
            switchWebApp(ytApp, embedded = isDashboardShowing)
        } else if (isDashboardShowing && (dashboardView?.isEmbeddedAppShowing() != true)) {
            showWebFullscreen()
        }

        YouTubePlayerHelper.search(web, query)
        CarMediaManager.notifyVoiceState(VoiceSearchManager.State.SUCCESS, "Đang tìm: $query")
        updateVoiceState(VoiceSearchManager.State.SUCCESS, "Đang tìm: $query")
        hideSearchOverlay()
    }

    fun playTvChannel(channelName: String) {
        val iptvApp = WebAppManager.getAllApps(context).find { it.id == "iptv" }
            ?: WebAppManager.DEFAULT_APPS.find { it.id == "iptv" }
            ?: return

        val label = if (channelName.isNotBlank()) channelName else "Truyền hình"
        updateVoiceState(VoiceSearchManager.State.SUCCESS, "📺 Đang mở $label...")
        CarMediaManager.notifyVoiceState(VoiceSearchManager.State.SUCCESS, "📺 Đang mở $label...")

        val isAlreadyIptv = (currentActiveAppId == "iptv" && web.url?.contains("iptv_player.html") == true)
        if (isAlreadyIptv) {
            if (channelName.isNotBlank()) {
                web.evaluateJavascript("if (window.playChannelByName) { window.playChannelByName('$channelName'); }", null)
            }
        } else {
            val targetUrl = if (channelName.isNotBlank()) {
                "file:///android_asset/iptv_player.html#channel=" + java.net.URLEncoder.encode(channelName, "UTF-8")
            } else {
                iptvApp.url
            }
            switchWebApp(iptvApp.copy(url = targetUrl), embedded = isDashboardShowing)
        }

        if (channelName.isNotBlank()) {
            web.postDelayed({
                web.evaluateJavascript("if (window.playChannelByName) { window.playChannelByName('$channelName'); }", null)
            }, 600L)
            web.postDelayed({
                web.evaluateJavascript("if (window.playChannelByName) { window.playChannelByName('$channelName'); }", null)
            }, 1500L)
        }
    }

    fun switchWebApp(app: WebAppItem, embedded: Boolean = true) {
        val currentUrl = web.url ?: ""
        val isYouTubeApp = (app.id == "youtube" || app.url.contains("youtube.com") || app.url.contains("youtu.be"))
        val isAlreadyLoaded = if (isYouTubeApp) {
            currentUrl.contains("youtube.com") || currentUrl.contains("youtu.be")
        } else {
            (currentActiveAppId == app.id) && currentUrl.isNotEmpty() && currentUrl != "about:blank"
        }
        currentActiveAppId = app.id
        WebAppManager.setActiveAppId(context, app.id)
        CarMediaManager.activeAppId = app.id
        CarMediaManager.lastEmbeddedApp = app
        if (embedded && isDashboardShowing) {
            CarMediaManager.isEmbeddedAppShowing = true
            CarMediaManager.isWebShowingFullscreen = false
        }

        val isDesktop = WebAppManager.isAppDesktop(context, app.id)
        if (app.id == "tiktok" || app.url.contains("tiktok.com")) {
            web.settings.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
            web.settings.domStorageEnabled = true
            web.settings.databaseEnabled = true
            web.settings.mediaPlaybackRequiresUserGesture = false
            try {
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
            } catch (e: Exception) {}
        } else if (isDesktop) {
            web.settings.userAgentString = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
        } else {
            applyDesktopMode(web)
        }

        applyWebScaleForUrl(app.url)

        val homeUrl = if (app.id == "youtube") {
            if (isDesktop) "https://www.youtube.com" else "https://m.youtube.com"
        } else {
            app.url
        }
        if (!isAlreadyLoaded) {
            web.loadUrl(homeUrl)
        }

        if (embedded && dashboardView != null && isDashboardShowing) {
            dashboardView?.showEmbeddedApp(app, web)
            topToolbarContainer?.visibility = View.GONE
        } else {
            showWebFullscreen(app)
        }

        rebuildTopToolbar()
        rebuildAppGrid()
        dashboardView?.refreshAppsList()
        resetAutoHideTimer()
    }

    val isShowingDashboard: Boolean
        get() = isDashboardShowing

    fun showWebFullscreen(app: WebAppItem? = null) {
        isDashboardShowing = false
        CarMediaManager.isWebShowingFullscreen = true
        CarMediaManager.isEmbeddedAppShowing = false
        try {
            (web.parent as? ViewGroup)?.removeView(web)
            root.addView(web, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } catch (e: Exception) {}
        
        // Disable dashboard mode so YouTube script knows it's fullscreen
        web.evaluateJavascript("window.isDashboardMode = false;", null)
        
        applyWebScaleForUrl(app?.url ?: web.url)
        YouTubePlayerHelper.applyTheme(web, isDayMode())
        dashboardView?.detachEmbeddedWeb()
        dashboardView?.visibility = View.GONE
        web.visibility = View.VISIBLE
        web.alpha = 1f
        topToolbarContainer?.visibility = View.VISIBLE
        rebuildSidebar()
        hudOverlay?.let {
            root.bringChildToFront(it)
        }
        // Restore dimensions and force rendering resume when entering fullscreen
        try { 
            web.layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            web.requestLayout()
            root.post {
                try {
                    web.onResume() 
                    web.evaluateJavascript(
                        """
                        (function() {
                            var v = document.querySelector('video');
                            if (v && v.paused) { try { if (v.muted) v.muted = false; v.play(); } catch(e){} }
                            var p = document.getElementById('movie_player') || document.querySelector('.html5-video-player');
                            if (p && typeof p.playVideo === 'function' && p.getPlayerState && p.getPlayerState() !== 1) { try { p.playVideo(); } catch(e){} }
                        })();
                        """.trimIndent(), null
                    )
                } catch (e: Exception) {}
            }
        } catch (e: Exception) {}
    }

    fun showDashboard() {
        isDashboardShowing = true
        CarMediaManager.isWebShowingFullscreen = false
        val isDay = isDayMode()
        dashboardView?.applyDayNightMode(isDay)
        YouTubePlayerHelper.applyTheme(web, isDay)
        dashboardView?.refreshAppsList()
        dashboardView?.scrollTo(0, 0)
        dashboardView?.visibility = View.VISIBLE
        
        // ALWAYS restore / embed video app in Card 5 (YouTube or TV) - NEVER revert to list app!
        CarMediaManager.isEmbeddedAppShowing = true
        val appList = WebAppManager.getAllApps(context)
        val targetAppId = CarMediaManager.activeAppId
        val targetApp = appList.find { it.id == targetAppId }
            ?: (if (web.url?.contains("iptv") == true) appList.find { it.id == "iptv" } else null)
            ?: appList.firstOrNull { it.id == "youtube" }
            ?: WebAppManager.DEFAULT_APPS.first()
        dashboardView?.showEmbeddedApp(targetApp, web)
        
        rebuildSidebar()
        showBars()
        hudOverlay?.let {
            root.bringChildToFront(it)
        }
        resetAutoHideTimer()
    }

    fun showWeb() {
        showWebFullscreen()
    }

    fun toggleDayNightMode() {
        val curMode = prefs.getString(SettingsActivity.KEY_THEME_MODE, SettingsActivity.THEME_AUTO) ?: SettingsActivity.THEME_AUTO
        val nextMode = when (curMode) {
            SettingsActivity.THEME_AUTO -> SettingsActivity.THEME_DAY
            SettingsActivity.THEME_DAY -> SettingsActivity.THEME_NIGHT
            SettingsActivity.THEME_NIGHT -> SettingsActivity.THEME_AUTO
            else -> SettingsActivity.THEME_AUTO
        }
        prefs.edit().putString(SettingsActivity.KEY_THEME_MODE, nextMode).apply()
        val isDay = isDayMode()
        prefs.edit().putBoolean("carhud_day_mode", isDay).apply()
        val modeText = when (nextMode) {
            SettingsActivity.THEME_AUTO -> "🚗 Giao diện Tự động (Cảm biến xe)"
            SettingsActivity.THEME_DAY -> "☀️ Giao diện Ban ngày (Sáng)"
            else -> "🌙 Giao diện Ban đêm (Tối)"
        }
        updateVoiceState(VoiceSearchManager.State.SUCCESS, modeText)
        applyCurrentTheme(isDay)
    }

    fun applyUniversalWebTheme(view: WebView?, isDay: Boolean) {
        YouTubePlayerHelper.applyUniversalWebTheme(view, isDay)
    }

    fun applyCurrentTheme(isDay: Boolean = isDayMode()) {
        dashboardView?.applyDayNightMode(isDay)
        rebuildSidebar()
        rebuildTopToolbar()
        YouTubePlayerHelper.applyUniversalWebTheme(web, isDay)
    }

    fun onCarConfigurationChanged(newConfig: android.content.res.Configuration? = null) {
        val mode = prefs.getString(SettingsActivity.KEY_THEME_MODE, SettingsActivity.THEME_AUTO) ?: SettingsActivity.THEME_AUTO
        if (mode == SettingsActivity.THEME_AUTO) {
            val isDay = if (newConfig != null) {
                val isNight = (newConfig.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
                !isNight
            } else {
                isDayMode()
            }
            prefs.edit().putBoolean("carhud_day_mode", isDay).apply()
            applyCurrentTheme(isDay)
        }
    }

    private fun buildAppGridOverlay(): FrameLayout {
        return FrameLayout(context).apply {
            visibility = View.GONE
            setBackgroundColor(Color.parseColor("#F208111D"))
            isClickable = true

            val rootPanel = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(20), dp(12), dp(20), dp(12))
            }

            // Top Header: Title + Hint + Close
            val header = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(12)
                }

                val title = TextView(context).apply {
                    text = "T-Car"
                    textSize = 20f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }
                addView(title)

                val hint = TextView(context).apply {
                    text = "Chạm biểu tượng để mở ứng dụng"
                    textSize = 13f
                    setTextColor(Color.parseColor("#90A4AE"))
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        rightMargin = dp(14)
                    }
                }
                addView(hint)

                val posToggleBtn = TextView(context).apply {
                    appGridPosToggleBtn = this
                    val curPos = prefs.getString(SettingsActivity.KEY_WEBAPP_TOOLBAR_POSITION, "left") ?: "left"
                    text = if (curPos == "left") "📍 Vị trí: Trái" else "📍 Vị trí: Trên"
                    textSize = 13.5f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.parseColor("#00E5FF"))
                    setPadding(dp(12), dp(8), dp(12), dp(8))
                    background = rounded(Color.parseColor("#1A00E5FF"), 10f, Color.parseColor("#00E5FF"), 1)
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        rightMargin = dp(10)
                    }
                    enableTouchBounce()
                    setOnClickListener {
                        onUserInteraction()
                        val oldPos = prefs.getString(SettingsActivity.KEY_WEBAPP_TOOLBAR_POSITION, "left") ?: "left"
                        val newPos = if (oldPos == "left") "top" else "left"
                        prefs.edit().putString(SettingsActivity.KEY_WEBAPP_TOOLBAR_POSITION, newPos).apply()
                        text = if (newPos == "left") "📍 Vị trí: Trái" else "📍 Vị trí: Trên"
                        rebuildTopToolbar()
                    }
                }
                addView(posToggleBtn)

                val sizeBtn = TextView(context).apply {
                    appGridSizeBtn = this
                    val curScale = prefs.getInt(SettingsActivity.KEY_DOCK_SCALE, 100).coerceIn(50, 150)
                    text = "📏 Cỡ: $curScale%"
                    textSize = 13.5f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.parseColor("#80D8FF"))
                    setPadding(dp(12), dp(8), dp(12), dp(8))
                    background = rounded(Color.parseColor("#1A00E5FF"), 10f, Color.parseColor("#80D8FF"), 1)
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        rightMargin = dp(10)
                    }
                    enableTouchBounce()
                    setOnClickListener {
                        onUserInteraction()
                        showDockSizeDialog()
                    }
                }
                addView(sizeBtn)

                val optRamBtn = TextView(context).apply {
                    text = "⚡ Tối ưu RAM"
                    textSize = 13.5f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.parseColor("#FFD54F"))
                    setPadding(dp(12), dp(8), dp(12), dp(8))
                    background = rounded(Color.parseColor("#26FFD54F"), 10f, Color.parseColor("#FFD54F"), 1)
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        rightMargin = dp(10)
                    }
                    enableTouchBounce()
                    setOnClickListener {
                        onUserInteraction()
                        try {
                            web.stopLoading()
                            web.clearCache(false)
                            web.freeMemory()
                        } catch (e: Exception) {}
                        System.gc()
                        updateVoiceState(VoiceSearchManager.State.SUCCESS, "Đã dọn dẹp RAM & tối ưu hiệu năng!")
                    }
                }
                addView(optRamBtn)

                val closeBtn = TextView(context).apply {
                    text = "✕ Đóng"
                    textSize = 14f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    setPadding(dp(16), dp(8), dp(16), dp(8))
                    background = rounded(Color.parseColor("#C62828"), 12f, Color.parseColor("#E57373"), 1)
                    enableTouchBounce()
                    setOnClickListener {
                        hideAppGridOverlay()
                    }
                }
                addView(closeBtn)
            }
            rootPanel.addView(header)

            val scrollContainer = HorizontalScrollView(context).apply {
                isHorizontalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    gravity = Gravity.CENTER_HORIZONTAL
                }
            }

            val gridContent = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
            }
            appGridPanel = gridContent
            scrollContainer.addView(gridContent)
            rootPanel.addView(scrollContainer)

            addView(rootPanel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
    }

    private fun rebuildAppGrid() {
        val panel = appGridPanel ?: return
        panel.removeAllViews()

        val apps = WebAppManager.getAllApps(context)
        val itemsPerRow = if (isPortrait) 3 else 5

        var currentRow: LinearLayout? = null

        for (i in apps.indices) {
            val app = apps[i]
            val isEnabled = WebAppManager.isAppEnabled(context, app.id)

            if (i % itemsPerRow == 0) {
                currentRow = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        bottomMargin = dp(14)
                    }
                }
                panel.addView(currentRow)
            }

            val card = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(6), dp(6), dp(6), dp(6))
                layoutParams = LinearLayout.LayoutParams(dp(100), dp(148)).apply {
                    leftMargin = dp(8)
                    rightMargin = dp(8)
                }
                alpha = if (isEnabled) 1.0f else 0.55f

                val iconBox = FrameLayout(context).apply {
                    val boxColor = try { Color.parseColor(app.colorHex) } catch(e: Exception) { Color.parseColor("#1E88E5") }
                    background = rounded(boxColor, 16f, if (isEnabled) Color.WHITE else Color.parseColor("#55FFFFFF"), 1)
                    layoutParams = LinearLayout.LayoutParams(dp(62), dp(62)).apply {
                        gravity = Gravity.CENTER_HORIZONTAL
                        bottomMargin = dp(5)
                    }

                    val icon = ImageView(context).apply {
                        scaleType = ImageView.ScaleType.CENTER_INSIDE
                        if (!app.iconPath.isNullOrBlank() && java.io.File(app.iconPath).exists()) {
                            val bmp = android.graphics.BitmapFactory.decodeFile(app.iconPath)
                            if (bmp != null) {
                                setImageBitmap(bmp)
                                setPadding(dp(5), dp(5), dp(5), dp(5))
                            } else {
                                setImageResource(app.iconRes)
                                setPadding(dp(9), dp(9), dp(9), dp(9))
                            }
                        } else {
                            setImageResource(app.iconRes)
                            setPadding(dp(9), dp(9), dp(9), dp(9))
                        }
                    }
                    addView(icon, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                }
                addView(iconBox)

                val label = TextView(context).apply {
                    text = app.name
                    textSize = 13f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(if (isEnabled) Color.WHITE else Color.parseColor("#90A4AE"))
                    gravity = Gravity.CENTER
                    maxLines = 1
                }
                addView(label)

                val statusBadge = TextView(context).apply {
                    text = if (isEnabled) "🟢 Bật" else "⚪ Đã tắt"
                    textSize = 11.5f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(if (isEnabled) Color.parseColor("#00E5FF") else Color.parseColor("#90A4AE"))
                    setPadding(dp(8), dp(4), dp(8), dp(4))
                    val bColor = if (isEnabled) Color.parseColor("#1A00E5FF") else Color.parseColor("#222A35")
                    val strColor = if (isEnabled) Color.parseColor("#00E5FF") else Color.parseColor("#455A64")
                    background = rounded(bColor, 8f, strColor, 1)
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        topMargin = dp(4)
                    }
                    enableTouchBounce()
                    setOnClickListener {
                        onUserInteraction()
                        val newState = !isEnabled
                        WebAppManager.setAppEnabled(context, app.id, newState)
                        if (!newState && app.id == currentActiveAppId) {
                            val enabledApps = WebAppManager.getEnabledApps(context)
                            switchWebApp(enabledApps.first())
                            try {
                                web.stopLoading()
                                web.clearCache(false)
                            } catch (e: Exception) {}
                        } else {
                            rebuildTopToolbar()
                            rebuildAppGrid()
                        }
                        updateVoiceState(VoiceSearchManager.State.SUCCESS, if (newState) "Đã bật ${app.name}" else "Đã tắt ${app.name} để tăng tốc")
                    }
                }
                addView(statusBadge)

                val isDesktop = WebAppManager.isAppDesktop(context, app.id)
                val modeBadge = TextView(context).apply {
                    text = if (isDesktop) "💻 Desktop" else "📱 Mobile"
                    textSize = 11f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(if (isDesktop) Color.parseColor("#00E5FF") else Color.parseColor("#81C784"))
                    setPadding(dp(7), dp(3), dp(7), dp(3))
                    val bColor = if (isDesktop) Color.parseColor("#2600E5FF") else Color.parseColor("#264CAF50")
                    val strColor = if (isDesktop) Color.parseColor("#00E5FF") else Color.parseColor("#4CAF50")
                    background = rounded(bColor, 7f, strColor, 1)
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        topMargin = dp(3)
                    }
                    enableTouchBounce()
                    setOnClickListener {
                        onUserInteraction()
                        val nextMode = !isDesktop
                        WebAppManager.setAppDesktop(context, app.id, nextMode)
                        rebuildAppGrid()
                        dashboardView?.refreshAppsList()
                        if (app.id == currentActiveAppId) {
                            if (nextMode) {
                                web.settings.userAgentString = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
                            } else {
                                applyDesktopMode(web)
                            }
                            web.reload()
                        }
                        updateVoiceState(VoiceSearchManager.State.SUCCESS, "${app.name}: ${if (nextMode) "Chế độ Desktop" else "Chế độ Mobile"}")
                    }
                }
                addView(modeBadge)

                enableTouchBounce()
                setOnClickListener {
                    onUserInteraction()
                    if (!isEnabled) {
                        WebAppManager.setAppEnabled(context, app.id, true)
                        hideAppGridOverlay()
                        switchWebApp(app)
                    } else {
                        hideAppGridOverlay()
                        switchWebApp(app)
                    }
                }

                setOnLongClickListener {
                    onUserInteraction()
                    showDisableAppDialog(app)
                    true
                }
            }
            currentRow?.addView(card)
        }

        // Add "+ Thêm App" card
        val addCard = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(6), dp(6), dp(6))
            layoutParams = LinearLayout.LayoutParams(dp(76), dp(84)).apply {
                leftMargin = dp(6)
                rightMargin = dp(6)
            }

            val iconBox = FrameLayout(context).apply {
                background = rounded(Color.parseColor("#1B2A1D"), 14f, Color.parseColor("#4CAF50"), 2)
                layoutParams = LinearLayout.LayoutParams(dp(50), dp(50)).apply {
                    gravity = Gravity.CENTER_HORIZONTAL
                    bottomMargin = dp(4)
                }

                val icon = ImageView(context).apply {
                    setImageResource(R.drawable.ic_app_add)
                    setColorFilter(Color.parseColor("#81C784"))
                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                    setPadding(dp(10), dp(10), dp(10), dp(10))
                }
                addView(icon, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
            addView(iconBox)

            val label = TextView(context).apply {
                text = "+ Thêm"
                textSize = 11f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.parseColor("#81C784"))
                gravity = Gravity.CENTER
                maxLines = 1
            }
            addView(label)

            setOnClickListener {
                hideAppGridOverlay()
                showAddAppDialog()
            }
        }
        if (apps.size % itemsPerRow == 0) {
            currentRow = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(12)
                }
            }
            panel.addView(currentRow)
        }
        currentRow?.addView(addCard)
    }

    fun toggleAppGridOverlay() {
        if (appGridOverlay?.visibility == View.VISIBLE) {
            hideAppGridOverlay()
        } else {
            showAppGridOverlay()
        }
    }

    fun showAppGridOverlay() {
        val curPos = prefs.getString(SettingsActivity.KEY_WEBAPP_TOOLBAR_POSITION, "left") ?: "left"
        val curScale = prefs.getInt(SettingsActivity.KEY_DOCK_SCALE, 100).coerceIn(50, 150)
        appGridPosToggleBtn?.text = if (curPos == "left") "📍 Vị trí: Trái" else "📍 Vị trí: Trên"
        appGridSizeBtn?.text = "📏 Cỡ: $curScale%"
        rebuildAppGrid()
        appGridOverlay?.visibility = View.VISIBLE
        appGridOverlay?.alpha = 0f
        appGridOverlay?.animate()?.alpha(1f)?.setDuration(200)?.start()
    }

    fun hideAppGridOverlay() {
        appGridOverlay?.animate()?.alpha(0f)?.setDuration(200)?.withEndAction {
            appGridOverlay?.visibility = View.GONE
        }?.start()
    }

    private fun buildAddAppOverlay(): FrameLayout {
        return FrameLayout(context).apply {
            visibility = View.GONE
            setBackgroundColor(Color.parseColor("#D9000000"))
            isClickable = true

            val card = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(20), dp(16), dp(20), dp(16))
                background = rounded(Color.parseColor("#101C28"), 16f, Color.parseColor("#00E5FF"), 2)
            }

            val title = TextView(context).apply {
                text = "➕ Thêm Ứng Dụng Web Mới"
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(10)
                }
            }
            card.addView(title)

            val iconPreviewRow = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(10)
                }

                val previewBox = FrameLayout(context).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply {
                        rightMargin = dp(10)
                    }
                    background = rounded(Color.parseColor("#1B2A3A"), 12f, Color.parseColor("#00E5FF"), 1)
                    val img = ImageView(context).apply {
                        addAppIconPreview = this
                        setImageResource(R.drawable.ic_app_web)
                        scaleType = ImageView.ScaleType.CENTER_INSIDE
                        setPadding(dp(8), dp(8), dp(8), dp(8))
                    }
                    addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                }
                addView(previewBox)

                val iconHint = TextView(context).apply {
                    text = "🌐 Tự động lấy Icon chất lượng cao từ tên miền URL"
                    textSize = 11f
                    setTextColor(Color.parseColor("#78909C"))
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }
                addView(iconHint)
            }
            card.addView(iconPreviewRow)

            addAppNameInput = EditText(context).apply {
                hint = "Tên ứng dụng (VD: TV360, Facebook, VTV...)"
                setHintTextColor(Color.parseColor("#607D8B"))
                setTextColor(Color.WHITE)
                textSize = 13f
                background = rounded(Color.parseColor("#182A3A"), 10f, Color.parseColor("#37474F"), 1)
                setPadding(dp(12), dp(8), dp(12), dp(8))
                layoutParams = LinearLayout.LayoutParams(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(8)
                }
            }
            card.addView(addAppNameInput)

            addAppUrlInput = EditText(context).apply {
                hint = "Địa chỉ URL (VD: tv360.vn, facebook.com)"
                setHintTextColor(Color.parseColor("#607D8B"))
                setTextColor(Color.WHITE)
                textSize = 13f
                background = rounded(Color.parseColor("#182A3A"), 10f, Color.parseColor("#37474F"), 1)
                setPadding(dp(12), dp(8), dp(12), dp(8))
                layoutParams = LinearLayout.LayoutParams(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(8)
                }

                addTextChangedListener(object : android.text.TextWatcher {
                    private var fetchTask: Runnable? = null
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                        fetchTask?.let { mainHandler.removeCallbacks(it) }
                        val raw = s?.toString()?.trim() ?: ""
                        if (raw.length > 3) {
                            val r = Runnable {
                                val domain = WebIconFetcher.extractDomain(raw)
                                if (domain.contains(".")) {
                                    if (addAppNameInput?.text.isNullOrBlank()) {
                                        addAppNameInput?.setText(WebIconFetcher.extractPrettyName(domain))
                                    }
                                    WebIconFetcher.fetchFaviconAsync(domain) { bmp ->
                                        if (bmp != null) {
                                            downloadedFaviconBitmap = bmp
                                            addAppIconPreview?.setImageBitmap(bmp)
                                            addAppIconPreview?.setPadding(dp(4), dp(4), dp(4), dp(4))
                                        }
                                    }
                                }
                            }
                            fetchTask = r
                            mainHandler.postDelayed(r, 600)
                        }
                    }
                    override fun afterTextChanged(s: android.text.Editable?) {}
                })
            }
            card.addView(addAppUrlInput)

            addAppDesktopCheck = CheckBox(context).apply {
                text = "Chế độ máy tính (Desktop User-Agent)"
                setTextColor(Color.parseColor("#B0BEC5"))
                textSize = 12f
                layoutParams = LinearLayout.LayoutParams(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(12)
                }
            }
            card.addView(addAppDesktopCheck)

            val btnRow = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT)

                val cancelBtn = TextView(context).apply {
                    text = "Hủy"
                    textSize = 13f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    setPadding(dp(18), dp(8), dp(18), dp(8))
                    background = rounded(Color.parseColor("#37474F"), 10f, 0, 0)
                    setOnClickListener {
                        hideAddAppDialog()
                    }
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        rightMargin = dp(8)
                    }
                }
                addView(cancelBtn)

                val saveBtn = TextView(context).apply {
                    text = "Lưu & Mở"
                    textSize = 13f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    setPadding(dp(18), dp(8), dp(18), dp(8))
                    background = rounded(Color.parseColor("#1976D2"), 10f, Color.parseColor("#00E5FF"), 1)
                    setOnClickListener {
                        val name = addAppNameInput?.text?.toString()?.trim() ?: ""
                        val url = addAppUrlInput?.text?.toString()?.trim() ?: ""
                        if (url.isNotEmpty()) {
                            val isDesktop = addAppDesktopCheck?.isChecked == true
                            val customId = "custom_" + System.currentTimeMillis()
                            var savedIconPath: String? = null
                            downloadedFaviconBitmap?.let { bmp ->
                                savedIconPath = WebIconFetcher.saveIconToDisk(context, customId, bmp)
                            }
                            val newApp = WebAppManager.addCustomApp(context, name, url, isDesktop, iconPath = savedIconPath)
                            hideAddAppDialog()
                            switchWebApp(newApp)
                        }
                    }
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        leftMargin = dp(8)
                    }
                }
                addView(saveBtn)
            }
            card.addView(btnRow)

            addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.CENTER
            })
        }
    }

    fun showAddAppDialog() {
        downloadedFaviconBitmap = null
        addAppIconPreview?.setImageResource(R.drawable.ic_app_web)
        addAppIconPreview?.setPadding(dp(8), dp(8), dp(8), dp(8))
        addAppNameInput?.setText("")
        addAppUrlInput?.setText("")
        addAppDesktopCheck?.isChecked = false
        addAppOverlay?.visibility = View.VISIBLE
        addAppOverlay?.alpha = 0f
        addAppOverlay?.animate()?.alpha(1f)?.setDuration(200)?.start()
    }

    fun hideAddAppDialog() {
        addAppOverlay?.animate()?.alpha(0f)?.setDuration(200)?.withEndAction {
            addAppOverlay?.visibility = View.GONE
        }?.start()
    }

    private fun createBarIcon(drawableRes: Int, sizeDp: Int, onClick: () -> Unit): ImageView {
        val isDay = isDayMode()
        return ImageView(context).apply {
            setImageResource(drawableRes)
            if (isDay) {
                if (drawableRes != R.drawable.ic_mode_night && drawableRes != R.drawable.ic_mode_day) {
                    setColorFilter(Color.parseColor("#1E293B"))
                } else {
                    clearColorFilter()
                }
            } else {
                clearColorFilter()
            }
            scaleType = ImageView.ScaleType.FIT_CENTER
            val pad = (sizeDp * 0.16f).roundToInt().coerceIn(6, 14)
            setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
            enableTouchBounce()
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        }
    }

    private fun createDivider(sizeDp: Int, isHorizontal: Boolean): View {
        val isDay = isDayMode()
        val span = (sizeDp * 0.55f).roundToInt()
        return View(context).apply {
            if (isHorizontal) {
                layoutParams = LinearLayout.LayoutParams(dp(1), dp(span)).apply {
                    leftMargin = dp(2)
                    rightMargin = dp(2)
                }
            } else {
                layoutParams = LinearLayout.LayoutParams(dp(span), dp(1)).apply {
                    topMargin = dp(2)
                    bottomMargin = dp(2)
                }
            }
            setBackgroundColor(if (isDay) Color.parseColor("#CBD5E1") else Color.parseColor("#33FFFFFF"))
        }
    }

    private fun executeSearch(query: String) {
        val q = query.trim()
        if (q.isNotEmpty()) {
            if (currentActiveAppId != "youtube") {
                val ytApp = WebAppManager.getAllApps(context).find { it.id == "youtube" } ?: WebAppManager.DEFAULT_APPS.first()
                switchWebApp(ytApp, embedded = isDashboardShowing)
            }
            if (isDashboardShowing) {
                showWebFullscreen()
            }
            YouTubePlayerHelper.search(web, q)
            CarMediaManager.submitSearchQuery(q)
            hideSearchOverlay()
        }
    }

    private fun buildSearchOverlay(): FrameLayout {
        return FrameLayout(context).apply {
            visibility = View.GONE
            setBackgroundColor(Color.parseColor("#FF080E17")) // 100% Solid dark background eliminates dashboard clutter
            isClickable = true
            isFocusable = true

            val rootLayout = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                setPadding(dp(12), dp(6), dp(12), dp(6))
            }

            // 1. Top Search Bar Row
            val topRow = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dp(5)
                    rightMargin = dp(56) // Safe margin so top-right floating buttons / system cutouts never overlap
                }

                // Close button [✕]
                val closeBtn = TextView(context).apply {
                    text = "✕"
                    textSize = 17f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    background = rounded(Color.parseColor("#212C3A"), 10f, Color.parseColor("#37474F"), 1)
                    setPadding(dp(14), dp(8), dp(14), dp(8))
                    enableTouchBounce(0.92f)
                    setOnClickListener { hideSearchOverlay() }
                }
                addView(closeBtn)

                // Search Input Box
                val inputContainer = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = rounded(Color.parseColor("#142030"), 10f, Color.parseColor("#1976D2"), 2)
                    setPadding(dp(12), dp(2), dp(6), dp(2))
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        leftMargin = dp(8)
                        rightMargin = dp(8)
                    }

                    val searchIcon = TextView(context).apply {
                        text = "🔍"
                        textSize = 15f
                        setPadding(0, 0, dp(6), 0)
                    }
                    addView(searchIcon)

                    searchInput = EditText(context).apply {
                        hint = "Nhập bài hát, ca sĩ, thể loại..."
                        setHintTextColor(Color.parseColor("#607D8B"))
                        setTextColor(Color.WHITE)
                        textSize = 16f
                        typeface = Typeface.DEFAULT_BOLD
                        background = null
                        isSingleLine = true
                        imeOptions = EditorInfo.IME_ACTION_SEARCH
                        inputType = InputType.TYPE_CLASS_TEXT
                        setOnKeyListener { _, keyCode, event ->
                            if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER) {
                                executeSearch(text.toString())
                                true
                            } else false
                        }
                        setOnEditorActionListener { _, actionId, _ ->
                            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                                executeSearch(text.toString())
                                true
                            } else false
                        }
                    }
                    addView(searchInput, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

                    val clearIcon = TextView(context).apply {
                        text = "✕"
                        textSize = 14f
                        typeface = Typeface.DEFAULT_BOLD
                        setTextColor(Color.parseColor("#90A4AE"))
                        setPadding(dp(8), dp(6), dp(8), dp(6))
                        enableTouchBounce(0.9f)
                        setOnClickListener {
                            searchInput.setText("")
                        }
                    }
                    addView(clearIcon)
                }
                addView(inputContainer)

                // Voice Search Button [🎙️ Nói]
                val voiceBtn = TextView(context).apply {
                    text = "🎙️ Nói"
                    textSize = 13.5f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    background = rounded(Color.parseColor("#C62828"), 10f, Color.parseColor("#EF5350"), 1)
                    setPadding(dp(14), dp(8), dp(14), dp(8))
                    enableTouchBounce(0.92f)
                    setOnClickListener {
                        startVoiceSearch()
                    }
                }
                addView(voiceBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    rightMargin = dp(8)
                })

                // Submit Search Button [🔍 TÌM]
                val submitBtn = TextView(context).apply {
                    text = "🔍 Tìm"
                    textSize = 14f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    background = rounded(Color.parseColor("#0288D1"), 10f, Color.parseColor("#00E5FF"), 1)
                    setPadding(dp(18), dp(8), dp(18), dp(8))
                    enableTouchBounce(0.92f)
                    setOnClickListener {
                        executeSearch(searchInput.text.toString())
                    }
                }
                addView(submitBtn)
            }
            rootLayout.addView(topRow)

            // 2. Quick Suggestion Chips Row
            val chipScroll = HorizontalScrollView(context).apply {
                isHorizontalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(5)
                    rightMargin = dp(48)
                }
                val chipRow = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, dp(2), 0, dp(2))
                    val suggestions = arrayOf(
                        "Nhạc trẻ remix", "Nhạc chill TikTok", "Bolero trữ tình", 
                        "EDM Bass cực căng", "Nhạc Tết 2026", "Top Hits Việt Nam", 
                        "Karaoke có lời", "Lofi thư giãn", "Acoustic nhẹ nhàng", 
                        "Nhạc vàng hải ngoại", "Không lời thư giãn"
                    )
                    for (s in suggestions) {
                        val chip = TextView(context).apply {
                            text = s
                            textSize = 12.5f
                            typeface = Typeface.DEFAULT_BOLD
                            setTextColor(Color.parseColor("#80D8FF"))
                            background = rounded(Color.parseColor("#152232"), 8f, Color.parseColor("#263238"), 1)
                            setPadding(dp(12), dp(5), dp(12), dp(5))
                            enableTouchBounce(0.92f)
                            setOnClickListener {
                                searchInput.setText(s)
                                executeSearch(s)
                            }
                        }
                        addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                            rightMargin = dp(6)
                        })
                    }
                }
                addView(chipRow)
            }
            rootLayout.addView(chipScroll)

            // 3. Full-Screen Automotive Touch Keyboard (5 rows)
            val keyboardContainer = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(Color.parseColor("#0C131D"), 12f, Color.parseColor("#1B293A"), 1)
                setPadding(dp(4), dp(4), dp(4), dp(4))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            }

            fun addChar(ch: String) {
                val cur = searchInput.text.toString()
                val selStart = searchInput.selectionStart.coerceAtLeast(0)
                val selEnd = searchInput.selectionEnd.coerceAtLeast(0)
                val start = Math.min(selStart, selEnd)
                val end = Math.max(selStart, selEnd)
                val updated = cur.substring(0, start) + ch + cur.substring(end)
                searchInput.setText(updated)
                searchInput.setSelection((start + ch.length).coerceAtMost(updated.length))
            }

            fun deleteChar() {
                val cur = searchInput.text.toString()
                if (cur.isEmpty()) return
                val selStart = searchInput.selectionStart.coerceAtLeast(0)
                val selEnd = searchInput.selectionEnd.coerceAtLeast(0)
                if (selStart != selEnd) {
                    val start = Math.min(selStart, selEnd)
                    val end = Math.max(selStart, selEnd)
                    val updated = cur.substring(0, start) + cur.substring(end)
                    searchInput.setText(updated)
                    searchInput.setSelection(start)
                } else if (selStart > 0) {
                    val updated = cur.substring(0, selStart - 1) + cur.substring(selStart)
                    searchInput.setText(updated)
                    searchInput.setSelection(selStart - 1)
                } else {
                    searchInput.setText(cur.dropLast(1))
                    searchInput.setSelection(searchInput.text.length)
                }
            }

            fun createKey(text: String, weight: Float, bg: Int = Color.parseColor("#1C2A3A"), stroke: Int = Color.parseColor("#2C3E52"), textColor: Int = Color.WHITE, textSize: Float = 16f, onClick: () -> Unit): TextView {
                return TextView(context).apply {
                    this.text = text
                    this.textSize = textSize
                    this.typeface = Typeface.DEFAULT_BOLD
                    this.setTextColor(textColor)
                    this.gravity = Gravity.CENTER
                    this.background = rounded(bg, 8f, stroke, 1)
                    enableTouchBounce(0.92f)
                    setOnClickListener { onClick() }
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight).apply {
                        setMargins(dp(2f), dp(2f), dp(2f), dp(2f))
                    }
                }
            }

            // Row 1: Numbers (1 2 3 4 5 6 7 8 9 0)
            val row1 = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
                val nums = arrayOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
                for (n in nums) {
                    addView(createKey(n, 1f, bg = Color.parseColor("#15202D"), textColor = Color.parseColor("#B0BEC5"), textSize = 15f) {
                        addChar(n)
                    })
                }
            }
            keyboardContainer.addView(row1)

            // Row 2: Q W E R T Y U I O P
            val row2 = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
                val letters = arrayOf("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P")
                for (l in letters) {
                    addView(createKey(l, 1f) {
                        addChar(l)
                    })
                }
            }
            keyboardContainer.addView(row2)

            // Row 3: A S D F G H J K L (staggered with 0.5f spacer on each side)
            val row3 = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
                addView(View(context), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.5f))
                val letters = arrayOf("A", "S", "D", "F", "G", "H", "J", "K", "L")
                for (l in letters) {
                    addView(createKey(l, 1f) {
                        addChar(l)
                    })
                }
                addView(View(context), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.5f))
            }
            keyboardContainer.addView(row3)

            // Row 4: [Đ] Z X C V B N M [⌫ XÓA]
            val row4 = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
                
                // Vietnamese Đ
                addView(createKey("Đ", 1f, bg = Color.parseColor("#1C2A3A"), stroke = Color.parseColor("#2C3E52")) {
                    addChar("Đ")
                })
                
                val letters = arrayOf("Z", "X", "C", "V", "B", "N", "M")
                for (l in letters) {
                    addView(createKey(l, 1f) {
                        addChar(l)
                    })
                }
                // Backspace Key
                val backspaceKey = createKey("⌫ XÓA", 1.8f, bg = Color.parseColor("#BF360C"), stroke = Color.parseColor("#FF5722"), textColor = Color.WHITE, textSize = 13f) {
                    deleteChar()
                }.apply {
                    setOnLongClickListener {
                        searchInput.setText("")
                        true
                    }
                }
                addView(backspaceKey)
            }
            keyboardContainer.addView(row4)

            // Row 5: [📱 Đ.Thoại] [⌨️ Gốc AA] [␣ DẤU CÁCH] [🗑️ Xóa hết] [🔍 TÌM KIẾM]
            val row5 = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)

                // Phone Search Switcher
                val phoneKey = createKey("📱 Đ.Thoại", 1.5f, bg = Color.parseColor("#1565C0"), stroke = Color.parseColor("#42A5F5"), textSize = 12f) {
                    CarMediaManager.launchPhoneSearchActivity(context, searchInput.text.toString())
                }
                addView(phoneKey)

                // Android Auto Native Search Switcher
                val aaKey = createKey("⌨️ Gốc AA", 1.5f, bg = Color.parseColor("#263238"), stroke = Color.parseColor("#546E7A"), textSize = 12f) {
                    CarMediaManager.requestCarNativeSearch(searchInput.text.toString())
                }
                addView(aaKey)

                // Space Bar
                val spaceKey = createKey("␣ DẤU CÁCH", 3.8f, bg = Color.parseColor("#1E293B"), stroke = Color.parseColor("#334155"), textColor = Color.parseColor("#B0BEC5"), textSize = 13f) {
                    addChar(" ")
                }
                addView(spaceKey)

                // Clear All Button
                val clearKey = createKey("🗑️ Xóa hết", 1.3f, bg = Color.parseColor("#37474F"), stroke = Color.parseColor("#78909C"), textColor = Color.parseColor("#FFAB91"), textSize = 12f) {
                    searchInput.setText("")
                }
                addView(clearKey)

                // Search Action Button
                val searchActionKey = createKey("🔍 TÌM KIẾM", 2.2f, bg = Color.parseColor("#0088FF"), stroke = Color.parseColor("#40C4FF"), textColor = Color.WHITE, textSize = 13.5f) {
                    executeSearch(searchInput.text.toString())
                }
                addView(searchActionKey)
            }
            keyboardContainer.addView(row5)

            rootLayout.addView(keyboardContainer)
            addView(rootLayout)
        }
    }

    fun showSearchOverlay() {
        searchOverlay.visibility = View.VISIBLE
        searchOverlay.bringToFront()

        // Clean UI: hide all background chrome & widgets so screen is 100% focused on keyboard
        hudOverlay?.visibility = View.GONE
        sidebarContainer?.visibility = View.GONE
        topToolbarContainer?.visibility = View.GONE

        searchInput.requestFocus()
        CarMediaManager.requestSearch(searchInput.text.toString())
    }

    fun hideSearchOverlay(notifyPhone: Boolean = true) {
        try {
            val displayCtx = context.createDisplayContext(display)
            val imm = displayCtx.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                ?: context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.hideSoftInputFromWindow(searchInput.windowToken, 0)
        } catch (e: Exception) {}
        searchOverlay.visibility = View.GONE

        // Restore elements cleanly based on screen state
        sidebarContainer?.visibility = View.VISIBLE
        sidebarContainer?.let { root.bringChildToFront(it) }

        if (!isDashboardShowing) {
            topToolbarContainer?.visibility = View.VISIBLE
            topToolbarContainer?.let { root.bringChildToFront(it) }
        }
        if (WazeHudManager.isFloatingOverlayEnabled(context)) {
            hudOverlay?.visibility = View.VISIBLE
            hudOverlay?.let { root.bringChildToFront(it) }
        }

        if (notifyPhone) {
            CarMediaManager.dismissSearch()
        }
    }

    private val voiceBannerHideHandler = Handler(Looper.getMainLooper())
    private val hideVoiceBannerRunnable = Runnable {
        statusBanner.animate().alpha(0f).setDuration(250).withEndAction {
            statusBanner.visibility = View.GONE
            statusBanner.alpha = 1f
        }.start()
        micBtn?.background = null
        if (isDayMode()) {
            micBtn?.setColorFilter(Color.parseColor("#1E293B"))
        } else {
            micBtn?.clearColorFilter()
        }
    }

    private fun scheduleVoiceBannerDismiss() {
        voiceBannerHideHandler.removeCallbacks(hideVoiceBannerRunnable)
        voiceBannerHideHandler.postDelayed(hideVoiceBannerRunnable, 5000L)
    }

    private fun updateVoiceState(state: VoiceSearchManager.State, text: String) {
        voiceBannerHideHandler.removeCallbacks(hideVoiceBannerRunnable)
        val isDay = isDayMode()
        when (state) {
            VoiceSearchManager.State.IDLE -> {
                statusBanner.visibility = View.GONE
                micBtn?.background = null
                if (isDay) micBtn?.setColorFilter(Color.parseColor("#1E293B")) else micBtn?.clearColorFilter()
            }
            VoiceSearchManager.State.LISTENING -> {
                statusBanner.text = "🎙️ Đang lắng nghe..."
                statusBanner.background = rounded(Color.parseColor("#EE102032"), 16f, Color.parseColor("#00E5FF"), 2)
                statusBanner.visibility = View.VISIBLE
                statusBanner.alpha = 1f
                statusBanner.bringToFront()
                micBtn?.background = null
                micBtn?.setColorFilter(Color.parseColor("#00E5FF"))
                scheduleVoiceBannerDismiss()
            }
            VoiceSearchManager.State.RECOGNIZING -> {
                statusBanner.text = "⏳ $text"
                statusBanner.background = rounded(Color.parseColor("#EE102032"), 16f, Color.parseColor("#F39C12"), 2)
                statusBanner.visibility = View.VISIBLE
                statusBanner.alpha = 1f
                statusBanner.bringToFront()
                micBtn?.background = null
                micBtn?.setColorFilter(Color.parseColor("#38BDF8"))
                scheduleVoiceBannerDismiss()
            }
            VoiceSearchManager.State.SUCCESS -> {
                statusBanner.text = "🔍 $text"
                statusBanner.background = rounded(Color.parseColor("#EE102032"), 16f, Color.parseColor("#2ECC71"), 2)
                statusBanner.visibility = View.VISIBLE
                statusBanner.alpha = 1f
                statusBanner.bringToFront()
                micBtn?.background = null
                micBtn?.setColorFilter(Color.parseColor("#10B981"))
                voiceBannerHideHandler.postDelayed(hideVoiceBannerRunnable, 2000L)
            }
            VoiceSearchManager.State.ERROR -> {
                statusBanner.text = "⚠️ $text"
                statusBanner.background = rounded(Color.parseColor("#EE102032"), 16f, Color.parseColor("#E74C3C"), 2)
                statusBanner.visibility = View.VISIBLE
                statusBanner.alpha = 1f
                statusBanner.bringToFront()
                micBtn?.background = null
                micBtn?.setColorFilter(Color.parseColor("#EF4444"))
                voiceBannerHideHandler.postDelayed(hideVoiceBannerRunnable, 2500L)
            }
        }
    }

    fun startVoiceSearch() {
        hideSearchOverlay()
        YouTubePlayerHelper.setDuckingVolume(web, 0.0f)
        updateVoiceState(VoiceSearchManager.State.LISTENING, "Đang lắng nghe... Hãy nói tên bài hát")
        voiceManager.startListening()
    }

    fun togglePlayPause() {
        CarMediaManager.togglePlayPause()
    }

    fun getWebView(): WebView = web

    fun dispatchTouch(x: Float, y: Float) {
        onUserInteraction()

        // 1. Check HUD interactions if HUD overlay is present
        val hud = hudOverlay
        if (hud != null && hud.visibility == View.VISIBLE) {
            // Priority 1: Direct hit on lock button toggles lock state (locked <-> unlocked)
            if (hud.hitTestLock(x, y)) {
                hud.toggleLock()
                return
            }

            // Priority 2: If HUD is unlocked:
            if (!hud.isHudLocked()) {
                // Tapping anywhere on the HUD overlay immediately locks it into place
                if (hud.isTouchOnOverlay(x, y)) {
                    hud.toggleLock()
                    return
                }

                // Tapping outside HUD moves HUD to that new position
                hud.moveTo(x, y, root.width, root.height)
                return
            }
        }

        val decor = window?.decorView ?: root
        val now = SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(now, now, MotionEvent.ACTION_DOWN, x, y, 0)
        val up = MotionEvent.obtain(now, now + 30, MotionEvent.ACTION_UP, x, y, 0)
        decor.dispatchTouchEvent(down)
        decor.dispatchTouchEvent(up)
        down.recycle()
        up.recycle()
    }

    fun dispatchScroll(dx: Float, dy: Float) {
        onUserInteraction()
        val hud = hudOverlay
        if (hud != null && hud.visibility == View.VISIBLE && !hud.isHudLocked()) {
            hud.moveBy(-dx, -dy, root.width, root.height)
            return
        }
        val activeWeb = CarMediaManager.getActiveWebView() ?: web
        val scrollDelta = (dy * 2.0f).roundToInt()
        if (scrollDelta != 0) {
            val js = """
                (function() {
                    var dy = $scrollDelta;
                    if (window.scrollChannelList) {
                        window.scrollChannelList(dy);
                    } else {
                        window.scrollBy(0, dy);
                    }
                })();
            """.trimIndent()
            activeWeb.evaluateJavascript(js, null)
        }
    }

    fun dispatchFling(vx: Float, vy: Float) {
        onUserInteraction()
        val hud = hudOverlay
        if (hud != null && hud.visibility == View.VISIBLE && !hud.isHudLocked()) {
            hud.moveBy(-vx * 0.1f, -vy * 0.1f, root.width, root.height)
            return
        }
        val activeWeb = CarMediaManager.getActiveWebView() ?: web
        val flingAmount = (-vy * 0.45f).roundToInt()
        if (flingAmount != 0) {
            val js = """
                (function() {
                    var dy = $flingAmount;
                    if (window.flingChannelList) {
                        window.flingChannelList(dy);
                    } else {
                        window.scrollBy({ top: dy, behavior: 'smooth' });
                    }
                })();
            """.trimIndent()
            activeWeb.evaluateJavascript(js, null)
        }
    }

    fun reload() {
        web.reload()
    }

    fun goBack() {
        if (addAppOverlay?.visibility == View.VISIBLE) {
            hideAddAppDialog()
            return
        }
        if (appGridOverlay?.visibility == View.VISIBLE) {
            hideAppGridOverlay()
            return
        }
        if (searchOverlay.visibility == View.VISIBLE) {
            hideSearchOverlay()
            return
        }
        val targetWeb = if (isDashboardShowing && dashboardView?.isEmbeddedAppShowing() == true) {
            dashboardView?.currentEmbeddedWeb ?: web
        } else {
            web
        }
        if (targetWeb.canGoBack()) {
            targetWeb.goBack()
        }
    }

    fun goHome() {
        showDashboard()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_VOICE_ASSIST,
                KeyEvent.KEYCODE_SEARCH -> {
                    startVoiceSearch()
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_NEXT -> {
                    CarMediaManager.playNext()
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    CarMediaManager.goBack()
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_PLAY,
                KeyEvent.KEYCODE_MEDIA_PAUSE,
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                KeyEvent.KEYCODE_HEADSETHOOK -> {
                    CarMediaManager.togglePlayPause()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    fun openPhoneSettings() {
        try {
            val intent = Intent(context, SettingsActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val options = ActivityOptions.makeBasic().apply {
                    setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
                }
                context.startActivity(intent, options.toBundle())
            } else {
                context.startActivity(intent)
            }
        } catch (e: Exception) {
            try {
                val pi = PendingIntent.getActivity(
                    context,
                    0,
                    Intent(context, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                pi.send()
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
        }
    }

    fun detachWebForBackground(): WebView {
        (web.parent as? ViewGroup)?.removeView(web)
        // CRITICAL FIX: Attach to MainActivity's background window so Chromium doesn't kill media playback!
        CarMediaManager.mainActivityRoot?.let { mainRoot ->
            try {
                if (web.parent == null) {
                    mainRoot.addView(web, ViewGroup.LayoutParams(1, 1))
                }
            } catch (e: Exception) {}
        }
        web.onResume()
        web.resumeTimers()
        return web
    }

    fun reattachWebForForeground() {
        (web.parent as? ViewGroup)?.removeView(web)
        try {
            if (web.parent == null) {
                // Add it back at index 0 (behind sidebar and search overlay)
                root.addView(web, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
        } catch (e: Exception) {}
        web.onResume()
        web.resumeTimers()
    }

    override fun onStop() {
        autoHideHandler.removeCallbacks(hideBarsRunnable)
        super.onStop()
        try {
            (web.parent as? ViewGroup)?.removeView(web)
        } catch(e: Exception) {}
    }


    override fun dismiss() {
        try {
            (web.parent as? ViewGroup)?.removeView(web)
        } catch(e: Exception) {}
        super.dismiss()
    }

    fun destroyWeb() {
        try {
            hudPrefs.unregisterOnSharedPreferenceChangeListener(hudPrefsListener)
        } catch (e: Exception) {}
        prefs.unregisterOnSharedPreferenceChangeListener(this)
        voiceManager.stop()
        CarMediaManager.unregisterVoiceListener(voiceListener)
        CarMediaManager.unregisterSearchQueryListener(searchQueryListener)
        CarMediaManager.unregisterSearchDismissListener(searchDismissListener)
        CarMediaManager.unregisterSearchLiveTextListener(searchLiveTextListener)
        try {
            web.webChromeClient?.onHideCustomView()
            web.evaluateJavascript("try { document.exitFullscreen(); } catch(e) {}", null)
        } catch(e: Exception) {}
        CarMediaManager.unregisterCarWebView(web)
        web.stopLoading()
        web.destroy()
    }

    private fun rounded(fill: Int, radiusDp: Float, stroke: Int, strokeDp: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(fill)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeDp > 0) {
                setStroke(dp(strokeDp), stroke)
            }
        }
    }

    private var carLockOverlay: View? = null

    private fun showCarActivationLock(parent: FrameLayout) {
        if (carLockOverlay != null) return

        val overlay = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0A1119"))
            setPadding(dp(24), dp(24), dp(24), dp(24))
            isClickable = true
            isFocusable = true
        }

        val logo = ImageView(context).apply {
            layoutParams = LinearLayout.LayoutParams(dp(72), dp(72)).apply {
                bottomMargin = dp(12)
            }
            setImageResource(R.drawable.ic_carhud_logo)
        }
        overlay.addView(logo)

        val title = TextView(context).apply {
            text = "T-Car Pro"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        overlay.addView(title)

        val sub = TextView(context).apply {
            text = "🔒 BUỒNG LÁI CHƯA ĐƯỢC KÍCH HOẠT BẢN QUYỀN"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#38BDF8"))
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(14))
        }
        overlay.addView(sub)

        val devBox = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(12), dp(20), dp(12))
            background = rounded(Color.parseColor("#121A24"), 12f, Color.parseColor("#1E293B"), 1)
        }

        val devLbl = TextView(context).apply {
            text = "MÃ THIẾT BỊ: ${LicenseManager.getDeviceId(context)}"
            textSize = 15f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.parseColor("#38BDF8"))
            gravity = Gravity.CENTER
        }
        devBox.addView(devLbl)

        val devDesc = TextView(context).apply {
            text = "Vui lòng mở ứng dụng T-Car trên điện thoại để gửi duyệt bản quyền qua Telegram."
            textSize = 12f
            setTextColor(Color.parseColor("#94A3B8"))
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, 0)
        }
        devBox.addView(devDesc)
        overlay.addView(devBox)

        val refreshBtn = TextView(context).apply {
            text = "🔄 Kiểm tra lại bản quyền"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(10), dp(24), dp(10))
            background = rounded(Color.parseColor("#0284C7"), 8f, 0, 0)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(16)
            }
            setOnClickListener {
                Toast.makeText(context, "⏳ Đang kiểm tra bản quyền...", Toast.LENGTH_SHORT).show()
                LicenseManager.checkStatus(context) { status, _, _ ->
                    mainHandler.post {
                        if (status == LicenseManager.STATUS_APPROVED) {
                            parent.removeView(overlay)
                            carLockOverlay = null
                            Toast.makeText(context, "🎉 Bản quyền T-Car Pro đã được kích hoạt!", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "Chưa kích hoạt. Vui lòng duyệt trên Telegram!", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
        overlay.addView(refreshBtn)

        carLockOverlay = overlay
        parent.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun dp(v: Int): Int = (v * context.resources.displayMetrics.density).toInt()
    private fun dp(v: Float): Int = (v * context.resources.displayMetrics.density).toInt()
}
