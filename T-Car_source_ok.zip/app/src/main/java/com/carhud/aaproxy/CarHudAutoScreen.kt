package com.carhud.aaproxy

import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Handler
import android.os.Looper
import android.view.Surface
import androidx.car.app.AppManager
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner

class CarHudAutoScreen(carContext: CarContext) : Screen(carContext), SurfaceCallback {

    private var virtualDisplay: VirtualDisplay? = null
    private var presentation: CarPresentation? = null
    private var carSurface: Surface? = null
    private val handler = Handler(Looper.getMainLooper())

    private val nativeSearchListener: (String) -> Unit = { query ->
        handler.post {
            try {
                screenManager.push(CarSearchScreen(carContext, query))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    init {
        try {
            carContext.getCarService(AppManager::class.java).setSurfaceCallback(this)
            val navManager = carContext.getCarService(androidx.car.app.navigation.NavigationManager::class.java)
            navManager.setNavigationManagerCallback(object : androidx.car.app.navigation.NavigationManagerCallback {
                override fun onStopNavigation() {}
            })
        } catch (e: Exception) {
            e.printStackTrace()
        }

        CarMediaManager.registerCarNativeSearchListener(nativeSearchListener)

        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) {
                CarMediaManager.unregisterCarNativeSearchListener(nativeSearchListener)
                fullCleanup()
                CarAppShutdownManager.shutdownCompletely(carContext, "CarHudAutoScreen Destroyed")
            }
        })
    }

    override fun onSurfaceAvailable(surfaceContainer: SurfaceContainer) {
        carSurface = surfaceContainer.surface
        val width = if (surfaceContainer.width > 0) surfaceContainer.width else 800
        val height = if (surfaceContainer.height > 0) surfaceContainer.height else 480
        val dpi = if (surfaceContainer.dpi > 0) surfaceContainer.dpi else 160

        handler.post {
            setupPresentation(carSurface, width, height, dpi)
            try { invalidate() } catch (e: Exception) {}
        }
    }

    override fun onVisibleAreaChanged(visibleArea: Rect) {}
    override fun onStableAreaChanged(stableArea: Rect) {}

    override fun onSurfaceDestroyed(surfaceContainer: SurfaceContainer) {
        handler.post {
            try {
                // Android Auto also destroys the projection surface when this app is
                // sent to the AA home screen or another car app. Keep the existing
                // VirtualDisplay + Presentation alive and only make the display
                // headless. This keeps Chromium/WebView attached to a real Window,
                // which is important for smooth YouTube/HLS audio in background.
                //
                // When a new surface arrives, setupPresentation() intentionally
                // dismisses/releases this headless display and creates a fresh one,
                // avoiding the black-screen issue caused by reusing a headless VD.
                carSurface = null
                virtualDisplay?.setSurface(null)
            } catch (e: Exception) {
                AppCrashHandler.logError(e, "AndroidAutoSurfaceDestroyed")
            }
        }
    }

    override fun onClick(x: Float, y: Float) {
        handler.post {
            presentation?.dispatchTouch(x, y)
        }
    }

    override fun onScroll(distanceX: Float, distanceY: Float) {
        handler.post {
            presentation?.dispatchScroll(distanceX, distanceY)
        }
    }

    override fun onFling(velocityX: Float, velocityY: Float) {
        handler.post {
            presentation?.dispatchFling(velocityX, velocityY)
        }
    }

    override fun onScale(focusX: Float, focusY: Float, scaleFactor: Float) {}

    fun onCarConfigurationChanged(newConfiguration: android.content.res.Configuration) {
        handler.post {
            presentation?.onCarConfigurationChanged(newConfiguration)
        }
    }

    private fun setupPresentation(surface: Surface?, width: Int, height: Int, dpi: Int) {
        if (surface == null || !surface.isValid) return

        try {
            // CRITICAL FIX: NEVER reuse VirtualDisplay if it was headless (surface=null). 
            // Android has a bug where setting surface back causes a permanent black screen (sound but no picture)!
            // Always recreate the VirtualDisplay and Presentation, and just re-attach the persistent WebView.
            presentation?.dismiss()
            virtualDisplay?.release()

            val dm = carContext.getSystemService(CarContext.DISPLAY_SERVICE) as DisplayManager
            val vd = dm.createVirtualDisplay(
                "CarHudYouTubeDisplay",
                width,
                height,
                dpi,
                surface,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION
            )
            virtualDisplay = vd

            val persistentWeb = CarMediaManager.getPersistentCarWebView(carContext)
            val pres = CarPresentation(carContext, vd.display, persistentWeb)
            pres.show()
            presentation = pres

            CarMediaManager.setCarConnectionState(true)
            CarMediaManager.userWantsPlayback = true
            CarMediaManager.ensureAudioFocus()
            CarMediaManager.acquireWakeLock(carContext)


        } catch (e: Exception) {
            AppCrashHandler.logError(e, "AndroidAutoSetupPresentation")
            e.printStackTrace()
        }
    }


    private fun fullCleanup() {
        try {
            presentation?.dismiss()
            presentation = null
            virtualDisplay?.release()
            virtualDisplay = null
            CarMediaManager.setCarConnectionState(false)
        } catch (e: Exception) {}
    }

    override fun onGetTemplate(): Template {
        val actionStrip = ActionStrip.Builder()
            .addAction(Action.BACK)
            .build()

        return NavigationTemplate.Builder()
            .setActionStrip(actionStrip)
            .build()
    }
}




