package com.carhud.aaproxy

import com.carhud.app.R
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.text.InputType
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    companion object {
        val DARK_BG = Color.rgb(15, 15, 15)
        val BAR_BG = Color.parseColor("#E60D1B2A")
        val BAR_BORDER = Color.parseColor("#1F374E")
        val ACCENT = Color.parseColor("#3498DB")
    }

    private lateinit var rootLayout: FrameLayout
    private lateinit var phoneHomeContainer: LinearLayout
    private lateinit var webContainer: FrameLayout
    private var phoneClockText: TextView? = null
    private var activeTabId: String = "home"

    private val phoneClockRunnable = object : Runnable {
        override fun run() {
            phoneClockText?.let {
                val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
                it.text = timeFormat.format(Calendar.getInstance().time)
            }
            mainHandler.postDelayed(this, 1000L)
        }
    }

    private lateinit var web: WebView
    private lateinit var floatingBar: LinearLayout
    private lateinit var searchOverlay: FrameLayout
    private lateinit var searchInput: EditText
    private lateinit var micBtn: TextView
    private lateinit var statusBanner: TextView
    private var topToolbar: View? = null
    private var appGridOverlay: FrameLayout? = null
    private var appGridPanel: LinearLayout? = null
    private var appGridPosToggleBtn: TextView? = null
    private var appGridSizeBtn: TextView? = null
    private var addAppOverlay: FrameLayout? = null
    private var addAppNameInput: EditText? = null
    private var addAppUrlInput: EditText? = null
    private var addAppDesktopCheck: CheckBox? = null
    private var phoneIconPreview: ImageView? = null
    private var phoneFaviconBitmap: android.graphics.Bitmap? = null
    private var currentActiveAppId: String = "youtube"

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private val prefs: SharedPreferences by lazy {
        getSharedPreferences(SettingsActivity.PREFS, Context.MODE_PRIVATE)
    }
    private val prefChangeListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == SettingsActivity.KEY_THEME_MODE || key == "carhud_day_mode") {
            mainHandler.post {
                if (::web.isInitialized) {
                    val isDay = SettingsActivity.resolveIsDay(this@MainActivity)
                    web.setBackgroundColor(if (isDay) Color.WHITE else DARK_BG)
                    YouTubePlayerHelper.applyTheme(web, isDay)
                }
            }
        }
    }

    private val searchRequestListener: (String) -> Unit = { query ->
        mainHandler.post {
            showSearchOverlay(query)
        }
    }

    private val searchDismissListener: () -> Unit = {
        mainHandler.post {
            hideSearchOverlay(notifyCar = false)
        }
    }

    private val voiceManager by lazy {
        VoiceSearchManager(
            context = this,
            onResult = { query ->
                mainHandler.post {
                    handleVoiceQuery(query)
                }
            },
            onStateChanged = { state, text ->
                mainHandler.post {
                    if (state == VoiceSearchManager.State.LISTENING || state == VoiceSearchManager.State.RECOGNIZING) {
                        YouTubePlayerHelper.setDuckingVolume(web, 0.0f)
                    } else if (state == VoiceSearchManager.State.IDLE || state == VoiceSearchManager.State.ERROR || state == VoiceSearchManager.State.SUCCESS) {
                        YouTubePlayerHelper.setDuckingVolume(web, 1.0f)
                    }
                    updateVoiceBanner(state, text)
                    if (state == VoiceSearchManager.State.LISTENING) {
                        searchInput.hint = "🎙️ Đang lắng nghe... Nói tên bài hát"
                    } else if (state == VoiceSearchManager.State.RECOGNIZING) {
                        if (text.startsWith("🎙️ ")) {
                            val partial = text.removePrefix("🎙️ ").trim()
                            if (partial.isNotEmpty()) {
                                searchInput.setText(partial)
                                searchInput.setSelection(partial.length)
                            }
                        } else {
                            searchInput.hint = "🎙️ Đang nhận diện: $text"
                        }
                    } else if (state == VoiceSearchManager.State.ERROR) {
                        searchInput.hint = "⚠️ $text - Hãy nhập bằng bàn phím"
                    }
                    CarMediaManager.notifyVoiceState(state, text)
                }
            }
        )
    }

    private val exitReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == CarAppShutdownManager.ACTION_FULL_EXIT) {
                finishAndRemoveTask()
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCrashHandler.init(this)
        if (!LicenseManager.isLicensed(this)) {
            val intent = Intent(this, ActivationActivity::class.java)
            startActivity(intent)
            finish()
            return
        }
        if (CarMediaManager.activeVoiceManager == null) {
            CarMediaManager.activeVoiceManager = voiceManager
        }
        voiceManager.prewarm()

        CarMediaManager.registerVoiceListener { state, text ->
            mainHandler.post {
                updateVoiceBanner(state, text)
            }
        }

        CarMediaManager.registerSearchRequestListener(searchRequestListener)
        CarMediaManager.registerSearchDismissListener(searchDismissListener)

        val exitFilter = IntentFilter(CarAppShutdownManager.ACTION_FULL_EXIT)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(exitReceiver, exitFilter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(exitReceiver, exitFilter)
        }

        if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            androidx.core.app.ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.RECORD_AUDIO), 1)
        }

        if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            androidx.core.app.ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION), 2)
        }

        try {
            GpsSpeedManager.start(this)
            WazeHlpWebSocketManager.start()
            CarTtsManager.init(applicationContext)
            CarTtsManager.startListeningToRepository()
        } catch (e: Exception) {}

        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = DARK_BG
        window.navigationBarColor = DARK_BG

        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.isAppearanceLightStatusBars = false
        insetsController.isAppearanceLightNavigationBars = false

        applySettings()
        prefs.registerOnSharedPreferenceChangeListener(prefChangeListener)

        // Unlock highest available refresh rate (90Hz / 120Hz / 144Hz)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val modes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    display?.supportedModes
                } else {
                    @Suppress("DEPRECATION")
                    (getSystemService(Context.WINDOW_SERVICE) as? WindowManager)?.defaultDisplay?.supportedModes
                }
                val highestMode = modes?.maxByOrNull { it.refreshRate }
                if (highestMode != null && highestMode.refreshRate > 60f) {
                    val attrs = window.attributes
                    attrs.preferredDisplayModeId = highestMode.modeId
                    window.attributes = attrs
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        rootLayout = FrameLayout(this).apply {
            setBackgroundColor(DARK_BG)
            fitsSystemWindows = true
        }

        CarMediaManager.mainActivityRoot = rootLayout


        // Build Ultra Smooth WebView
        val initIsDay = SettingsActivity.resolveIsDay(this)
        web = WebView(this).apply {
            setBackgroundColor(if (initIsDay) Color.WHITE else DARK_BG)
            YouTubePlayerHelper.applyUltraPerformance(this)
            YouTubePlayerHelper.applyTheme(this, initIsDay)

            addJavascriptInterface(object {
                @JavascriptInterface
                fun isAuto(): Boolean = false

                @JavascriptInterface
                fun startListening() {
                    mainHandler.post {
                        startVoiceSearch()
                    }
                }

                @JavascriptInterface
                fun openSearchKeyboard() {
                    mainHandler.post {
                        showSearchOverlay()
                    }
                }

                @JavascriptInterface
                fun onUserSelectedVideo(url: String) {
                    CarMediaManager.userWantsPlayback = true
                    CarMediaManager.saveLastPlayedUrl(this@MainActivity, url)
                    mainHandler.post {
                        CarMediaManager.ensureAudioFocus()
                        CarMediaManager.acquireWakeLock(this@MainActivity)
                    }
                }

                @JavascriptInterface
                fun saveLastPlayedUrl(url: String) {
                    CarMediaManager.saveLastPlayedUrl(this@MainActivity, url)
                }

                @JavascriptInterface
                fun onPlaybackStateChanged(playing: Boolean) {
                    mainHandler.post {
                        CarMediaManager.setPlaybackState(playing)
                    }
                }

                @JavascriptInterface
                fun onTrackChanged(title: String, artist: String) {
                    mainHandler.post {
                        CarMediaManager.updateTrack(title, artist, null)
                    }
                }

                @JavascriptInterface
                fun onTrackChanged(title: String, artist: String, thumbUrl: String) {
                    mainHandler.post {
                        CarMediaManager.updateTrack(title, artist, thumbUrl)
                    }
                }


                @JavascriptInterface
                fun onVideoTimeUpdate(currentSec: Int, totalSec: Int, formattedTime: String) {
                    mainHandler.post {
                        CarMediaManager.updatePlaybackProgress(currentSec, totalSec)
                    }
                }

                @JavascriptInterface
                fun isAutoFullscreenEnabled(): Boolean = false

                @JavascriptInterface
                fun fetchSponsorSegments(videoId: String) {
                    SponsorBlockManager.fetchSegments(videoId) { jsonString ->
                        mainHandler.post {
                            try {
                                val jsonLiteral = org.json.JSONObject.quote(jsonString)
                                web.evaluateJavascript("if (window.FermataSB && window.FermataSB.onSegmentsLoaded) { window.FermataSB.onSegmentsLoaded('$videoId', $jsonLiteral); }", null)
                            } catch (e: Exception) {}
                        }
                    }
                }
            }, "AndroidVoice")

            addJavascriptInterface(object {
                @JavascriptInterface
                fun getChannelsJson(): String {
                    return IptvManager.getCachedJson(this@MainActivity)
                }

                @JavascriptInterface
                fun getCustomUrl(): String {
                    return IptvManager.getM3uUrl(this@MainActivity)
                }

                @JavascriptInterface
                fun saveCustomUrl(newUrl: String) {
                    mainHandler.post {
                        IptvManager.setM3uUrl(this@MainActivity, newUrl)
                        IptvManager.refresh(this@MainActivity) { freshList ->
                            val arr = org.json.JSONArray()
                            for (ch in freshList) arr.put(ch.toJson())
                            web.evaluateJavascript("window.onChannelsUpdated('${arr.toString().replace("'", "\\'")}')", null)
                        }
                    }
                }

                @JavascriptInterface
                fun saveCustomM3uString(fileName: String, content: String) {
                    mainHandler.post {
                        IptvManager.setM3uContent(this@MainActivity, content, fileName)
                        IptvManager.refresh(this@MainActivity) { freshList ->
                            val arr = org.json.JSONArray()
                            for (ch in freshList) arr.put(ch.toJson())
                            web.evaluateJavascript("window.onChannelsUpdated('${arr.toString().replace("'", "\\'")}')", null)
                        }
                    }
                }

                @JavascriptInterface
                fun refresh() {
                    mainHandler.post {
                        IptvManager.refresh(this@MainActivity) { freshList ->
                            val arr = org.json.JSONArray()
                            for (ch in freshList) arr.put(ch.toJson())
                            web.evaluateJavascript("window.onChannelsUpdated('${arr.toString().replace("'", "\\'")}')", null)
                        }
                    }
                }
            }, "AndroidIptv")

            IptvManager.getChannels(this@MainActivity) {}

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val target = request?.url?.toString() ?: return false
                    if (target.startsWith("intent:") || 
                        target.startsWith("snssdk") || 
                        target.startsWith("market:") || 
                        target.contains("play.google.com/store")) {
                        return true
                    }
                    return false
                }

                @Deprecated("Deprecated in Java")
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    val target = url ?: return false
                    if (target.startsWith("intent:") || 
                        target.startsWith("snssdk") || 
                        target.startsWith("market:") || 
                        target.contains("play.google.com/store")) {
                        return true
                    }
                    return false
                }

                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    YouTubeAdBlocker.shouldIntercept(request)?.let { return it }
                    val url = request?.url?.toString()
                    if (url != null && YouTubePlayerHelper.isAdUrl(url)) {
                        val origin = request.requestHeaders?.get("Origin") ?: request.requestHeaders?.get("origin")
                        return YouTubePlayerHelper.createEmptyResponse(origin)
                    }
                    return super.shouldInterceptRequest(view, request)
                }
                
                override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    val isDay = SettingsActivity.resolveIsDay(this@MainActivity)
                    YouTubePlayerHelper.applyUniversalWebTheme(view, isDay)
                }

                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    YouTubeAdBlocker.onPageFinished(view, url)
                    val isDay = SettingsActivity.resolveIsDay(this@MainActivity)
                    YouTubePlayerHelper.applyUniversalWebTheme(view, isDay)
                    val isYouTube = url.contains("youtube.com") || url.contains("youtu.be")
                    if (isYouTube) {
                        YouTubePlayerHelper.inject(view)
                    }
                    val prefs = getSharedPreferences(SettingsActivity.PREFS, Context.MODE_PRIVATE)
                    val autoResume = prefs.getBoolean(SettingsActivity.KEY_AUTO_RESUME_LAST_TRACK, true)
                    if (url.contains("watch")) {
                        if (CarMediaManager.userWantsPlayback || autoResume) {
                            CarMediaManager.userWantsPlayback = true
                            CarMediaManager.ensureAudioFocus()
                            CarMediaManager.acquireWakeLock(this@MainActivity)
                            view.postDelayed({
                                if (!CarMediaManager.isPlaying) {
                                    YouTubePlayerHelper.resumePlayback(view)
                                }
                            }, 500L)
                        }
                    } else if (isYouTube && (CarMediaManager.userWantsPlayback || autoResume)) {
                        CarMediaManager.ensureAudioFocus()
                        view.postDelayed({
                            if (!CarMediaManager.isPlaying) {
                                YouTubePlayerHelper.playFirstAvailableVideo(view)
                            }
                        }, 600L)
                    }
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest?) {
                    request?.grant(request.resources)
                }

                override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                    if (customView != null) {
                        callback?.onCustomViewHidden()
                        return
                    }
                    customView = view
                    customViewCallback = callback
                    web.visibility = View.GONE
                    floatingBar.visibility = View.GONE
                    topToolbar?.visibility = View.GONE
                    rootLayout.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                    enterFullscreen()
                }

                override fun onHideCustomView() {
                    if (customView == null) return
                    rootLayout.removeView(customView)
                    customView = null
                    customViewCallback?.onCustomViewHidden()
                    customViewCallback = null
                    web.visibility = View.VISIBLE
                    floatingBar.visibility = View.VISIBLE
                    topToolbar?.visibility = View.VISIBLE
                    exitFullscreen()
                    showFloatingBar()
                    try {
                        web.evaluateJavascript(
                            """
                            (function() {
                                document.documentElement.classList.remove('carhud-force-fullscreen');
                                document.body.classList.remove('carhud-force-fullscreen');
                                var v = document.querySelector('video');
                                if (v) {
                                    v.removeAttribute('data-carhud-styled');
                                    v.style.removeProperty('position');
                                    v.style.removeProperty('top');
                                    v.style.removeProperty('left');
                                    v.style.removeProperty('right');
                                    v.style.removeProperty('bottom');
                                    v.style.removeProperty('width');
                                    v.style.removeProperty('height');
                                    v.style.removeProperty('margin');
                                    v.style.removeProperty('object-fit');
                                    v.style.removeProperty('z-index');
                                    if (v.paused) { try { v.play(); } catch(e){} }
                                }
                                var p = document.getElementById('movie_player') || document.querySelector('.html5-video-player');
                                if (p && typeof p.playVideo === 'function') { try { p.playVideo(); } catch(e){} }
                            })();
                            """.trimIndent(), null
                        )
                    } catch (e: Exception) {}
                }
            }
        }

        // Web Container
        webContainer = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply {
                bottomMargin = dp(60)
            }
            visibility = View.GONE
        }
        webContainer.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // Top App Toolbar inside webContainer
        rebuildTopToolbar()

        // Floating Control Bar at Bottom
        floatingBar = buildFloatingBar()
        val barParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(16)
        }
        webContainer.addView(floatingBar, barParams)

        // Status banner
        statusBanner = TextView(this).apply {
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(12), dp(20), dp(12))
            background = rounded(Color.parseColor("#F0102032"), 16f, Color.parseColor("#00E5FF"), 2)
            elevation = 50f
            visibility = View.GONE
        }
        val bannerParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            topMargin = dp(46)
        }
        webContainer.addView(statusBanner, bannerParams)
        rootLayout.addView(webContainer)

        // Phone Home Screen (Trang chủ CarWeb khớp 100% media_1788745790453.jpg)
        phoneHomeContainer = buildPhoneHomeView()
        rootLayout.addView(phoneHomeContainer)

        // In-App Search Overlay
        searchOverlay = buildSearchOverlay()
        rootLayout.addView(searchOverlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // App Grid Overlay
        appGridOverlay = buildAppGridOverlay()
        rootLayout.addView(appGridOverlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // Add App Dialog Overlay
        addAppOverlay = buildAddAppOverlay()
        rootLayout.addView(addAppOverlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        setContentView(rootLayout)

        if (savedInstanceState == null) {
            CarMediaManager.registerPhoneWebView(web, this)
            val prefs = getSharedPreferences(SettingsActivity.PREFS, Context.MODE_PRIVATE)
            val autoResume = prefs.getBoolean(SettingsActivity.KEY_AUTO_RESUME_LAST_TRACK, true)
            val lastUrl = prefs.getString(SettingsActivity.KEY_LAST_PLAYED_URL, null)
            val activeApp = WebAppManager.getActiveApp(this)
            val targetUrl = if (activeApp.id == "youtube" && autoResume && !lastUrl.isNullOrBlank() && lastUrl.contains("watch")) {
                CarMediaManager.userWantsPlayback = true
                if (lastUrl.contains("www.youtube.com")) lastUrl.replace("www.youtube.com", "m.youtube.com") else lastUrl
            } else {
                activeApp.url
            }
            if (activeApp.isDesktop) {
                web.settings.userAgentString = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
            } else {
                web.settings.userAgentString = null
            }
            web.loadUrl(targetUrl)
        } else {
            web.restoreState(savedInstanceState)
        }
        resetAutoHideTimer()
    }

    private var notifBanner: View? = null

    override fun onResume() {
        super.onResume()
        if (!LicenseManager.isLicensed(this)) {
            val intent = Intent(this, ActivationActivity::class.java)
            startActivity(intent)
            finish()
            return
        }
        rebuildTopToolbar()
        checkNotificationPermissionBanner()
        if (::web.isInitialized) {
            web.onResume()
            web.resumeTimers()
            YouTubePlayerHelper.applyTheme(web, SettingsActivity.resolveIsDay(this))
            if (CarMediaManager.userWantsPlayback || CarMediaManager.isPlaying) {
                YouTubePlayerHelper.resumePlayback(web)
            }
        }
    }


    private fun checkNotificationPermissionBanner() {
        val granted = VietmapSettingsManager.isNotificationListenerGranted(this)
        if (!granted) {
            if (notifBanner == null) {
                val banner = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = 10f * resources.displayMetrics.density
                        setColor(Color.parseColor("#1E293B"))
                        setStroke((1 * resources.displayMetrics.density).toInt(), Color.parseColor("#F59E0B"))
                    }
                    val d = resources.displayMetrics.density
                    setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply {
                        setMargins((12 * d).toInt(), (60 * d).toInt(), (12 * d).toInt(), 0)
                    }

                    val icon = TextView(this@MainActivity).apply {
                        text = "🔔"
                        textSize = 18f
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply {
                            rightMargin = (8 * d).toInt()
                        }
                    }
                    addView(icon)

                    val textCol = LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

                        val title = TextView(this@MainActivity).apply {
                            text = "Ch\u01B0a c\u1EA5p quy\u1EC1n Th\u00F4ng b\u00E1o"
                            textSize = 12f
                            typeface = Typeface.DEFAULT_BOLD
                            setTextColor(Color.parseColor("#FBBF24"))
                        }
                        addView(title)

                        val sub = TextView(this@MainActivity).apply {
                            text = "C\u1EA7n c\u1EA5p quy\u1EC1n \u0111\u1EC3 CarHud nh\u1EADn ch\u1EC9 \u0111\u01B0\u1EDDng Google Maps & C\u1EA3nh b\u00E1o t\u1ED1c \u0111\u1ED9 Waze Mod"
                            textSize = 10.5f
                            setTextColor(Color.parseColor("#CBD5E1"))
                        }
                        addView(sub)
                    }
                    addView(textCol)

                    val btn = TextView(this@MainActivity).apply {
                        text = "B\u1EACT"
                        textSize = 11.5f
                        typeface = Typeface.DEFAULT_BOLD
                        setTextColor(Color.WHITE)
                        background = GradientDrawable().apply {
                            shape = GradientDrawable.RECTANGLE
                            cornerRadius = 6f * d
                            setColor(Color.parseColor("#D97706"))
                        }
                        setPadding((12 * d).toInt(), (6 * d).toInt(), (12 * d).toInt(), (6 * d).toInt())
                        setOnClickListener {
                            VietmapSettingsManager.openNotificationSettings(this@MainActivity)
                        }
                    }
                    addView(btn)
                }
                (window.decorView as? ViewGroup)?.addView(banner)
                notifBanner = banner
            }
            notifBanner?.visibility = View.VISIBLE
        } else {
            notifBanner?.visibility = View.GONE
        }
    }

    private val autoHideHandler = Handler(Looper.getMainLooper())
    private val hideFloatingBarRunnable = Runnable {
        hideFloatingBar()
    }

    fun showFloatingBar() {
        if (!::floatingBar.isInitialized) return
        if (floatingBar.visibility != View.VISIBLE) {
            floatingBar.bringToFront()
            floatingBar.visibility = View.VISIBLE
            floatingBar.alpha = 0f
            floatingBar.animate().alpha(1f).setDuration(200).start()
        } else if (floatingBar.alpha < 1f) {
            floatingBar.animate().alpha(1f).setDuration(150).start()
        }

        topToolbar?.let { top ->
            if (top.visibility != View.VISIBLE) {
                top.bringToFront()
                top.visibility = View.VISIBLE
                top.alpha = 0f
                top.animate().alpha(1f).setDuration(200).start()
            } else if (top.alpha < 1f) {
                top.animate().alpha(1f).setDuration(150).start()
            }
        }
        resetAutoHideTimer()
    }

    fun hideFloatingBar() {
        if (!::floatingBar.isInitialized) return
        if (searchOverlay.visibility == View.VISIBLE || customView != null || addAppOverlay?.visibility == View.VISIBLE || appGridOverlay?.visibility == View.VISIBLE) {
            resetAutoHideTimer()
            return
        }
        if (floatingBar.visibility == View.VISIBLE) {
            floatingBar.animate().alpha(0f).setDuration(250).withEndAction {
                floatingBar.visibility = View.GONE
            }.start()
        }
        topToolbar?.let { top ->
            if (top.visibility == View.VISIBLE) {
                top.animate().alpha(0f).setDuration(250).withEndAction {
                    top.visibility = View.GONE
                }.start()
            }
        }
    }

    fun resetAutoHideTimer() {
        autoHideHandler.removeCallbacks(hideFloatingBarRunnable)
        autoHideHandler.postDelayed(hideFloatingBarRunnable, 10000L) // 10s auto-hide
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        showFloatingBar()
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (ev?.action == MotionEvent.ACTION_DOWN) {
            showFloatingBar()
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun rebuildTopToolbar() {
        topToolbar?.let { (it.parent as? ViewGroup)?.removeView(it) }

        val apps = WebAppManager.getEnabledApps(this)
        currentActiveAppId = WebAppManager.getActiveAppId(this)

        val prefs = getSharedPreferences(SettingsActivity.PREFS, Context.MODE_PRIVATE)
        val position = prefs.getString(SettingsActivity.KEY_WEBAPP_TOOLBAR_POSITION, "left") ?: "left"
        val isVertical = (position == "left")

        val dockScale = prefs.getInt(SettingsActivity.KEY_DOCK_SCALE, 100).coerceIn(50, 150)
        val factor = dockScale / 100f

        val padH = if (isVertical) ((4 * dockScale) / 100).coerceIn(2, 10) else ((6 * dockScale) / 100).coerceIn(3, 14)
        val padV = if (isVertical) ((6 * dockScale) / 100).coerceIn(3, 14) else ((4 * dockScale) / 100).coerceIn(2, 10)

        val toolbar = LinearLayout(this).apply {
            orientation = if (isVertical) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(Color.parseColor("#F50B132B"), (16f * factor).coerceIn(10f, 24f), Color.parseColor("#00E5FF"), 2)
            elevation = 20f
            setPadding(dp(padH), dp(padV), dp(padH), dp(padV))
        }

        // 1. App Grid Launcher button (▦)
        val vBtnSize = ((44 * dockScale) / 100).coerceIn(30, 68)
        val hBtnSize = ((40 * dockScale) / 100).coerceIn(26, 60)
        val iconPad = ((4 * dockScale) / 100).coerceIn(2, 8)
        val tabMargin = ((4 * dockScale) / 100).coerceIn(2, 8)
        val hMargin = ((6 * dockScale) / 100).coerceIn(3, 10)

        val gridBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_app_grid)
            setColorFilter(Color.parseColor("#00E5FF"))
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(iconPad), dp(iconPad), dp(iconPad), dp(iconPad))
            background = rounded(Color.parseColor("#1E3B5A"), (10f * factor).coerceIn(6f, 16f), Color.parseColor("#00E5FF"), 2)
            layoutParams = if (isVertical) {
                LinearLayout.LayoutParams(dp(vBtnSize), dp(vBtnSize)).apply { bottomMargin = dp(tabMargin) }
            } else {
                LinearLayout.LayoutParams(dp(hBtnSize), dp(hBtnSize)).apply { rightMargin = dp(hMargin) }
            }
            enableTouchBounce()
            setOnClickListener {
                showFloatingBar()
                toggleAppGridOverlay()
            }
        }
        toolbar.addView(gridBtn)

        // Divider
        val div1 = View(this).apply {
            setBackgroundColor(Color.parseColor("#33FFFFFF"))
            layoutParams = if (isVertical) {
                val divWidth = ((22 * dockScale) / 100).coerceIn(12, 40)
                LinearLayout.LayoutParams(dp(divWidth), dp(1)).apply {
                    topMargin = dp(2)
                    bottomMargin = dp(tabMargin)
                }
            } else {
                val divHeight = ((16 * dockScale) / 100).coerceIn(10, 28)
                LinearLayout.LayoutParams(dp(1), dp(divHeight)).apply {
                    rightMargin = dp(hMargin)
                }
            }
        }
        toolbar.addView(div1)

        // 2. Tabs Container (Scrollable)
        if (isVertical) {
            val vScroll = ScrollView(this).apply {
                isVerticalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            val tabsContainer = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
            }
            for (app in apps) {
                val isActive = (app.id == currentActiveAppId)
                val tabView = FrameLayout(this).apply {
                    val boxColor = if (isActive) Color.parseColor("#1E3B5A") else Color.parseColor("#101C28")
                    val borderColor = if (isActive) Color.parseColor("#00E5FF") else Color.parseColor("#1B2E42")
                    background = rounded(boxColor, (10f * factor).coerceIn(6f, 16f), borderColor, if (isActive) 2 else 1)
                    layoutParams = LinearLayout.LayoutParams(dp(vBtnSize), dp(vBtnSize)).apply {
                        bottomMargin = dp(tabMargin)
                    }

                    val icon = ImageView(this@MainActivity).apply {
                        setImageResource(app.iconRes)
                        scaleType = ImageView.ScaleType.CENTER_INSIDE
                        setPadding(dp(iconPad), dp(iconPad), dp(iconPad), dp(iconPad))
                    }
                    addView(icon, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

                    enableTouchBounce()
                    setOnClickListener {
                        showFloatingBar()
                        switchWebApp(app)
                    }
                    setOnLongClickListener {
                        showFloatingBar()
                        showDisableAppDialog(app)
                        true
                    }
                }
                tabsContainer.addView(tabView)
            }
            vScroll.addView(tabsContainer)
            toolbar.addView(vScroll)
        } else {
            val hScroll = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val tabsContainer = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            for (app in apps) {
                val isActive = (app.id == currentActiveAppId)
                val tabPadH = ((8 * dockScale) / 100).coerceIn(4, 14)
                val tabPadV = ((4 * dockScale) / 100).coerceIn(2, 8)
                val tabView = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(tabPadH), dp(tabPadV), dp(tabPadH), dp(tabPadV))
                    background = if (isActive) {
                        rounded(Color.parseColor("#1E3B5A"), (10f * factor).coerceIn(6f, 16f), Color.parseColor("#00E5FF"), 2)
                    } else {
                        rounded(Color.parseColor("#101C28"), (10f * factor).coerceIn(6f, 16f), Color.parseColor("#1B2E42"), 1)
                    }
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(hBtnSize)).apply {
                        rightMargin = dp(((5 * dockScale) / 100).coerceIn(2, 10))
                    }

                    val hIconSize = ((16 * dockScale) / 100).coerceIn(10, 28)
                    val icon = ImageView(this@MainActivity).apply {
                        setImageResource(app.iconRes)
                        scaleType = ImageView.ScaleType.CENTER_INSIDE
                        layoutParams = LinearLayout.LayoutParams(dp(hIconSize), dp(hIconSize)).apply {
                            rightMargin = dp(4)
                        }
                    }
                    addView(icon)

                    val label = TextView(this@MainActivity).apply {
                        text = app.name
                        textSize = (11f * factor).coerceIn(8f, 18f)
                        typeface = if (isActive) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                        setTextColor(if (isActive) Color.WHITE else Color.parseColor("#B0BEC5"))
                    }
                    addView(label)

                    enableTouchBounce()
                    setOnClickListener {
                        showFloatingBar()
                        switchWebApp(app)
                    }
                    setOnLongClickListener {
                        showFloatingBar()
                        showDisableAppDialog(app)
                        true
                    }
                }
                tabsContainer.addView(tabView)
            }
            hScroll.addView(tabsContainer)
            toolbar.addView(hScroll)
        }

        // Divider
        val div2 = View(this).apply {
            setBackgroundColor(Color.parseColor("#33FFFFFF"))
            layoutParams = if (isVertical) {
                val divWidth = ((22 * dockScale) / 100).coerceIn(12, 40)
                LinearLayout.LayoutParams(dp(divWidth), dp(1)).apply {
                    topMargin = dp(2)
                    bottomMargin = dp(tabMargin)
                }
            } else {
                val divHeight = ((16 * dockScale) / 100).coerceIn(10, 28)
                LinearLayout.LayoutParams(dp(1), dp(divHeight)).apply {
                    leftMargin = dp(4)
                    rightMargin = dp(hMargin)
                }
            }
        }
        toolbar.addView(div2)

        // 3. Add App button (➕)
        val addBtnSize = if (isVertical) ((32 * dockScale) / 100).coerceIn(18, 54) else hBtnSize
        val addBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_app_add)
            setColorFilter(Color.parseColor("#81C784"))
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(iconPad), dp(iconPad), dp(iconPad), dp(iconPad))
            background = rounded(Color.parseColor("#1B2A1D"), (10f * factor).coerceIn(6f, 16f), Color.parseColor("#4CAF50"), 1)
            layoutParams = if (isVertical) {
                LinearLayout.LayoutParams(dp(addBtnSize), dp(addBtnSize))
            } else {
                LinearLayout.LayoutParams(dp(addBtnSize), dp(addBtnSize))
            }
            enableTouchBounce()
            setOnClickListener {
                showFloatingBar()
                showAddAppDialog()
            }
        }
        toolbar.addView(addBtn)

        topToolbar = toolbar

        val params = if (isVertical) {
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                leftMargin = dp(8)
            }
        } else {
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                topMargin = dp(6)
                leftMargin = dp(8)
                rightMargin = dp(8)
            }
        }
        if (::webContainer.isInitialized) {
            webContainer.addView(toolbar, params)
        } else {
            rootLayout.addView(toolbar, params)
        }
        resetAutoHideTimer()
    }

    private fun showDockSizeDialog() {
        val prefs = getSharedPreferences(SettingsActivity.PREFS, Context.MODE_PRIVATE)
        val currentScale = prefs.getInt(SettingsActivity.KEY_DOCK_SCALE, 100).coerceIn(50, 150)
        val options = arrayOf("Nhỏ gọn (70%)", "Vừa (85%)", "Chuẩn mặc định (100%)", "Lớn (120%)", "Cực lớn (140%)")
        val scales = intArrayOf(70, 85, 100, 120, 140)
        var selectedIndex = scales.indexOf(currentScale)
        if (selectedIndex == -1) {
            selectedIndex = scales.indices.minByOrNull { Math.abs(scales[it] - currentScale) } ?: 2
        }

        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("📏 Kích thước thanh dock")
            .setSingleChoiceItems(options, selectedIndex) { dialog, which ->
                val newScale = scales[which]
                prefs.edit().putInt(SettingsActivity.KEY_DOCK_SCALE, newScale).apply()
                appGridSizeBtn?.text = "📏 Cỡ: $newScale%"
                rebuildTopToolbar()
                updateVoiceBanner(VoiceSearchManager.State.SUCCESS, "Đã chỉnh kích thước dock: $newScale%")
                dialog.dismiss()
            }
            .setNegativeButton("Đóng", null)
            .show()
    }

    private fun showDisableAppDialog(app: WebAppItem) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("⚙ Tùy chỉnh dock: ${app.name}")
            .setMessage("Tắt ứng dụng này khỏi thanh dock để giải phóng bộ nhớ RAM và tăng tốc hiệu năng?")
            .setPositiveButton("🛑 Tắt app") { _, _ ->
                WebAppManager.setAppEnabled(this, app.id, false)
                if (app.id == currentActiveAppId) {
                    val enabledApps = WebAppManager.getEnabledApps(this)
                    switchWebApp(enabledApps.first())
                    try {
                        web.stopLoading()
                        web.clearCache(false)
                        web.freeMemory()
                    } catch (e: Exception) {}
                    System.gc()
                } else {
                    rebuildTopToolbar()
                    rebuildAppGrid()
                }
                updateVoiceBanner(VoiceSearchManager.State.SUCCESS, "Đã tắt ${app.name} để tăng tốc!")
            }
            .setNeutralButton("📏 Cỡ dock") { _, _ ->
                showDockSizeDialog()
            }
            .setNegativeButton("Hủy", null)
            .show()
    }
    private fun buildPhoneHomeView(): LinearLayout {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply {
                bottomMargin = dp(60)
            }
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#35153B"), Color.parseColor("#1B1226"), Color.parseColor("#0F1424"))
            )
            setPadding(dp(20), dp(16), dp(20), dp(8))
        }

        // 1. Header Bar: "CarWeb", "•••", "⚙", "HH:mm"
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(24)
            }

            val title = TextView(this@MainActivity).apply {
                text = "CARHUD"
                textSize = 24f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                letterSpacing = 0.02f
            }
            addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val moreBtn = TextView(this@MainActivity).apply {
                text = "•••"
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                setPadding(dp(8), dp(4), dp(8), dp(4))
                setOnClickListener { showAppGridOverlay() }
            }
            addView(moreBtn)

            val settingsBtn = ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_bar_setting)
                setColorFilter(Color.WHITE)
                setPadding(dp(4), dp(4), dp(4), dp(4))
                layoutParams = LinearLayout.LayoutParams(dp(32), dp(32)).apply {
                    leftMargin = dp(6)
                    rightMargin = dp(8)
                }
                setOnClickListener {
                    startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
                }
            }
            addView(settingsBtn)

            phoneClockText = TextView(this@MainActivity).apply {
                val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
                text = timeFormat.format(Calendar.getInstance().time)
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
            }
            addView(phoneClockText)
        }
        container.addView(header)

        // 2. 3x3 App Grid Container
        val gridScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER

            val grid = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }

            val apps = WebAppRepository.loadApps(this@MainActivity)
            val itemsPerRow = 3
            val totalRows = (apps.size + itemsPerRow - 1) / itemsPerRow

            for (r in 0 until totalRows) {
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        bottomMargin = dp(24)
                    }
                }

                for (c in 0 until itemsPerRow) {
                    val idx = r * itemsPerRow + c
                    if (idx < apps.size) {
                        val app = apps[idx]
                        val item = LinearLayout(this@MainActivity).apply {
                            orientation = LinearLayout.VERTICAL
                            gravity = Gravity.CENTER
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

                            val iconBox = FrameLayout(this@MainActivity).apply {
                                layoutParams = LinearLayout.LayoutParams(dp(68), dp(68)).apply {
                                    bottomMargin = dp(8)
                                }
                                val bgHex = app.colorHex
                                val color = try { Color.parseColor(bgHex) } catch (e: Exception) { Color.parseColor("#1877F2") }
                                background = rounded(color, 22f, Color.parseColor("#22FFFFFF"), 1)
                                elevation = 12f

                                val iv = ImageView(this@MainActivity).apply {
                                    setImageResource(app.iconRes)
                                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                                    setPadding(dp(14), dp(14), dp(14), dp(14))
                                }
                                addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                            }
                            addView(iconBox)

                            val label = TextView(this@MainActivity).apply {
                                text = app.name
                                textSize = 13f
                                typeface = Typeface.DEFAULT_BOLD
                                setTextColor(Color.WHITE)
                                gravity = Gravity.CENTER
                                maxLines = 1
                                ellipsize = android.text.TextUtils.TruncateAt.END
                            }
                            addView(label)

                            setOnClickListener {
                                showPhoneWeb(app)
                            }
                        }
                        row.addView(item)
                    } else {
                        val spacer = View(this@MainActivity).apply {
                            layoutParams = LinearLayout.LayoutParams(0, 0, 1f)
                        }
                        row.addView(spacer)
                    }
                }
                grid.addView(row)
            }
            addView(grid)
        }
        container.addView(gridScroll)

        // 3. Paging dots (3 dots)
        val dotsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(14)
                topMargin = dp(8)
            }

            for (i in 0 until 3) {
                val dot = View(this@MainActivity).apply {
                    val size = if (i == 0) dp(7) else dp(6)
                    layoutParams = LinearLayout.LayoutParams(size, size).apply {
                        leftMargin = dp(4)
                        rightMargin = dp(4)
                    }
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(if (i == 0) Color.WHITE else Color.parseColor("#55FFFFFF"))
                    }
                }
                addView(dot)
            }
        }
        container.addView(dotsRow)

        mainHandler.post(phoneClockRunnable)
        return container
    }

    fun showPhoneHome() {
        activeTabId = "home"
        phoneHomeContainer.visibility = View.VISIBLE
        webContainer.visibility = View.GONE
    }

    fun showPhoneWeb(app: WebAppItem? = null) {
        activeTabId = "browser"
        phoneHomeContainer.visibility = View.GONE
        webContainer.visibility = View.VISIBLE
        if (app != null) {
            switchWebApp(app)
        }
        showFloatingBar()
    }

    private fun handleVoiceQuery(query: String) {
        val tvCmd = TvVoiceHelper.parse(query)
        if (tvCmd != null) {
            playTvChannel(tvCmd.channelTarget)
            return
        }

        searchInput.setText(query)
        searchInput.setSelection(query.length)
        updateVoiceBanner(VoiceSearchManager.State.SUCCESS, "Đang tìm: $query")
        YouTubePlayerHelper.setDuckingVolume(web, 1.0f)

        if (currentActiveAppId != "youtube") {
            val ytApp = WebAppManager.getAllApps(this).find { it.id == "youtube" } ?: WebAppManager.DEFAULT_APPS.first()
            switchWebApp(ytApp)
        }

        YouTubePlayerHelper.search(web, query)
        CarMediaManager.notifyVoiceState(VoiceSearchManager.State.SUCCESS, "Đang tìm: $query")
        mainHandler.postDelayed({ hideSearchOverlay() }, 600)
    }

    fun playTvChannel(channelName: String) {
        val iptvApp = WebAppManager.getAllApps(this).find { it.id == "iptv" }
            ?: WebAppManager.DEFAULT_APPS.find { it.id == "iptv" }
            ?: return

        val label = if (channelName.isNotBlank()) channelName else "Truyền hình"
        updateVoiceBanner(VoiceSearchManager.State.SUCCESS, "📺 Đang mở $label...")
        CarMediaManager.notifyVoiceState(VoiceSearchManager.State.SUCCESS, "📺 Đang mở $label...")

        val isAlreadyIptv = (currentActiveAppId == "iptv" && web.url?.contains("iptv_player.html") == true)
        if (isAlreadyIptv) {
            if (channelName.isNotBlank()) {
                web.evaluateJavascript("if (window.playChannelByName) { window.playChannelByName('$channelName'); }", null)
            }
        } else {
            val targetUrl = if (channelName.isNotBlank()) {
                "file:///android_asset/iptv_player.html#channel=" + java.net.URLEncoder.encode(channelName, "UTF-8")
            } else {
                iptvApp.url
            }
            switchWebApp(iptvApp.copy(url = targetUrl))
        }

        if (channelName.isNotBlank()) {
            web.postDelayed({
                web.evaluateJavascript("if (window.playChannelByName) { window.playChannelByName('$channelName'); }", null)
            }, 600L)
            web.postDelayed({
                web.evaluateJavascript("if (window.playChannelByName) { window.playChannelByName('$channelName'); }", null)
            }, 1500L)
        }
        mainHandler.postDelayed({ hideSearchOverlay() }, 600)
    }

    fun switchWebApp(app: WebAppItem) {
        val currentUrl = web.url ?: ""
        val isYouTubeApp = (app.id == "youtube" || app.url.contains("youtube.com") || app.url.contains("youtu.be"))
        val isAlreadyLoaded = if (isYouTubeApp) {
            currentUrl.contains("youtube.com") || currentUrl.contains("youtu.be")
        } else {
            (currentActiveAppId == app.id) && currentUrl.isNotEmpty() && currentUrl != "about:blank"
        }
        currentActiveAppId = app.id
        WebAppManager.setActiveAppId(this, app.id)

        if (app.id == "tiktok" || app.url.contains("tiktok.com")) {
            web.settings.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
            web.settings.domStorageEnabled = true
            web.settings.databaseEnabled = true
            web.settings.mediaPlaybackRequiresUserGesture = false
            try {
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
            } catch (e: Exception) {}
        } else if (app.isDesktop) {
            web.settings.userAgentString = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
        } else {
            web.settings.userAgentString = null
        }
        if (app.url.contains("iptv_player.html") || app.url.startsWith("file:///android_asset/")) {
            web.setInitialScale(100)
            web.settings.useWideViewPort = true
            web.settings.loadWithOverviewMode = false
            web.settings.textZoom = 100
        } else {
            web.setInitialScale(0)
            web.settings.useWideViewPort = true
            web.settings.loadWithOverviewMode = true
        }

        val homeUrl = if (app.id == "youtube") {
            if (app.isDesktop) "https://www.youtube.com" else "https://m.youtube.com"
        } else {
            app.url
        }
        if (!isAlreadyLoaded) {
            web.loadUrl(homeUrl)
        }
        rebuildTopToolbar()
        rebuildAppGrid()
        resetAutoHideTimer()
    }

    private fun buildAppGridOverlay(): FrameLayout {
        return FrameLayout(this).apply {
            visibility = View.GONE
            setBackgroundColor(Color.parseColor("#F208111D"))
            isClickable = true

            val rootPanel = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(16), dp(16), dp(16), dp(16))
            }

            val header = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(14)
                }

                // Row 1: Title + Close Button
                val topRow = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        bottomMargin = dp(10)
                    }

                    val title = TextView(this@MainActivity).apply {
                        text = "🚀 CÀI ĐẶT ỨNG DỤNG CARHUD"
                        textSize = 18f
                        typeface = Typeface.DEFAULT_BOLD
                        setTextColor(Color.WHITE)
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    addView(title)

                    val closeBtn = TextView(this@MainActivity).apply {
                        text = "✕ Đóng"
                        textSize = 13.5f
                        typeface = Typeface.DEFAULT_BOLD
                        setTextColor(Color.WHITE)
                        setPadding(dp(16), dp(8), dp(16), dp(8))
                        background = rounded(Color.parseColor("#C62828"), 12f, Color.parseColor("#E57373"), 1)
                        enableTouchBounce()
                        setOnClickListener {
                            hideAppGridOverlay()
                        }
                    }
                    addView(closeBtn)
                }
                addView(topRow)

                // Row 2: Action Buttons (Position, Size, Optimize RAM)
                val actionsRow = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

                    val posToggleBtn = TextView(this@MainActivity).apply {
                        appGridPosToggleBtn = this
                        val prefs = getSharedPreferences(SettingsActivity.PREFS, Context.MODE_PRIVATE)
                        val curPos = prefs.getString(SettingsActivity.KEY_WEBAPP_TOOLBAR_POSITION, "left") ?: "left"
                        text = if (curPos == "left") "📍 Vị trí: Trái" else "📍 Vị trí: Trên"
                        textSize = 13f
                        typeface = Typeface.DEFAULT_BOLD
                        setTextColor(Color.parseColor("#00E5FF"))
                        setPadding(dp(12), dp(8), dp(12), dp(8))
                        background = rounded(Color.parseColor("#1A00E5FF"), 10f, Color.parseColor("#00E5FF"), 1)
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                            rightMargin = dp(6)
                        }
                        gravity = Gravity.CENTER
                        enableTouchBounce()
                        setOnClickListener {
                            val oldPos = prefs.getString(SettingsActivity.KEY_WEBAPP_TOOLBAR_POSITION, "left") ?: "left"
                            val newPos = if (oldPos == "left") "top" else "left"
                            prefs.edit().putString(SettingsActivity.KEY_WEBAPP_TOOLBAR_POSITION, newPos).apply()
                            text = if (newPos == "left") "📍 Vị trí: Trái" else "📍 Vị trí: Trên"
                            rebuildTopToolbar()
                        }
                    }
                    addView(posToggleBtn)

                    val sizeBtn = TextView(this@MainActivity).apply {
                        appGridSizeBtn = this
                        val prefs = getSharedPreferences(SettingsActivity.PREFS, Context.MODE_PRIVATE)
                        val curScale = prefs.getInt(SettingsActivity.KEY_DOCK_SCALE, 100).coerceIn(50, 150)
                        text = "📏 Cỡ: $curScale%"
                        textSize = 13f
                        typeface = Typeface.DEFAULT_BOLD
                        setTextColor(Color.parseColor("#80D8FF"))
                        setPadding(dp(12), dp(8), dp(12), dp(8))
                        background = rounded(Color.parseColor("#1A00E5FF"), 10f, Color.parseColor("#80D8FF"), 1)
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                            rightMargin = dp(6)
                        }
                        gravity = Gravity.CENTER
                        enableTouchBounce()
                        setOnClickListener {
                            showDockSizeDialog()
                        }
                    }
                    addView(sizeBtn)

                    val optRamBtn = TextView(this@MainActivity).apply {
                        text = "⚡ Tối ưu RAM"
                        textSize = 13f
                        typeface = Typeface.DEFAULT_BOLD
                        setTextColor(Color.parseColor("#FFD54F"))
                        setPadding(dp(12), dp(8), dp(12), dp(8))
                        background = rounded(Color.parseColor("#26FFD54F"), 10f, Color.parseColor("#FFD54F"), 1)
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                        gravity = Gravity.CENTER
                        enableTouchBounce()
                        setOnClickListener {
                            try {
                                web.stopLoading()
                                web.clearCache(false)
                                web.freeMemory()
                            } catch (e: Exception) {}
                            System.gc()
                            Toast.makeText(this@MainActivity, "⚡ Đã giải phóng RAM & tối ưu hiệu năng!", Toast.LENGTH_SHORT).show()
                        }
                    }
                    addView(optRamBtn)
                }
                addView(actionsRow)
            }
            rootPanel.addView(header)

            val scrollContainer = ScrollView(this@MainActivity).apply {
                isVerticalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }

            val gridContent = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
            }
            appGridPanel = gridContent
            scrollContainer.addView(gridContent)
            rootPanel.addView(scrollContainer)

            addView(rootPanel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
    }

    private fun rebuildAppGrid() {
        val panel = appGridPanel ?: return
        panel.removeAllViews()

        val apps = WebAppManager.getAllApps(this)
        val itemsPerRow = 4

        var currentRow: LinearLayout? = null

        for (i in apps.indices) {
            val app = apps[i]
            val isEnabled = WebAppManager.isAppEnabled(this, app.id)

            if (i % itemsPerRow == 0) {
                currentRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        bottomMargin = dp(14)
                    }
                }
                panel.addView(currentRow)
            }

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(8), dp(4), dp(8))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                alpha = if (isEnabled) 1.0f else 0.55f

                val iconBox = FrameLayout(this@MainActivity).apply {
                    val boxColor = try { Color.parseColor(app.colorHex) } catch(e: Exception) { Color.parseColor("#1E88E5") }
                    background = rounded(boxColor, 16f, if (isEnabled) Color.WHITE else Color.parseColor("#55FFFFFF"), 1)
                    layoutParams = LinearLayout.LayoutParams(dp(66), dp(66)).apply {
                        gravity = Gravity.CENTER_HORIZONTAL
                        bottomMargin = dp(6)
                    }

                    val icon = ImageView(this@MainActivity).apply {
                        scaleType = ImageView.ScaleType.CENTER_INSIDE
                        if (!app.iconPath.isNullOrBlank() && java.io.File(app.iconPath).exists()) {
                            val bmp = android.graphics.BitmapFactory.decodeFile(app.iconPath)
                            if (bmp != null) {
                                setImageBitmap(bmp)
                                setPadding(dp(6), dp(6), dp(6), dp(6))
                            } else {
                                setImageResource(app.iconRes)
                                setPadding(dp(10), dp(10), dp(10), dp(10))
                            }
                        } else {
                            setImageResource(app.iconRes)
                            setPadding(dp(10), dp(10), dp(10), dp(10))
                        }
                    }
                    addView(icon, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                }
                addView(iconBox)

                val label = TextView(this@MainActivity).apply {
                    text = app.name
                    textSize = 13.5f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(if (isEnabled) Color.WHITE else Color.parseColor("#90A4AE"))
                    gravity = Gravity.CENTER
                    maxLines = 1
                }
                addView(label)

                val statusBadge = TextView(this@MainActivity).apply {
                    text = if (isEnabled) "🟢 Bật" else "⚪ Đã tắt"
                    textSize = 12f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(if (isEnabled) Color.parseColor("#00E5FF") else Color.parseColor("#90A4AE"))
                    setPadding(dp(10), dp(5), dp(10), dp(5))
                    val bColor = if (isEnabled) Color.parseColor("#1A00E5FF") else Color.parseColor("#222A35")
                    val strColor = if (isEnabled) Color.parseColor("#00E5FF") else Color.parseColor("#455A64")
                    background = rounded(bColor, 10f, strColor, 1)
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        topMargin = dp(5)
                    }
                    enableTouchBounce()
                    setOnClickListener {
                        val newState = !isEnabled
                        WebAppManager.setAppEnabled(this@MainActivity, app.id, newState)
                        if (!newState && app.id == currentActiveAppId) {
                            val enabledApps = WebAppManager.getEnabledApps(this@MainActivity)
                            switchWebApp(enabledApps.first())
                            try {
                                web.stopLoading()
                                web.clearCache(false)
                            } catch (e: Exception) {}
                        } else {
                            rebuildTopToolbar()
                            rebuildAppGrid()
                        }
                        updateVoiceBanner(VoiceSearchManager.State.SUCCESS, if (newState) "Đã bật ${app.name}" else "Đã tắt ${app.name} để tăng tốc")
                    }
                }
                addView(statusBadge)

                val isDesktop = WebAppManager.isAppDesktop(this@MainActivity, app.id)
                val modeBadge = TextView(this@MainActivity).apply {
                    text = if (isDesktop) "💻 Desktop" else "📱 Mobile"
                    textSize = 11.5f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(if (isDesktop) Color.parseColor("#00E5FF") else Color.parseColor("#81C784"))
                    setPadding(dp(8), dp(4), dp(8), dp(4))
                    val bColor = if (isDesktop) Color.parseColor("#2600E5FF") else Color.parseColor("#264CAF50")
                    val strColor = if (isDesktop) Color.parseColor("#00E5FF") else Color.parseColor("#4CAF50")
                    background = rounded(bColor, 8f, strColor, 1)
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        topMargin = dp(4)
                    }
                    enableTouchBounce()
                    setOnClickListener {
                        val nextMode = !isDesktop
                        WebAppManager.setAppDesktop(this@MainActivity, app.id, nextMode)
                        rebuildAppGrid()
                        if (app.id == currentActiveAppId) {
                            if (nextMode) {
                                web.settings.userAgentString = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
                            } else {
                                web.settings.userAgentString = null
                            }
                            web.reload()
                        }
                        updateVoiceBanner(VoiceSearchManager.State.SUCCESS, "${app.name}: ${if (nextMode) "Chế độ Desktop" else "Chế độ Mobile"}")
                    }
                }
                addView(modeBadge)

                enableTouchBounce()
                setOnClickListener {
                    if (!isEnabled) {
                        androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                            .setTitle("Bật ứng dụng ${app.name}?")
                            .setMessage("Ứng dụng này đang tắt để tiết kiệm RAM. Bật lại lên thanh dock và mở ngay?")
                            .setPositiveButton("Bật & Mở") { _, _ ->
                                WebAppManager.setAppEnabled(this@MainActivity, app.id, true)
                                hideAppGridOverlay()
                                switchWebApp(app)
                            }
                            .setNegativeButton("Hủy", null)
                            .show()
                    } else {
                        hideAppGridOverlay()
                        switchWebApp(app)
                    }
                }

                setOnLongClickListener {
                    showDisableAppDialog(app)
                    true
                }
            }
            currentRow?.addView(card)
        }

        // Add "+ Thêm App" card
        val addCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(4), dp(4), dp(4))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

            val iconBox = FrameLayout(this@MainActivity).apply {
                background = rounded(Color.parseColor("#1B2A1D"), 14f, Color.parseColor("#4CAF50"), 2)
                layoutParams = LinearLayout.LayoutParams(dp(50), dp(50)).apply {
                    gravity = Gravity.CENTER_HORIZONTAL
                    bottomMargin = dp(4)
                }

                val icon = ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_app_add)
                    setColorFilter(Color.parseColor("#81C784"))
                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                    setPadding(dp(10), dp(10), dp(10), dp(10))
                }
                addView(icon, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
            addView(iconBox)

            val label = TextView(this@MainActivity).apply {
                text = "+ Thêm"
                textSize = 10.5f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.parseColor("#81C784"))
                gravity = Gravity.CENTER
                maxLines = 1
            }
            addView(label)

            setOnClickListener {
                hideAppGridOverlay()
                showAddAppDialog()
            }
        }
        if (apps.size % itemsPerRow == 0) {
            currentRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(12)
                }
            }
            panel.addView(currentRow)
        }
        currentRow?.addView(addCard)
    }

    fun toggleAppGridOverlay() {
        if (appGridOverlay?.visibility == View.VISIBLE) {
            hideAppGridOverlay()
        } else {
            showAppGridOverlay()
        }
    }

    fun showAppGridOverlay() {
        val prefs = getSharedPreferences(SettingsActivity.PREFS, Context.MODE_PRIVATE)
        val curPos = prefs.getString(SettingsActivity.KEY_WEBAPP_TOOLBAR_POSITION, "left") ?: "left"
        val curScale = prefs.getInt(SettingsActivity.KEY_DOCK_SCALE, 100).coerceIn(50, 150)
        appGridPosToggleBtn?.text = if (curPos == "left") "📍 Vị trí: Trái" else "📍 Vị trí: Trên"
        appGridSizeBtn?.text = "📏 Cỡ: $curScale%"
        rebuildAppGrid()
        appGridOverlay?.visibility = View.VISIBLE
        appGridOverlay?.alpha = 0f
        appGridOverlay?.animate()?.alpha(1f)?.setDuration(200)?.start()
    }

    fun hideAppGridOverlay() {
        appGridOverlay?.animate()?.alpha(0f)?.setDuration(200)?.withEndAction {
            appGridOverlay?.visibility = View.GONE
        }?.start()
    }

    private fun buildAddAppOverlay(): FrameLayout {
        return FrameLayout(this).apply {
            visibility = View.GONE
            setBackgroundColor(Color.parseColor("#D9000000"))
            isClickable = true

            val card = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(20), dp(16), dp(20), dp(16))
                background = rounded(Color.parseColor("#101C28"), 16f, Color.parseColor("#00E5FF"), 2)
            }

            val title = TextView(this@MainActivity).apply {
                text = "➕ Thêm Ứng Dụng Web Mới"
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(10)
                }
            }
            card.addView(title)

            val iconPreviewRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(dp(260), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(10)
                }

                val previewBox = FrameLayout(this@MainActivity).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply {
                        rightMargin = dp(10)
                    }
                    background = rounded(Color.parseColor("#1B2A3A"), 12f, Color.parseColor("#00E5FF"), 1)
                    val img = ImageView(this@MainActivity).apply {
                        phoneIconPreview = this
                        setImageResource(R.drawable.ic_app_web)
                        scaleType = ImageView.ScaleType.CENTER_INSIDE
                        setPadding(dp(8), dp(8), dp(8), dp(8))
                    }
                    addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                }
                addView(previewBox)

                val iconHint = TextView(this@MainActivity).apply {
                    text = "🌐 Tự động lấy Icon chất lượng cao từ tên miền URL"
                    textSize = 11f
                    setTextColor(Color.parseColor("#78909C"))
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }
                addView(iconHint)
            }
            card.addView(iconPreviewRow)

            addAppNameInput = EditText(this@MainActivity).apply {
                hint = "Tên ứng dụng (VD: TV360, Facebook, VTV...)"
                setHintTextColor(Color.parseColor("#607D8B"))
                setTextColor(Color.WHITE)
                textSize = 13f
                background = rounded(Color.parseColor("#182A3A"), 10f, Color.parseColor("#37474F"), 1)
                setPadding(dp(12), dp(8), dp(12), dp(8))
                layoutParams = LinearLayout.LayoutParams(dp(260), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(8)
                }
            }
            card.addView(addAppNameInput)

            addAppUrlInput = EditText(this@MainActivity).apply {
                hint = "Địa chỉ URL (VD: tv360.vn, facebook.com)"
                setHintTextColor(Color.parseColor("#607D8B"))
                setTextColor(Color.WHITE)
                textSize = 13f
                background = rounded(Color.parseColor("#182A3A"), 10f, Color.parseColor("#37474F"), 1)
                setPadding(dp(12), dp(8), dp(12), dp(8))
                layoutParams = LinearLayout.LayoutParams(dp(260), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(8)
                }

                addTextChangedListener(object : android.text.TextWatcher {
                    private var fetchTask: Runnable? = null
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                        fetchTask?.let { mainHandler.removeCallbacks(it) }
                        val raw = s?.toString()?.trim() ?: ""
                        if (raw.length > 3) {
                            val r = Runnable {
                                val domain = WebIconFetcher.extractDomain(raw)
                                if (domain.contains(".")) {
                                    if (addAppNameInput?.text.isNullOrBlank()) {
                                        addAppNameInput?.setText(WebIconFetcher.extractPrettyName(domain))
                                    }
                                    WebIconFetcher.fetchFaviconAsync(domain) { bmp ->
                                        if (bmp != null) {
                                            phoneFaviconBitmap = bmp
                                            phoneIconPreview?.setImageBitmap(bmp)
                                            phoneIconPreview?.setPadding(dp(4), dp(4), dp(4), dp(4))
                                        }
                                    }
                                }
                            }
                            fetchTask = r
                            mainHandler.postDelayed(r, 600)
                        }
                    }
                    override fun afterTextChanged(s: android.text.Editable?) {}
                })
            }
            card.addView(addAppUrlInput)

            addAppDesktopCheck = CheckBox(this@MainActivity).apply {
                text = "Chế độ máy tính (Desktop User-Agent)"
                setTextColor(Color.parseColor("#B0BEC5"))
                textSize = 12f
                layoutParams = LinearLayout.LayoutParams(dp(260), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(12)
                }
            }
            card.addView(addAppDesktopCheck)

            val btnRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(260), ViewGroup.LayoutParams.WRAP_CONTENT)

                val cancelBtn = TextView(this@MainActivity).apply {
                    text = "Hủy"
                    textSize = 13f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    setPadding(dp(18), dp(8), dp(18), dp(8))
                    background = rounded(Color.parseColor("#37474F"), 10f, 0, 0)
                    setOnClickListener {
                        hideAddAppDialog()
                    }
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        rightMargin = dp(8)
                    }
                }
                addView(cancelBtn)

                val saveBtn = TextView(this@MainActivity).apply {
                    text = "Lưu & Mở"
                    textSize = 13f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    setPadding(dp(18), dp(8), dp(18), dp(8))
                    background = rounded(Color.parseColor("#1976D2"), 10f, Color.parseColor("#00E5FF"), 1)
                    setOnClickListener {
                        val name = addAppNameInput?.text?.toString()?.trim() ?: ""
                        val url = addAppUrlInput?.text?.toString()?.trim() ?: ""
                        if (url.isNotEmpty()) {
                            val isDesktop = addAppDesktopCheck?.isChecked == true
                            val customId = "custom_" + System.currentTimeMillis()
                            var savedIconPath: String? = null
                            phoneFaviconBitmap?.let { bmp ->
                                savedIconPath = WebIconFetcher.saveIconToDisk(this@MainActivity, customId, bmp)
                            }
                            val newApp = WebAppManager.addCustomApp(this@MainActivity, name, url, isDesktop, iconPath = savedIconPath)
                            hideAddAppDialog()
                            switchWebApp(newApp)
                        }
                    }
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        leftMargin = dp(8)
                    }
                }
                addView(saveBtn)
            }
            card.addView(btnRow)

            addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.CENTER
            })
        }
    }

    fun showAddAppDialog() {
        phoneFaviconBitmap = null
        phoneIconPreview?.setImageResource(R.drawable.ic_app_web)
        phoneIconPreview?.setPadding(dp(8), dp(8), dp(8), dp(8))
        addAppNameInput?.setText("")
        addAppUrlInput?.setText("")
        addAppDesktopCheck?.isChecked = false
        addAppOverlay?.visibility = View.VISIBLE
        addAppOverlay?.alpha = 0f
        addAppOverlay?.animate()?.alpha(1f)?.setDuration(200)?.start()
    }

    fun hideAddAppDialog() {
        addAppOverlay?.animate()?.alpha(0f)?.setDuration(200)?.withEndAction {
            addAppOverlay?.visibility = View.GONE
        }?.start()
    }

    fun goHome() {
        val app = WebAppManager.getActiveApp(this)
        switchWebApp(app)
    }

    fun startVoiceSearch() {
        hideSearchOverlay()
        YouTubePlayerHelper.setDuckingVolume(web, 0.0f)
        updateVoiceBanner(VoiceSearchManager.State.LISTENING, "Đang lắng nghe... Hãy nói tên bài hát")
        voiceManager.startListening()
    }

    private fun buildFloatingBar(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = rounded(Color.parseColor("#F50B132B"), 22f, Color.parseColor("#00E5FF"), 2)

            addView(barButton("‹") { if (web.canGoBack()) web.goBack() })
            addView(barButton("⌂") { goHome() })
            addView(barButton("▦") { toggleAppGridOverlay() })
            addView(barButton("↻") { web.reload() })
            addView(barButton("⌕") { showSearchOverlay() })
            micBtn = barButton("🎙️") {
                startVoiceSearch()
            }
            addView(micBtn)
            addView(barButton("⚙") { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) })
        }
    }

    private fun barButton(text: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(Color.parseColor("#1E3B5A"), 18f, Color.parseColor("#00E5FF"), 1)
            enableTouchBounce()
            setOnClickListener { onClick() }
            val p = LinearLayout.LayoutParams(dp(44), dp(44)).apply {
                leftMargin = dp(3)
                rightMargin = dp(3)
            }
            layoutParams = p
        }
    }

    private val voiceBannerHideHandler = Handler(Looper.getMainLooper())
    private val hideVoiceBannerRunnable = Runnable {
        statusBanner.animate().alpha(0f).setDuration(250).withEndAction {
            statusBanner.visibility = View.GONE
            statusBanner.alpha = 1f
        }.start()
        micBtn.background = rounded(Color.parseColor("#223348"), 16f, Color.parseColor("#334C68"), 1)
    }

    private fun scheduleVoiceBannerDismiss() {
        voiceBannerHideHandler.removeCallbacks(hideVoiceBannerRunnable)
        voiceBannerHideHandler.postDelayed(hideVoiceBannerRunnable, 5000L)
    }

    private fun updateVoiceBanner(state: VoiceSearchManager.State, text: String) {
        voiceBannerHideHandler.removeCallbacks(hideVoiceBannerRunnable)
        when (state) {
            VoiceSearchManager.State.IDLE -> {
                statusBanner.visibility = View.GONE
                micBtn.background = rounded(Color.parseColor("#223348"), 16f, Color.parseColor("#334C68"), 1)
            }
            VoiceSearchManager.State.LISTENING -> {
                statusBanner.text = "🎙️ Đang lắng nghe..."
                statusBanner.background = rounded(Color.parseColor("#F0102032"), 16f, Color.parseColor("#00E5FF"), 2)
                statusBanner.visibility = View.VISIBLE
                statusBanner.alpha = 1f
                statusBanner.bringToFront()
                micBtn.background = rounded(Color.parseColor("#E74C3C"), 16f, Color.WHITE, 2)
                scheduleVoiceBannerDismiss()
                try {
                    Toast.makeText(this, "🎙️ Đang nghe... Hãy nói tên bài hát", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {}
            }
            VoiceSearchManager.State.RECOGNIZING -> {
                statusBanner.text = "⏳ $text"
                statusBanner.background = rounded(Color.parseColor("#F0102032"), 16f, Color.parseColor("#F39C12"), 2)
                statusBanner.visibility = View.VISIBLE
                statusBanner.alpha = 1f
                statusBanner.bringToFront()
                micBtn.background = rounded(Color.parseColor("#E67E22"), 16f, Color.WHITE, 2)
                scheduleVoiceBannerDismiss()
            }
            VoiceSearchManager.State.SUCCESS -> {
                statusBanner.text = "🔍 $text"
                statusBanner.background = rounded(Color.parseColor("#F0102032"), 16f, Color.parseColor("#2ECC71"), 2)
                statusBanner.visibility = View.VISIBLE
                statusBanner.alpha = 1f
                statusBanner.bringToFront()
                micBtn.background = rounded(Color.parseColor("#2ECC71"), 16f, Color.WHITE, 2)
                voiceBannerHideHandler.postDelayed(hideVoiceBannerRunnable, 2000L)
            }
            VoiceSearchManager.State.ERROR -> {
                statusBanner.text = "⚠️ $text"
                statusBanner.background = rounded(Color.parseColor("#F0102032"), 16f, Color.parseColor("#E74C3C"), 2)
                statusBanner.visibility = View.VISIBLE
                statusBanner.alpha = 1f
                statusBanner.bringToFront()
                micBtn.background = rounded(Color.parseColor("#E74C3C"), 16f, Color.parseColor("#C0392B"), 1)
                voiceBannerHideHandler.postDelayed(hideVoiceBannerRunnable, 2500L)
            }
        }
    }

    private fun buildSearchOverlay(): FrameLayout {
        return FrameLayout(this).apply {
            visibility = View.GONE
            setBackgroundColor(Color.parseColor("#CC000000"))
            setOnClickListener { hideSearchOverlay() }

            val card = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(8), dp(14), dp(8))
                background = rounded(Color.parseColor("#1E2D3D"), 24f, ACCENT, 1)

                val closeBtn = TextView(this@MainActivity).apply {
                    text = "✕"
                    textSize = 17f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.parseColor("#FF5252"))
                    setPadding(dp(8), dp(4), dp(10), dp(4))
                    setOnClickListener { hideSearchOverlay() }
                }
                addView(closeBtn)

                searchInput = EditText(this@MainActivity).apply {
                    hint = "Nhập từ khóa tìm kiếm (bàn phím thiết bị)..."
                    setHintTextColor(Color.parseColor("#8898AA"))
                    setTextColor(Color.WHITE)
                    textSize = 15f
                    background = null
                    isSingleLine = true
                    imeOptions = EditorInfo.IME_ACTION_SEARCH
                    inputType = InputType.TYPE_CLASS_TEXT
                    setOnKeyListener { _, keyCode, event ->
                        if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER) {
                            val q = text.toString().trim()
                            if (q.isNotEmpty()) {
                                executeSearch(q)
                            }
                            true
                        } else false
                    }
                    setOnEditorActionListener { _, actionId, _ ->
                        if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                            val q = text.toString().trim()
                            if (q.isNotEmpty()) {
                                executeSearch(q)
                            }
                            true
                        } else false
                    }
                }
                addView(searchInput, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f))

                val goBtn = TextView(this@MainActivity).apply {
                    text = "Tìm"
                    textSize = 15f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    setPadding(dp(12), dp(6), dp(12), dp(6))
                    background = rounded(ACCENT, 16f, 0, 0)
                    setOnClickListener {
                        val q = searchInput.text.toString().trim()
                        if (q.isNotEmpty()) {
                            executeSearch(q)
                        }
                    }
                }
                addView(goBtn)
            }

            val cardParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.TOP
                topMargin = dp(40)
                leftMargin = dp(24)
                rightMargin = dp(24)
            }
            addView(card, cardParams)
        }
    }

    private fun executeSearch(q: String) {
        if (q.isNotEmpty()) {
            YouTubePlayerHelper.search(web, q)
            CarMediaManager.submitSearchQuery(q)
            hideSearchOverlay()
        }
    }

    fun showSearchOverlay(initialQuery: String = "") {
        searchOverlay.visibility = View.VISIBLE
        searchOverlay.bringToFront()
        if (initialQuery.isNotEmpty()) {
            searchInput.setText(initialQuery)
            searchInput.setSelection(initialQuery.length)
        }
        searchInput.requestFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
    }

    fun hideSearchOverlay(notifyCar: Boolean = true) {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(searchInput.windowToken, 0)
        searchOverlay.visibility = View.GONE
        showFloatingBar()
        if (notifyCar) {
            CarMediaManager.dismissSearch()
        }
    }

    private fun enterFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    private fun exitFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, true)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.show(WindowInsetsCompat.Type.systemBars())
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    private fun applySettings() {
        val prefs = getSharedPreferences(SettingsActivity.PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(SettingsActivity.KEY_KEEP_SCREEN, true)) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun rounded(fill: Int, radiusDp: Float, stroke: Int, strokeDp: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(fill)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeDp > 0) {
                setStroke(dp(strokeDp), stroke)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        val prefs = getSharedPreferences(SettingsActivity.PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(SettingsActivity.KEY_BACKGROUND_AUDIO, true) && ::web.isInitialized) {
            web.onResume()
            web.resumeTimers()
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::web.isInitialized) {
            val isDay = SettingsActivity.resolveIsDay(this)
            YouTubePlayerHelper.applyUniversalWebTheme(web, isDay)
        }
    }

    override fun onStop() {
        super.onStop()
        val prefs = getSharedPreferences(SettingsActivity.PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(SettingsActivity.KEY_BACKGROUND_AUDIO, true) && ::web.isInitialized) {
            web.onResume()
            web.resumeTimers()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        val prefs = getSharedPreferences(SettingsActivity.PREFS, Context.MODE_PRIVATE)
        if (!hasFocus && prefs.getBoolean(SettingsActivity.KEY_BACKGROUND_AUDIO, true) && ::web.isInitialized) {
            web.onResume()
            web.resumeTimers()
        }
    }

    override fun onBackPressed() {
        if (addAppOverlay?.visibility == View.VISIBLE) {
            hideAddAppDialog()
            return
        }
        if (appGridOverlay?.visibility == View.VISIBLE) {
            hideAppGridOverlay()
            return
        }
        if (searchOverlay.visibility == View.VISIBLE) {
            hideSearchOverlay()
            return
        }
        if (customView != null) {
            (web.webChromeClient as? WebChromeClient)?.onHideCustomView()
            return
        }
        if (::webContainer.isInitialized && webContainer.visibility == View.VISIBLE) {
            if (web.canGoBack()) {
                web.goBack()
                return
            }
            showPhoneHome()
            return
        }
        if (web.canGoBack()) {
            web.goBack()
            return
        }
        super.onBackPressed()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onDestroy() {
        try { unregisterReceiver(exitReceiver) } catch (e: Exception) {}
        super.onDestroy()
        prefs.unregisterOnSharedPreferenceChangeListener(prefChangeListener)
        CarMediaManager.unregisterSearchRequestListener(searchRequestListener)
        CarMediaManager.unregisterSearchDismissListener(searchDismissListener)
        autoHideHandler.removeCallbacks(hideFloatingBarRunnable)
        if (::web.isInitialized) {
            CarMediaManager.unregisterPhoneWebView(web)
        }
        if (CarMediaManager.mainActivityRoot == rootLayout) {
            CarMediaManager.mainActivityRoot = null
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
    private fun dp(v: Float): Int = (v * resources.displayMetrics.density).roundToInt()
}
